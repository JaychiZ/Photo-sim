// Bundle src/main.js + three.js into one self-contained HTML file (no external requests).
import { build } from "esbuild";
import fs from "node:fs";
import path from "node:path";
import { gzipSync } from "node:zlib";

const assetDir = path.resolve("src/scene-assets");
const sceneAssets = {
  name: "scene-assets",
  setup(build) {
    build.onResolve({ filter: /^scene-assets$/ }, () => ({ path: "assets", namespace: "scene-assets" }));
    build.onLoad({ filter: /.*/, namespace: "scene-assets" }, () => {
      const ids = fs.readdirSync(assetDir).filter((name) => name.endsWith(".glb")).sort();
      const loaders = ids.map((name) => {
        const id = path.basename(name, ".glb");
        const compressed = gzipSync(fs.readFileSync(path.join(assetDir, name)), { level: 9 }).toString("base64");
        return `${JSON.stringify(id)}: ${JSON.stringify(compressed)}`;
      });
      const catDir = path.resolve("src/cat-assets"); if (fs.existsSync(catDir)) for (const name of fs.readdirSync(catDir).filter((n) => n.endsWith(".cat")).sort()) loaders.push(`${JSON.stringify("cat:" + path.basename(name, ".cat"))}: ${JSON.stringify(gzipSync(fs.readFileSync(path.join(catDir, name)), { level: 9 }).toString("base64"))}`);
      return { contents: `export default {${loaders.join(",")}};`, resolveDir: assetDir };
    });
  },
};

const r = await build({ entryPoints: ["src/main.js"], bundle: true, minify: !process.env.DEV, format: "iife", write: false, target: "es2022", legalComments: "none", loader: { ".jpg": "dataurl", ".glb": "binary" }, plugins: [sceneAssets] });
const js = r.outputFiles[0].text.replace(/<\/script/g, "<\\/script");
const html = fs.readFileSync("src/index.html", "utf8").replace("/*__BUNDLE__*/", () => js);
const bytes = Buffer.byteLength(html);
if (bytes >= 5_000_000) throw new Error(`Single HTML is ${bytes.toLocaleString()} bytes; it must be under 5 MB`);
fs.writeFileSync("index.html", html);
console.log("built index.html", bytes, "bytes");
