// Vehicles built like hero props: smooth lofted bodies with real glazing and pillars, tyres with tread, alloy wheels with lugs, lamp clusters,
// mirrors, door seams, handles, wipers, plates. Double-decker bus and tram are real geometry (panes, pillars, doors, louvres), not textured boxes.
import * as THREE from "three";
import { lathe, loft, rbox, detail } from "./kit.js";
import { gunzipSync } from "three/addons/libs/fflate.module.js";
import sources from "scene-assets";
// car bodies modelled in Blender (tools/car_blender.py: lofted cage from the same stations, subdivision surface, boolean wheel arches,
// window faces picked on the cage), packed as quantised meshes: paint shell + glass
const bodyCache = new Map();
function blenderBody(id) { if (bodyCache.has(id)) return bodyCache.get(id); const b64 = sources["cat:" + id]; if (!b64) { bodyCache.set(id, null); return null; }
  const raw = gunzipSync(Uint8Array.from(atob(b64), (c) => c.charCodeAt(0))), dv = new DataView(raw.buffer, raw.byteOffset, raw.byteLength); let o = 4; const parts = {};
  for (let p = 0, n = dv.getUint32(0, true); p < n; p++) { const nl = dv.getUint8(o); o += 1; const name = new TextDecoder().decode(raw.subarray(o, o + nl)); o += nl; const nv = dv.getUint32(o, true), ni = dv.getUint32(o + 4, true); o += 8; const mn = [0, 1, 2].map((k) => dv.getFloat32(o + k * 4, true)), mx = [0, 1, 2].map((k) => dv.getFloat32(o + 12 + k * 4, true)); o += 24;
    const pos = new Float32Array(nv * 3), nor = new Float32Array(nv * 3); for (let i = 0; i < nv * 3; i++) { const k = i % 3; pos[i] = mn[k] + (dv.getUint16(o + i * 2, true) / 65535) * (mx[k] - mn[k]); } o += nv * 6; for (let i = 0; i < nv * 3; i++) nor[i] = dv.getInt8(o + i) / 127; o += nv * 3; o += nv * 3; if (o % 2) o++;
    const idx = new Uint16Array(ni); for (let i = 0; i < ni; i++) idx[i] = dv.getUint16(o + i * 2, true); o += ni * 2; if (o % 4) o += 4 - (o % 4);
    const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.BufferAttribute(pos, 3)); g.setAttribute("normal", new THREE.BufferAttribute(nor, 3)); g.setIndex(new THREE.BufferAttribute(idx, 1)); parts[name] = g; }
  bodyCache.set(id, parts); return parts; }
const HP = Math.PI / 2, cr = (p0, p1, p2, p3, t) => 0.5 * (2 * p1 + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t + (-p0 + 3 * p1 - 3 * p2 + p3) * t * t * t), lp = (a, b, t) => a + (b - a) * t, cl = (v) => Math.max(0, Math.min(1, v));
export const CARS = {
  sedan: { L: 4.62, W: 0.9, wheel: 0.33, axles: [-1.36, 1.42], pillars: [-0.02], st: [[-2.31, 0.66, 0.44, 0.7, 0], [-2.2, 0.84, 0.3, 0.86, 0], [-1.75, 0.9, 0.22, 0.95, 0], [-1.3, 0.905, 0.2, 0.97, 0], [-0.78, 0.905, 0.2, 0.96, 1.4], [0.32, 0.905, 0.2, 0.94, 1.44], [1.02, 0.9, 0.2, 0.91, 0], [1.7, 0.885, 0.22, 0.83, 0], [2.17, 0.83, 0.28, 0.72, 0], [2.31, 0.64, 0.42, 0.6, 0]] },
  taxi: { L: 4.72, W: 0.88, wheel: 0.32, axles: [-1.4, 1.44], pillars: [-0.1], st: [[-2.36, 0.66, 0.44, 0.74, 0], [-2.24, 0.83, 0.3, 0.9, 0], [-1.7, 0.88, 0.22, 0.97, 0], [-1.22, 0.885, 0.2, 0.98, 0], [-1.0, 0.885, 0.2, 0.975, 1.42], [0.44, 0.885, 0.2, 0.955, 1.47], [1.08, 0.88, 0.2, 0.925, 0], [1.76, 0.87, 0.22, 0.85, 0], [2.22, 0.82, 0.28, 0.74, 0], [2.36, 0.64, 0.42, 0.62, 0]] },
  van: { L: 5.4, W: 0.98, wheel: 0.36, axles: [-1.62, 1.72], pillars: [-1.1, 0.3, 1.25], st: [[-2.7, 0.86, 0.42, 1.18, 0], [-2.66, 0.97, 0.3, 1.24, 2.26], [-1.6, 0.985, 0.26, 1.24, 2.32], [1.5, 0.985, 0.26, 1.2, 2.32], [2.2, 0.97, 0.26, 1.1, 0], [2.6, 0.92, 0.3, 0.95, 0], [2.7, 0.78, 0.42, 0.8, 0]] },
};
// smooth body: stations resampled with Catmull-Rom, 16-point section, shared smooth normals; glazing and pillars are index subsets of the same surface
export function carBody(spec) {
  const st = spec.st, SUB = 7, rows = []; const at = (i, k) => st[Math.max(0, Math.min(st.length - 1, i))][k];
  for (let i = 0; i < st.length - 1; i++) for (let j = 0; j < (i === st.length - 2 ? SUB + 1 : SUB); j++) { const t = j / SUB, v = [0, 1, 2, 3].map((k) => cr(at(i - 1, k), at(i, k), at(i + 1, k), at(i + 2, k), t)); const ra = at(i, 4) || at(i, 3), rb = at(i + 1, 4) || at(i + 1, 3), ts = t * t * (3 - 2 * t); rows.push([v[0], v[1], v[2], v[3], lp(ra, rb, ts)]); }
  const N = 16, pos = [], cab = [];
  for (const [x, w, y0, y1, y2] of rows) { const c = cl((y2 - y1) / 0.32); cab.push(c); const H = [[w * 0.84, y0], [w * 0.985, y0 + 0.1], [w * 1.0, lp(y0 + 0.1, y1, 0.55)], [w * 0.975, y1], [w * lp(0.9, 0.86, c), lp(y1 + 0.012, lp(y1, y2, 0.55), c)], [w * lp(0.72, 0.74, c), lp(y1 + 0.024, y2 - 0.035, c)], [w * lp(0.4, 0.5, c), lp(y1 + 0.034, y2 + 0.004, c)], [0, lp(y1 + 0.038, y2 + 0.016, c)]];
    for (let k = 0; k < 8; k++) pos.push(x, H[k][1], H[k][0]); for (let k = 6; k >= 1; k--) pos.push(x, H[k][1], -H[k][0]); pos.push(x, H[0][1], -H[0][0]); pos.push(x, y0 - 0.01, 0); }
  const body = [], glass = [], R = rows.length, pill = (x0, x1) => (spec.pillars || []).some((p) => p > Math.min(x0, x1) - 0.03 && p < Math.max(x0, x1) + 0.03);
  for (let i = 0; i < R - 1; i++) { const a = i * N, b = (i + 1) * N, c0 = cab[i], c1 = cab[i + 1], side = c0 > 0.97 && c1 > 0.97, rake = (c0 > 0.06 || c1 > 0.06) && !(side); for (let k = 0; k < N; k++) { const k2 = (k + 1) % N, sg = side && (k === 3 || k === 4 || k === 10 || k === 11) && !pill(rows[i][0], rows[i + 1][0]), eg = rake && k >= 3 && k <= 11 && Math.min(c0, c1) > 0.08 && Math.max(c0, c1) < 0.999 && Math.abs(c1 - c0) > 0.02 && !(k === 3 || k === 11) ; (sg || eg ? glass : body).push(a + k, b + k, b + k2, a + k, b + k2, a + k2); } }
  for (const [o, flip] of [[0, true], [(R - 1) * N, false]]) { const ci = pos.length / 3; let cy = 0; for (let k = 0; k < N; k++) cy += pos[(o + k) * 3 + 1]; pos.push(pos[o * 3] + (flip ? -0.03 : 0.03), cy / N, 0); for (let k = 0; k < N; k++) flip ? body.push(ci, o + ((k + 1) % N), o + k) : body.push(ci, o + k, o + ((k + 1) % N)); }
  const full = new THREE.BufferGeometry(); full.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3)); full.setIndex([...body, ...glass]); full.computeVertexNormals();
  const mk = (idx) => { const g = new THREE.BufferGeometry(); g.setAttribute("position", full.attributes.position); g.setAttribute("normal", full.attributes.normal); g.setIndex(idx); return g; };
  return { body: mk(body), glass: mk(glass), rows };
}
// wheel on the z axis, outer face towards +z
export function wheelParts(B, M, r, w, x, y, z, side, big = false) {
  const s = side, ry = 0, rx = s > 0 ? HP : -HP, rr = r * (big ? 0.6 : 0.68), tw = w / 2;
  B.add(lathe([[rr, -tw], [r - 0.035, -tw], [r - 0.012, -tw + 0.02], [r, -tw + 0.045], [r, -tw * 0.42], [r - 0.012, -tw * 0.38], [r - 0.012, -tw * 0.3], [r, -tw * 0.26], [r, tw * 0.26], [r - 0.012, tw * 0.3], [r - 0.012, tw * 0.38], [r, tw * 0.42], [r, tw - 0.045], [r - 0.012, tw - 0.02], [r - 0.035, tw], [rr, tw]], 40), M.tire, x, y, z, ry, rx);
  for (let i = 0; i < 44; i++) { const a = (i / 44) * 6.2832; B.add(rbox(0.012, 0.016, w * 0.2, 0.003), M.tire, x + Math.cos(a) * (r - 0.004), y + Math.sin(a) * (r - 0.004), z + s * w * 0.33 * (i % 2 ? 1 : -1), 0, 0, a + HP); }
  B.add(lathe([[rr + 0.004, tw * 0.9], [rr - 0.012, tw * 0.9], [rr - 0.022, tw * 0.72], [rr * 0.45, tw * 0.5], [rr * 0.3, tw * 0.62], [rr * 0.24, tw * 0.7], [0, tw * 0.7]], 36), M.rim, x, y, z, ry, rx); B.add(lathe([[0, -tw * 0.2], [rr * 0.82, -tw * 0.2], [rr * 0.82, -tw * 0.1], [0, -tw * 0.1]], 28), M.disc, x, y, z, ry, rx);
  const n = big ? 10 : 5; for (let i = 0; i < n; i++) { const a = (i / n) * 6.2832 + 0.3; if (!big) for (const o of [-0.09, 0.09]) B.add(rbox(rr * 0.74, 0.026, 0.03, 0.008), M.rim, x + Math.cos(a + o * 0.5) * rr * 0.6, y + Math.sin(a + o * 0.5) * rr * 0.6, z + s * tw * 0.66, 0, 0, a + o); B.add(lathe([[0, 0], [0.011, 0], [0.011, 0.014], [0.006, 0.02], [0, 0.02]], 6), M.chrome, x + Math.cos(a) * rr * (big ? 0.42 : 0.2), y + Math.sin(a) * rr * (big ? 0.42 : 0.2), z + s * tw * (big ? 0.6 : 0.7), ry, rx); }
  B.add(lathe([[0, 0], [rr * (big ? 0.3 : 0.11), 0], [rr * (big ? 0.26 : 0.1), 0.03], [0, 0.036]], 20), big ? M.rim : M.chrome, x, y, z + s * tw * 0.68, ry, rx);
}
const plateTex = (K, txt, bg = "#f2e04a") => K.canvasTex(256, 64, (g) => { g.fillStyle = bg; g.fillRect(0, 0, 256, 64); g.strokeStyle = "#111"; g.lineWidth = 4; g.strokeRect(3, 3, 250, 58); g.fillStyle = "#111"; g.font = "900 44px Helvetica, Arial"; g.textAlign = "center"; g.textBaseline = "middle"; g.fillText(txt, 128, 35); });
const mats = (K) => ({ tire: K.flat(0x0b0b0c, { rough: 0.88, detail: "rubber" }), rim: K.flat(0xa9adb2, { rough: 0.28, metal: 1 }), disc: K.flat(0x4a4c50, { rough: 0.5, metal: 1 }), chrome: K.flat(0xd0d2d4, { rough: 0.12, metal: 1 }), trim: K.flat(0x0d0d0e, { rough: 0.6, detail: "plastic" }), lens: K.flat(0xe6ecf0, { rough: 0.08, metal: 0.6 }), seat: K.flat(0x2a2a30, { rough: 0.9 }), amber: K.flat(0xd87a12, { rough: 0.2 }) });
const rndPlate = (r) => "ABCDEFGHJKLMNPRSTUVWXYZ"[Math.floor(r() * 23)] + "ABCDEFGHJKLMNPRSTUVWXYZ"[Math.floor(r() * 23)] + " " + Math.floor(1000 + r() * 8999);
export function buildCar(K, kind, paint, o, r) {
  const spec = CARS[kind], g = new THREE.Group(), M = mats(K), B = K.builder(), f = spec.L / 2, W = spec.W, van = kind === "van";
  const bl = blenderBody(van ? "car_van" : "car_sedan"), geo = bl ? { body: bl.paint, glass: bl.glass } : carBody(spec), bm = new THREE.Mesh(geo.body, paint), gm = new THREE.Mesh(geo.glass, o.glass); if (bl && kind === "taxi") { bm.scale.set(4.72 / 4.62, 1, 0.88 / 0.9); gm.scale.copy(bm.scale); } bm.castShadow = bm.receiveShadow = true; g.add(bm, gm);
  const cabin = spec.st.filter((s) => s[4] > 0), cx0 = cabin[0][0], cx1 = cabin[cabin.length - 1][0], belt = cabin[0][3], roof = cabin[0][4];
  for (const ax of spec.axles) for (const s of [-1, 1]) { wheelParts(B, M, spec.wheel, 0.22, ax, spec.wheel, s * (W - 0.085), s); B.add(new THREE.CircleGeometry(spec.wheel + 0.075, 28), M.trim, ax, spec.wheel + 0.01, s * (W - 0.2), s > 0 ? 0 : Math.PI); B.add(new THREE.TorusGeometry(spec.wheel + 0.07, 0.022, 8, 24, Math.PI), M.trim, ax, spec.wheel - 0.005, s * (W + 0.0), 0); }
  // closed underbody and nose / tail aprons: the lofted shell ends above the bumpers, which left see-through gaps at the corners
  { const nose = spec.st[spec.st.length - 1], tail = spec.st[0], ends = [[f, nose[2], 1], [-f, tail[2], -1]];
    B.box(M.trim, spec.L * 0.86, 0.34, W * 1.5, 0, 0.2, 0, { bev: 0 });
    for (const [x, y0, s] of bl ? [] : ends) { B.box(paint, 0.42, Math.max(0.06, y0 + 0.05 - 0.2), W * 1.7, x - s * 0.43, 0.2, 0, { bev: 0.03 }); B.box(M.trim, 0.36, 0.3, W * 1.42, x - s * 0.24, 0.17, 0, { bev: 0.02 }); } }
  // sills, bumpers, grille, intakes
  for (const s of [-1, 1]) B.box(M.trim, spec.axles[1] - spec.axles[0] - spec.wheel * 2 - 0.2, 0.07, 0.05, (spec.axles[0] + spec.axles[1]) / 2, 0.2, s * (W - 0.03));
  const fy = spec.st[spec.st.length - 1][3], ry0 = spec.st[0][3]; B.box(M.trim, 0.1, 0.16, W * 1.5, f - 0.04, 0.3, 0, { bev: 0.03 }); B.box(M.trim, 0.1, 0.14, W * 1.55, -f + 0.04, 0.34, 0, { bev: 0.03 }); B.box(M.trim, 0.05, 0.12, W * 0.95, f + 0.005, 0.5, 0, { bev: 0.015 }); for (let i = 0; i < 4; i++) B.box(M.chrome, 0.012, 0.012, W * 0.9, f + 0.032, 0.455 + i * 0.03, 0, { bev: 0.004 });
  for (const s of [-1, 1]) { B.box(M.trim, 0.04, 0.07, 0.2, f + 0.0, 0.3, s * W * 0.6, { bev: 0.012 }); B.add(lathe([[0, 0], [0.035, 0], [0.04, 0.006], [0.04, 0.02], [0, 0.02]], 14), M.lens, f + 0.012, 0.3, s * W * 0.6, 0, 0, -HP);
    // lamp clusters: chrome bezel, clear lens over the emitter
    B.box(M.chrome, 0.06, 0.11, 0.36, f - 0.1, fy + 0.005, s * W * 0.6, { bev: 0.02, ry: s * 0.35 }); B.box(o.head, 0.05, 0.075, 0.2, f - 0.078, fy + 0.012, s * W * 0.56, { bev: 0.015, ry: s * 0.35 }); B.box(M.amber, 0.04, 0.07, 0.09, f - 0.135, fy + 0.012, s * W * 0.8, { bev: 0.012, ry: s * 0.6 });
    B.box(o.tail, 0.05, 0.1, 0.3, -f + 0.07, ry0 + 0.01, s * W * 0.62, { bev: 0.02, ry: -s * 0.3 }); B.box(M.lens, 0.045, 0.045, 0.1, -f + 0.066, ry0 - 0.02, s * W * 0.42, { bev: 0.012 }); B.box(M.amber, 0.04, 0.045, 0.08, -f + 0.1, ry0 + 0.03, s * W * 0.83, { bev: 0.012, ry: -s * 0.6 });
    // mirrors
    B.add(loft([{ p: [cx0 + (van ? 3.95 : 1.62), belt + 0.06, s * (W + 0.02)], r: [0.03, 0.02] }, { p: [cx0 + (van ? 3.93 : 1.6), belt + 0.09, s * (W + 0.1)], r: [0.05, 0.035] }, { p: [cx0 + (van ? 3.9 : 1.57), belt + 0.1, s * (W + 0.2)], r: [0.07, 0.035] }], { seg: 12, up: [1, 0, 0] }), paint, 0, 0, 0);
    // door seams + handles
    const doors = van ? [cx0 + 0.9, cx0 + 2.2, cx0 + 3.3, cx0 + 4.1] : [cx0 + 0.05, (cx0 + cx1) / 2 - 0.02, cx1 - 0.25]; for (const dx of doors) B.box(M.trim, 0.012, belt - 0.32, 0.006, dx, 0.3, s * (W + 0.001), { bev: 0 }); for (const dx of doors.slice(1)) { B.box(M.chrome, 0.13, 0.022, 0.02, dx - 0.14, belt - 0.1, s * (W + 0.006), { bev: 0.008 }); }
    B.box(M.chrome, cx1 - cx0 - 0.3, 0.014, 0.008, (cx0 + cx1) / 2, belt + 0.004, s * (W * 0.975 + 0.003), { bev: 0.004 });
    B.box(M.trim, 0.5, 0.012, 0.016, cx1 + 0.42, belt + 0.05 - 0.02, s * 0.3, { bev: 0.004, ry: s * 0.3, rz: -0.12 }); // wipers
  }
  // interior: dash, wheel, seats visible through the glass
  B.box(M.trim, 0.4, 0.2, W * 1.7, cx1 - 0.25, belt - 0.2, 0, { bev: 0.05 }); B.add(new THREE.TorusGeometry(0.17, 0.016, 8, 22), M.trim, cx1 - 0.48, belt + 0.02, van ? 0.5 : 0.42, HP, 0.35); for (const sx of van ? [cx1 - 0.9, cx1 - 1.8, cx1 - 2.7, cx1 - 3.6] : [cx1 - 0.95, cx0 + 0.35]) for (const s of [-1, 1]) { B.box(M.seat, 0.14, 0.62, 0.46, sx - 0.2, belt - 0.42, s * W * 0.45, { bev: 0.05, rz: -0.12 }); B.box(M.seat, 0.1, 0.16, 0.24, sx - 0.25, belt + 0.2, s * W * 0.45, { bev: 0.04 }); }
  B.add(lathe([[0, 0], [0.03, 0], [0.03, 0.2], [0.024, 0.2], [0.024, 0.01], [0, 0.01]], 12), M.chrome, -f + 0.02, 0.26, -W * 0.5, 0, 0, HP); // exhaust
  for (const [x, ry, y] of [[f + 0.035, HP, 0.4], [-f - 0.012, -HP, ry0 - 0.12]]) { const p = new THREE.Mesh(new THREE.PlaneGeometry(0.44, 0.11), new THREE.MeshStandardMaterial({ map: plateTex(K, rndPlate(r), x > 0 ? "#f4f4f0" : "#f2e04a"), roughness: 0.5 })); p.position.set(x, y, 0); p.rotation.y = ry; g.add(p); }
  if (o.roof) { const rg = carBody({ st: cabin.map((s) => [s[0], s[1] * 0.76, s[4] - 0.03, s[4] + 0.0, 0]) }); const rm = new THREE.Mesh(rg.body, o.roof); rm.position.y = 0.003; g.add(rm); }
  if (kind === "taxi") { B.box(M.trim, 0.3, 0.02, 0.2, -0.3, roof + 0.012, 0, { bev: 0.006 }); const t = K.canvasTex(128, 48, (c) => { c.fillStyle = "#fff6c8"; c.fillRect(0, 0, 128, 48); c.fillStyle = "#b01c16"; c.font = "900 30px Helvetica"; c.textAlign = "center"; c.fillText("TAXI", 64, 35); }); const sg = new THREE.Mesh(rbox(0.1, 0.12, 0.34, 0.025), K.glow(0xfff2c0, 0.9, { map: t })); sg.position.set(-0.3, roof + 0.09, 0); g.add(sg); }
  B.finish(g); return g;
}
// double-decker bus / tram. forward = +x
export function buildBus(K, tram, paintHex, r) {
  const g = new THREE.Group(), B = K.builder(), M = mats(K), L = tram ? 9 : 11.2, W = tram ? 1.98 : 2.5, H = tram ? 4.25 : 4.38, f = L / 2, hw = W / 2;
  const paint = K.flat(paintHex, { rough: 0.34, metal: 0.4, wet: 1, coat: 1 }), cream = K.flat(tram ? 0xcfc7a8 : 0xe8e2cc, { rough: 0.4, metal: 0.2, wet: 1 }), gasket = M.trim, frame = tram ? K.mat("wood", { color: 0x6a4a2c, rough: 0.6 }) : K.flat(0x16171a, { rough: 0.45, metal: 0.6 }), pane = K.flat(0x0e151b, { rough: 0.06, metal: 0.75, detail: 'glass' }), head = K.glow(0xfff4d8, 40, { night: true }), tail = K.glow(0xff1a10, 2.5), inner = K.glow(0xffe9c0, 0.035, { night: true }), board = (txt, w, h, col = "#ffb020") => K.glow(0xffffff, 0.5, { map: K.canvasTex(512, Math.round((512 * h) / w), (c, cw, ch) => { c.fillStyle = "#050505"; c.fillRect(0, 0, cw, ch); c.fillStyle = col; c.font = `900 ${ch * 0.62}px 'PingFang HK','PingFang SC',sans-serif`; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(txt, cw / 2, ch / 2 + 2); }) });
  const y0 = 0.36, lowTop = 2.28, band = 0.3, upBot = lowTop + band;
  // shell: skirt, lower deck, waist band, upper deck, roof — each a chamfered slab so panel breaks catch light
  B.box(M.trim, L - 0.1, 0.22, W - 0.06, 0, y0 - 0.08, 0, { bev: 0.04 }); B.box(paint, L, lowTop - y0 - 0.1, W, 0, y0 + 0.1, 0, { bev: 0.07 }); B.box(cream, L + 0.012, band, W + 0.012, 0, lowTop, 0, { bev: 0.03 }); B.box(paint, L, H - upBot - 0.12, W, 0, upBot, 0, { bev: 0.09 }); B.box(tram ? K.flat(0x2a3028, { rough: 0.6 }) : cream, L - 0.16, 0.14, W - 0.14, 0, H - 0.14, 0, { bev: 0.06 });
  // glazing: individual panes in gaskets between pillars, lit from inside at night
  const row = (ya, yb, x0, x1, n, s) => { const pw = (x1 - x0) / n; B.box(inner, x1 - x0, yb - ya, 0.02, (x0 + x1) / 2, ya, s * (hw - 0.05), { bev: 0 }); for (let i = 0; i < n; i++) { const cx = x0 + (i + 0.5) * pw; B.box(gasket, pw - 0.07, yb - ya, 0.03, cx, ya, s * (hw + 0.002), { bev: 0.012 }); B.box(pane, pw - 0.13, yb - ya - 0.06, 0.02, cx, ya + 0.03, s * (hw + 0.012), { bev: 0.008 }); if (i % 2 === 0) B.box(frame, pw - 0.13, 0.03, 0.03, cx, ya + (yb - ya) * 0.72, s * (hw + 0.016), { bev: 0.006 }); } for (let i = 0; i <= n; i++) B.box(frame, 0.07, yb - ya + 0.04, 0.04, x0 + i * pw, ya - 0.02, s * (hw + 0.004), { bev: 0.01 }); };
  for (const s of [-1, 1]) { row(upBot + 0.42, H - 0.42, -f + 0.3, f - 0.3, tram ? 8 : 10, s); const door = s > 0; row(1.2, lowTop - 0.12, -f + 0.3, door ? f - 3.0 : f - 0.5, tram ? 6 : door ? 7 : 9, s);
    if (door) for (const [dx, dw] of tram ? [[f - 1.0, 0.9]] : [[f - 1.35, 1.25], [0.2, 1.25]]) { B.box(gasket, dw, lowTop - y0 - 0.25, 0.04, dx, y0 + 0.1, s * (hw + 0.004), { bev: 0.012 }); for (const q of [-1, 1]) { B.box(pane, dw / 2 - 0.07, lowTop - y0 - 0.5, 0.02, dx + q * dw * 0.25, y0 + 0.32, s * (hw + 0.02), { bev: 0.008 }); B.box(M.chrome, 0.02, 0.5, 0.03, dx + q * 0.05, y0 + 0.9, s * (hw + 0.04), { bev: 0.008 }); } }
    // waist advert / fleet name, rub rail, wheel arches, side markers
    const ad = new THREE.Mesh(new THREE.PlaneGeometry(tram ? 4.6 : 6, band - 0.06), new THREE.MeshStandardMaterial({ map: K.canvasTex(1024, 48, (c) => { c.fillStyle = "rgba(0,0,0,0)"; c.fillStyle = "#1c1c1c"; c.font = "900 34px 'PingFang HK','PingFang SC',sans-serif"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillText(tram ? "城 市 電 車   CITY TRAMWAYS" : "城 市 巴 士   CITY BUS", 512, 26); }), transparent: true, roughness: 0.5, polygonOffset: true, polygonOffsetFactor: -2 })); ad.position.set(0, lowTop + band / 2, s * (hw + 0.008)); ad.rotation.y = s > 0 ? 0 : Math.PI; g.add(ad);
    B.box(M.trim, L - 0.3, 0.05, 0.03, 0, 1.02, s * (hw + 0.006), { bev: 0.012 });
    for (const ax of tram ? [-f + 2.2, f - 2.2] : [-f + 2.6, -f + 3.75, f - 2.5]) { const wr = tram ? 0.4 : 0.5; wheelParts(B, M, wr, 0.3, ax, wr, s * (hw - 0.2), s, true); B.add(new THREE.CircleGeometry(wr + 0.1, 28), M.trim, ax, wr + 0.03, s * (hw - 0.02), s > 0 ? 0 : Math.PI); B.add(new THREE.TorusGeometry(wr + 0.1, 0.03, 8, 24, Math.PI), paint, ax, wr + 0.02, s * (hw + 0.004)); if (tram) B.box(M.trim, 1.3, 0.34, 0.06, ax, y0 - 0.12, s * (hw - 0.03), { bev: 0.02 }); }
    for (const x of [-f + 0.5, 0, f - 0.5]) B.box(M.amber, 0.1, 0.04, 0.02, x, 1.08, s * (hw + 0.012), { bev: 0.008 });
    // mirrors on arms
    B.box(M.trim, 0.03, 0.03, 0.42, f - 0.12, lowTop - 0.2, s * (hw + 0.2), { bev: 0.01 }); B.box(M.trim, 0.06, 0.34, 0.2, f - 0.1, lowTop - 0.62, s * (hw + 0.38), { bev: 0.03 }); }
  // front: windscreens, destination display, lamps, grille, wipers, bumper
  B.box(gasket, 0.05, lowTop - 1.12, W - 0.24, f + 0.004, 1.06, 0, { bev: 0.015 }); B.box(pane, 0.03, lowTop - 1.24, W - 0.36, f + 0.03, 1.12, 0, { bev: 0.01 }); B.box(gasket, 0.05, H - upBot - 0.86, W - 0.24, f + 0.004, upBot + 0.4, 0, { bev: 0.015 }); B.box(pane, 0.03, H - upBot - 0.98, W - 0.36, f + 0.03, upBot + 0.46, 0, { bev: 0.01 }); B.box(frame, 0.05, H - upBot - 0.9, 0.06, f + 0.03, upBot + 0.42, 0, { bev: 0.012 });
  B.box(gasket, 0.05, 0.3, W * 0.72, f + 0.01, lowTop - 0.02, 0, { bev: 0.012 }); B.box(board(tram ? "環線" : "1A  渡雲碼頭", W * 0.66, 0.24), 0.02, 0.24, W * 0.66, f + 0.04, lowTop + 0.01, 0, { bev: 0 });
  B.box(M.trim, 0.14, 0.26, W + 0.04, f - 0.02, y0 - 0.04, 0, { bev: 0.05 }); B.box(M.trim, 0.14, 0.26, W + 0.04, -f + 0.02, y0 - 0.04, 0, { bev: 0.05 }); for (let i = 0; i < 5; i++) B.box(M.trim, 0.02, 0.022, W * 0.5, f + 0.012, 0.56 + i * 0.05, 0, { bev: 0.006 });
  for (const s of tram ? [0] : [-1, 1]) { B.add(lathe([[0, 0], [0.1, 0], [0.11, 0.012], [0.11, 0.04], [0.095, 0.05], [0, 0.05]], 24), M.chrome, f - 0.01, 0.78, s * hw * 0.68, 0, 0, -HP); B.add(lathe([[0, 0.05], [0.09, 0.05], [0.07, 0.062], [0, 0.068]], 24), head, f - 0.01, 0.78, s * hw * 0.68, 0, 0, -HP); B.box(M.amber, 0.03, 0.07, 0.14, f + 0.012, 0.6, s * hw * 0.7, { bev: 0.012 }); B.box(M.trim, 0.012, 0.016, 0.8, f + 0.055, 1.2, s * 0.45 || 0.2, { bev: 0.004, rx: 0.5 }); }
  const fp = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.12), new THREE.MeshStandardMaterial({ map: plateTex(K, rndPlate(r), "#f4f4f0"), roughness: 0.5 })); fp.position.set(f + 0.055, 0.45, 0); fp.rotation.y = HP; g.add(fp);
  // rear: engine louvres, window, lamp stacks
  for (let i = 0; i < 9; i++) B.box(M.trim, 0.03, 0.03, W * 0.6, -f - 0.006, 0.62 + i * 0.07, 0, { bev: 0.008, rz: 0.4 }); B.box(gasket, 0.05, 0.7, W - 0.5, -f - 0.004, upBot + 0.5, 0, { bev: 0.015 }); B.box(pane, 0.03, 0.6, W - 0.62, -f - 0.03, upBot + 0.55, 0, { bev: 0.01 });
  for (const s of [-1, 1]) { B.box(M.trim, 0.04, 0.5, 0.18, -f - 0.006, 0.7, s * hw * 0.82, { bev: 0.015 }); B.box(tail, 0.03, 0.16, 0.13, -f - 0.03, 0.98, s * hw * 0.82, { bev: 0.012 }); B.box(M.amber, 0.03, 0.12, 0.13, -f - 0.03, 0.84, s * hw * 0.82, { bev: 0.012 }); B.box(M.lens, 0.03, 0.1, 0.13, -f - 0.03, 0.72, s * hw * 0.82, { bev: 0.012 }); }
  B.box(board(tram ? "120" : "1A", 0.5, 0.24), 0.02, 0.24, 0.5, -f - 0.02, lowTop + 0.01, 0, { bev: 0 });
  // roof gear
  if (tram) { B.box(M.trim, 0.5, 0.1, 0.4, -0.6, H, 0, { bev: 0.03 }); B.add(loft([{ p: [-0.6, H + 0.08, 0], r: 0.025 }, { p: [-2.2, H + 1.1, 0], r: 0.02 }, { p: [-3.4, H + 1.75, 0], r: 0.016 }], { seg: 8 }), M.trim); B.add(lathe([[0, 0], [0.07, 0], [0.07, 0.03], [0, 0.03]], 12), M.chrome, -3.4, H + 1.75, 0, 0, HP); }
  else { B.box(cream, 2.6, 0.2, 1.7, -1.5, H - 0.02, 0, { bev: 0.06 }); for (let i = 0; i < 6; i++) B.box(M.trim, 0.04, 0.03, 1.5, -2.5 + i * 0.4, H + 0.17, 0, { bev: 0.01 }); for (const x of [1.5, 3.4]) B.box(M.trim, 0.7, 0.05, 0.7, x, H - 0.01, 0, { bev: 0.02 }); }
  B.finish(g); return { g, L, W };
}
