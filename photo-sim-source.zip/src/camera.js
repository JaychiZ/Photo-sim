// Camera bodies, lenses and the exposure maths. Specs are the makers' published figures, rounded; the simulation only uses
// sensor size, ISO range, fastest shutter, burst rate, stabilisation and the lens' focal range / maximum aperture / close focus.
import { EXTRA_BODIES, EXTRA_LENSES } from "./gear.js";
export const BODIES = [
  // id, brand, name, mount, sensor w×h mm, MP, ISO min/max, fastest shutter (1/x), fps, IBIS stops
  ["a7m4", "Sony", "α7 IV", "E", 35.9, 23.9, 33, 100, 51200, 8000, 10, 5.5], ["a7rm5", "Sony", "α7R V", "E", 35.7, 23.8, 61, 100, 32000, 8000, 10, 8], ["a1", "Sony", "α1", "E", 35.9, 24, 50, 100, 32000, 32000, 30, 5.5],
  ["a7sm3", "Sony", "α7S III", "E", 35.6, 23.8, 12, 80, 102400, 8000, 10, 5.5], ["a7cm2", "Sony", "α7C II", "E", 35.9, 23.9, 33, 100, 51200, 4000, 10, 7], ["a6700", "Sony", "α6700", "E", 23.3, 15.5, 26, 100, 32000, 8000, 11, 5],
  ["r5", "Canon", "EOS R5", "RF", 36, 24, 45, 100, 51200, 8000, 20, 8], ["r6m2", "Canon", "EOS R6 Mark II", "RF", 35.9, 23.9, 24, 100, 102400, 16000, 40, 8], ["r8", "Canon", "EOS R8", "RF", 35.9, 23.9, 24, 100, 102400, 16000, 40, 0],
  ["r7", "Canon", "EOS R7", "RF", 22.3, 14.8, 32.5, 100, 32000, 16000, 30, 7],
  ["z8", "Nikon", "Z8", "Z", 35.9, 23.9, 45.7, 64, 25600, 32000, 20, 6], ["z6m3", "Nikon", "Z6III", "Z", 35.9, 23.9, 24.5, 100, 64000, 16000, 20, 8], ["zf", "Nikon", "Zf", "Z", 35.9, 23.9, 24.5, 100, 64000, 8000, 14, 8],
  ["zfc", "Nikon", "Z fc", "Z", 23.5, 15.7, 20.9, 100, 51200, 4000, 11, 0],
  ["xt5", "Fujifilm", "X-T5", "X", 23.5, 15.7, 40.2, 125, 12800, 8000, 15, 7], ["xh2s", "Fujifilm", "X-H2S", "X", 23.5, 15.6, 26.2, 160, 12800, 8000, 40, 7], ["x100vi", "Fujifilm", "X100VI", "FIX", 23.5, 15.7, 40.2, 125, 12800, 4000, 11, 6],
  ["gfx100s2", "Fujifilm", "GFX100S II", "G", 43.8, 32.9, 102, 80, 12800, 4000, 7, 8],
  ["m11", "Leica", "M11", "M", 36, 24, 60, 64, 50000, 4000, 4.5, 0], ["q3", "Leica", "Q3", "FIX", 36, 24, 60, 50, 100000, 2000, 15, 4],
  ["x2d", "Hasselblad", "X2D 100C", "XCD", 43.8, 32.9, 100, 64, 25600, 2000, 3.3, 7],
  ["s5m2", "Panasonic", "LUMIX S5II", "L", 35.6, 23.8, 24.2, 100, 51200, 8000, 9, 5], ["om1m2", "OM System", "OM-1 Mark II", "MFT", 17.4, 13, 20.4, 200, 25600, 8000, 120, 8.5],
  ["gr3x", "Ricoh", "GR IIIx", "FIX", 23.5, 15.6, 24.2, 100, 102400, 4000, 4, 4], ["rx100m7", "Sony", "RX100 VII", "FIX", 13.2, 8.8, 20.1, 100, 12800, 2000, 20, 4],
  ["ip16p", "Apple", "iPhone 16 Pro（主摄）", "FIX", 9.8, 7.3, 48, 50, 12800, 8000, 10, 4],
].map(([id, brand, name, mount, sw, sh, mp, isoMin, isoMax, tMin, fps, ibis]) => ({ id, brand, name, mount, sw, sh, mp, isoMin, isoMax, tMin: 1 / tMin, fps, ibis }));
const FIXED = { x100vi: ["23mm F2（定焦）", 23, 23, 2, 2, 16, 0.1, 9], q3: ["Summilux 28mm F1.7 ASPH.（定焦）", 28, 28, 1.7, 1.7, 16, 0.17, 9], gr3x: ["GR 26.1mm F2.8（定焦）", 26.1, 26.1, 2.8, 2.8, 16, 0.12, 9],
  rx100m7: ["ZEISS 9–72mm F2.8–4.5", 9, 72, 2.8, 4.5, 11, 0.08, 7], ip16p: ["6.86mm F1.78（定焦，光圈不可调）", 6.86, 6.86, 1.78, 1.78, 1.78, 0.2, 0] };
// name, focal min, max, max aperture at wide, at tele, min aperture, close focus (m), blades
const L = {
  E: [["FE 14mm F1.8 GM", 14, 14, 1.8, 1.8, 16, 0.25, 9], ["FE 16-35mm F2.8 GM II", 16, 35, 2.8, 2.8, 22, 0.22, 11], ["FE 24-70mm F2.8 GM II", 24, 70, 2.8, 2.8, 22, 0.21, 11], ["FE 24-105mm F4 G OSS", 24, 105, 4, 4, 22, 0.38, 9],
    ["FE 35mm F1.4 GM", 35, 35, 1.4, 1.4, 16, 0.27, 11], ["FE 50mm F1.2 GM", 50, 50, 1.2, 1.2, 16, 0.4, 11], ["FE 85mm F1.4 GM II", 85, 85, 1.4, 1.4, 16, 0.85, 11], ["FE 90mm F2.8 Macro G OSS", 90, 90, 2.8, 2.8, 22, 0.28, 9],
    ["FE 70-200mm F2.8 GM OSS II", 70, 200, 2.8, 2.8, 22, 0.4, 11], ["FE 200-600mm F5.6-6.3 G OSS", 200, 600, 5.6, 6.3, 36, 2.4, 11], ["FE 400mm F2.8 GM OSS", 400, 400, 2.8, 2.8, 22, 2.7, 11]],
  RF: [["RF16mm F2.8 STM", 16, 16, 2.8, 2.8, 22, 0.13, 7], ["RF15-35mm F2.8 L IS USM", 15, 35, 2.8, 2.8, 22, 0.28, 9], ["RF24-70mm F2.8 L IS USM", 24, 70, 2.8, 2.8, 22, 0.21, 9], ["RF28-70mm F2 L USM", 28, 70, 2, 2, 22, 0.39, 9],
    ["RF24-105mm F4 L IS USM", 24, 105, 4, 4, 22, 0.45, 9], ["RF35mm F1.8 MACRO IS STM", 35, 35, 1.8, 1.8, 22, 0.17, 9], ["RF50mm F1.2 L USM", 50, 50, 1.2, 1.2, 16, 0.4, 10], ["RF85mm F1.2 L USM", 85, 85, 1.2, 1.2, 16, 0.85, 9],
    ["RF100mm F2.8 L MACRO IS USM", 100, 100, 2.8, 2.8, 32, 0.26, 9], ["RF70-200mm F2.8 L IS USM", 70, 200, 2.8, 2.8, 32, 0.7, 9], ["RF100-500mm F4.5-7.1 L IS USM", 100, 500, 4.5, 7.1, 32, 0.9, 9], ["RF600mm F4 L IS USM", 600, 600, 4, 4, 32, 4.2, 9]],
  Z: [["Z 20mm f/1.8 S", 20, 20, 1.8, 1.8, 16, 0.2, 9], ["Z 14-24mm f/2.8 S", 14, 24, 2.8, 2.8, 22, 0.28, 9], ["Z 24-70mm f/2.8 S", 24, 70, 2.8, 2.8, 22, 0.38, 9], ["Z 24-120mm f/4 S", 24, 120, 4, 4, 22, 0.35, 9],
    ["Z 35mm f/1.8 S", 35, 35, 1.8, 1.8, 16, 0.25, 9], ["Z 50mm f/1.2 S", 50, 50, 1.2, 1.2, 16, 0.45, 9], ["Z 85mm f/1.2 S", 85, 85, 1.2, 1.2, 16, 0.85, 11], ["Z 135mm f/1.8 S Plena", 135, 135, 1.8, 1.8, 16, 0.82, 11],
    ["Z MC 105mm f/2.8 VR S", 105, 105, 2.8, 2.8, 32, 0.29, 9], ["Z 70-200mm f/2.8 VR S", 70, 200, 2.8, 2.8, 22, 0.5, 9], ["Z 180-600mm f/5.6-6.3 VR", 180, 600, 5.6, 6.3, 32, 1.3, 9], ["Z 400mm f/4.5 VR S", 400, 400, 4.5, 4.5, 32, 2.5, 9],
    ["Z 600mm f/6.3 VR S", 600, 600, 6.3, 6.3, 32, 4, 9]],
  X: [["XF8mm F3.5 R WR", 8, 8, 3.5, 3.5, 22, 0.18, 9], ["XF10-24mm F4 R OIS WR", 10, 24, 4, 4, 22, 0.24, 7], ["XF16-55mm F2.8 R LM WR II", 16, 55, 2.8, 2.8, 22, 0.3, 11], ["XF23mm F1.4 R LM WR", 23, 23, 1.4, 1.4, 16, 0.19, 9],
    ["XF33mm F1.4 R LM WR", 33, 33, 1.4, 1.4, 16, 0.3, 9], ["XF56mm F1.2 R WR", 56, 56, 1.2, 1.2, 16, 0.5, 11], ["XF80mm F2.8 R LM OIS WR Macro", 80, 80, 2.8, 2.8, 22, 0.25, 9], ["XF50-140mm F2.8 R LM OIS WR", 50, 140, 2.8, 2.8, 22, 1, 7],
    ["XF150-600mm F5.6-8 R LM OIS WR", 150, 600, 5.6, 8, 22, 2.4, 9]],
  G: [["GF20-35mm F4 R WR", 20, 35, 4, 4, 22, 0.35, 9], ["GF32-64mm F4 R LM WR", 32, 64, 4, 4, 32, 0.5, 9], ["GF55mm F1.7 R WR", 55, 55, 1.7, 1.7, 22, 0.5, 11], ["GF80mm F1.7 R WR", 80, 80, 1.7, 1.7, 22, 0.7, 9], ["GF110mm F2 R LM WR", 110, 110, 2, 2, 22, 0.9, 9],
    ["GF120mm F4 R LM OIS WR Macro", 120, 120, 4, 4, 32, 0.45, 9], ["GF250mm F4 R LM OIS WR", 250, 250, 4, 4, 32, 1.4, 9], ["GF500mm F5.6 R LM OIS WR", 500, 500, 5.6, 5.6, 32, 2.75, 9]],
  XCD: [["XCD 25mm F2.5 V", 25, 25, 2.5, 2.5, 32, 0.25, 9], ["XCD 38mm F2.5 V", 38, 38, 2.5, 2.5, 32, 0.3, 9], ["XCD 55mm F2.5 V", 55, 55, 2.5, 2.5, 32, 0.45, 9], ["XCD 90mm F2.5 V", 90, 90, 2.5, 2.5, 32, 0.67, 9], ["XCD 35-75mm F3.5-4.5", 35, 75, 3.5, 4.5, 32, 0.42, 8],
    ["XCD 135mm F2.8", 135, 135, 2.8, 2.8, 32, 1.05, 8]],
  M: [["Summilux-M 21mm f/1.4 ASPH.", 21, 21, 1.4, 1.4, 16, 0.7, 11], ["Elmarit-M 28mm f/2.8 ASPH.", 28, 28, 2.8, 2.8, 22, 0.7, 10], ["Summilux-M 35mm f/1.4 ASPH.", 35, 35, 1.4, 1.4, 16, 0.4, 11], ["Summicron-M 50mm f/2", 50, 50, 2, 2, 16, 0.7, 8],
    ["Noctilux-M 50mm f/0.95 ASPH.", 50, 50, 0.95, 0.95, 16, 1, 11], ["APO-Summicron-M 90mm f/2 ASPH.", 90, 90, 2, 2, 16, 1, 9]],
  L: [["Sigma 14mm F1.4 DG DN Art", 14, 14, 1.4, 1.4, 16, 0.3, 11], ["LUMIX S 20-60mm F3.5-5.6", 20, 60, 3.5, 5.6, 22, 0.15, 9], ["LUMIX S PRO 24-70mm F2.8", 24, 70, 2.8, 2.8, 22, 0.37, 11], ["LUMIX S 50mm F1.8", 50, 50, 1.8, 1.8, 22, 0.45, 9],
    ["LUMIX S 85mm F1.8", 85, 85, 1.8, 1.8, 22, 0.8, 9], ["Sigma 105mm F2.8 DG DN Macro Art", 105, 105, 2.8, 2.8, 22, 0.295, 9], ["LUMIX S PRO 70-200mm F2.8 O.I.S.", 70, 200, 2.8, 2.8, 22, 0.95, 11]],
  MFT: [["M.Zuiko 7-14mm F2.8 PRO", 7, 14, 2.8, 2.8, 22, 0.2, 7], ["M.Zuiko 12-40mm F2.8 PRO II", 12, 40, 2.8, 2.8, 22, 0.2, 7], ["M.Zuiko 25mm F1.2 PRO", 25, 25, 1.2, 1.2, 16, 0.3, 9], ["M.Zuiko 45mm F1.2 PRO", 45, 45, 1.2, 1.2, 16, 0.5, 9],
    ["M.Zuiko 60mm F2.8 Macro", 60, 60, 2.8, 2.8, 22, 0.19, 7], ["M.Zuiko 40-150mm F2.8 PRO", 40, 150, 2.8, 2.8, 22, 0.7, 9], ["M.Zuiko 300mm F4 IS PRO", 300, 300, 4, 4, 22, 1.4, 9], ["M.Zuiko 150-400mm F4.5 TC1.25x IS PRO", 150, 400, 4.5, 4.5, 22, 1.3, 9]],
};
const mk = ([name, f0, f1, n0, n1, nMin, close, blades]) => ({ name, f0, f1, n0, n1, nMin, close, blades });
for (const [m, list] of Object.entries(EXTRA_LENSES)) L[m] = [...(L[m] || []), ...list]; for (const m in L) L[m].sort((a, b) => a[1] - b[1] || a[2] - b[2] || a[3] - b[3]);
{ const order = ["Sony", "Canon", "Nikon", "Fujifilm", "Leica", "Hasselblad", "Panasonic", "OM System", "Olympus", "Sigma", "Pentax", "Ricoh", "DJI", "Apple", "华为", "小米", "Samsung", "vivo"]; BODIES.push(...EXTRA_BODIES); BODIES.sort((a, b) => order.indexOf(a.brand) - order.indexOf(b.brand)); }
export const lensesFor = (body) => (body.mount === "FIX" ? [mk(FIXED[body.id] || body.fix)] : L[body.mount].map(mk));
export const GEAR_COUNT = { bodies: BODIES.length, lenses: Object.values(L).reduce((n, l) => n + l.length, 0) + BODIES.filter((b) => b.mount === "FIX").length };
export const MOUNT_NAME = { E: "索尼 E 卡口", RF: "佳能 RF 卡口", Z: "尼康 Z 卡口", X: "富士 X 卡口", G: "富士 G 卡口", XCD: "哈苏 XCD 卡口", M: "徕卡 M 卡口", L: "L 卡口", MFT: "M4/3 卡口", EF: "佳能 EF 卡口（单反）", F: "尼康 F 卡口（单反）", K: "宾得 K 卡口（单反）", FIX: "固定镜头" };

export const APERTURES = [0.95, 1, 1.1, 1.2, 1.4, 1.6, 1.7, 1.8, 2, 2.2, 2.5, 2.8, 3.2, 3.5, 4, 4.5, 5, 5.6, 6.3, 7.1, 8, 9, 10, 11, 13, 14, 16, 18, 20, 22, 25, 29, 32, 36];
const SH_LONG = [30, 25, 20, 15, 13, 10, 8, 6, 5, 4, 3.2, 2.5, 2, 1.6, 1.3, 1, 0.8, 0.6, 0.5, 0.4, 0.3];
const SH_FRAC = [4, 5, 6, 8, 10, 13, 15, 20, 25, 30, 40, 50, 60, 80, 100, 125, 160, 200, 250, 320, 400, 500, 640, 800, 1000, 1250, 1600, 2000, 2500, 3200, 4000, 5000, 6400, 8000, 10000, 12800, 16000, 20000, 25600, 32000];
export const SHUTTERS = [...SH_LONG.map((s) => ({ t: s, label: s + '"' })), ...SH_FRAC.map((d) => ({ t: 1 / d, label: "1/" + d }))];
export const ISOS = [50, 64, 80, 100, 125, 160, 200, 250, 320, 400, 500, 640, 800, 1000, 1250, 1600, 2000, 2500, 3200, 4000, 5000, 6400, 8000, 10000, 12800, 16000, 20000, 25600, 32000, 40000, 51200, 64000, 80000, 102400];
export const STYLES = { std: { name: "标准", contrast: 1.0, sat: 1.0, mono: 0, fade: 0, tint: [1, 1, 1] }, vivid: { name: "鲜艳", contrast: 1.08, sat: 1.22, mono: 0, fade: 0, tint: [1, 1, 1] }, neutral: { name: "中性", contrast: 0.96, sat: 0.94, mono: 0, fade: 0, tint: [1, 1, 1] },
  film: { name: "胶片", contrast: 1.02, sat: 0.9, mono: 0, fade: 0.55, tint: [1.03, 1.0, 0.95] }, cine: { name: "电影青橙", contrast: 1.1, sat: 1.05, mono: 0, fade: 0.2, tint: [1.04, 1.0, 0.94] }, mono: { name: "黑白", contrast: 1.18, sat: 1, mono: 1, fade: 0, tint: [1, 1, 1] } };
export const ASPECTS = { "3:2": 1.5, "4:3": 4 / 3, "16:9": 16 / 9, "1:1": 1, "65:24": 65 / 24 };
export const EXPK = 8.1; // sunny-16 puts an 18 % grey at mid-tone
const near = (arr, v, key) => arr.reduce((b, x) => (Math.abs(Math.log((key ? x[key] : x) / v)) < Math.abs(Math.log((key ? b[key] : b) / v)) ? x : b));
const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
// colour of a black body, linear RGB, normalised so 5500 K is white
function bb(K) { const t = K / 100; let r, g, b; r = t <= 66 ? 255 : 329.698727446 * Math.pow(t - 60, -0.1332047592); g = t <= 66 ? 99.4708025861 * Math.log(t) - 161.1195681661 : 288.1221695283 * Math.pow(t - 60, -0.0755148492);
  b = t >= 66 ? 255 : t <= 19 ? 0 : 138.5177312231 * Math.log(t - 10) - 305.0447927307; return [r, g, b].map((v) => Math.pow(clamp(v, 1, 255) / 255, 2.2)); }
export function wbGain(K) { const a = bb(5500), b = bb(K), g = a.map((v, i) => v / b[i]); const n = g[1]; return g.map((v) => v / n); }

export function createCam() {
  const C = { body: BODIES[0], lens: null, focal: 35, N: 2.8, t: 1 / 250, iso: 200, mode: "A", autoISO: true, ev: 0, wb: "auto", wbK: 5500, af: true, focus: 5, style: "std", nd: 0, tripod: false, aspect: "3:2", video: false, burst: false, m: 1, meterL: 1, awbK: 5500, vf: false, dofPreview: true };
  C.setBody = (id) => { C.body = BODIES.find((b) => b.id === id) || BODIES[0]; const ls = lensesFor(C.body); C.setLens(ls.find((l) => l.f0 <= 35 && l.f1 >= 35) || ls[Math.min(2, ls.length - 1)]); C.iso = clamp(C.iso, C.body.isoMin, C.body.isoMax); C.t = Math.max(C.t, C.body.tMin); };
  C.setLens = (l) => { C.lens = l; C.focal = clamp(C.focal, l.f0, l.f1); if (C.focal !== 35 && l.f0 <= 35 && l.f1 >= 35 && !C._init) C.focal = 35; C.N = clamp(C.N, C.maxN(), l.nMin); C.focus = Math.max(C.focus, l.close); };
  C.maxN = () => { const l = C.lens; if (l.f1 === l.f0) return l.n0; const k = Math.log(C.focal / l.f0) / Math.log(l.f1 / l.f0); return near(APERTURES, Math.exp(Math.log(l.n0) + (Math.log(l.n1) - Math.log(l.n0)) * k)); };
  C.apertures = () => APERTURES.filter((n) => n >= C.maxN() - 1e-6 && n <= C.lens.nMin + 1e-6 || Math.abs(n - C.maxN()) < 1e-6);
  C.shutters = () => SHUTTERS.filter((s) => s.t >= C.body.tMin * 0.999);
  C.isos = () => ISOS.filter((i) => i >= C.body.isoMin && i <= C.body.isoMax);
  C.step = (what, d) => { // move one third of a stop
    if (what === "N") { const a = C.apertures(), i = a.indexOf(near(a, C.N)); C.N = a[clamp(i + d, 0, a.length - 1)]; }
    if (what === "t") { const a = C.shutters(), i = a.indexOf(near(a, C.t, "t")); C.t = a[clamp(i - d, 0, a.length - 1)].t; }
    if (what === "iso") { const a = C.isos(), i = a.indexOf(near(a, C.iso)); C.iso = a[clamp(i + d, 0, a.length - 1)]; C.autoISO = false; }
    if (what === "ev") C.ev = clamp(Math.round((C.ev + d / 3) * 3) / 3, -5, 5);
  };
  C.zoom = (k) => { const l = C.lens; C.focal = clamp(C.focal * k, l.f0, l.f1); C.N = Math.max(C.N, C.maxN()); };
  C.shutterLabel = () => near(SHUTTERS, C.t, "t").label;
  C.crop = () => 43.27 / Math.hypot(C.body.sw, C.body.sh);
  C.frame = () => { const a = C.video ? 16 / 9 : ASPECTS[C.aspect], sa = C.body.sw / C.body.sh; return a >= sa ? { w: C.body.sw, h: C.body.sw / a, a } : { w: C.body.sh * a, h: C.body.sh, a }; };
  C.expFactor = () => (EXPK * C.t * C.iso) / (C.N * C.N) / Math.pow(2, C.nd);
  // auto exposure from the metered scene luminance (same units as the renderer): keeps M untouched, solves the free parameters otherwise
  C.auto = (sceneL) => {
    C.meterL = sceneL; if (!(sceneL > 0)) return; const want = (0.15 * Math.pow(2, C.ev)) / sceneL * Math.pow(2, C.nd); // wanted t*iso/N² * EXPK
    const q = want / EXPK, sh = C.shutters(), tMaxHand = C.tripod ? 30 : Math.min(1 / 15, 1.2 / (C.focal * C.crop()) * Math.pow(2, Math.min(C.body.ibis, 3)));
    const setT = (t) => (C.t = near(sh, clamp(t, C.body.tMin, 30), "t").t), setN = (n) => (C.N = near(C.apertures(), n)), setISO = (i) => (C.iso = near(C.isos(), clamp(i, C.body.isoMin, C.body.isoMax)));
    const base = Math.max(C.body.isoMin, 100);
    if (C.mode === "M") { if (C.autoISO) setISO((q * C.N * C.N) / C.t); return; }
    if (C.mode === "A") { let iso = C.autoISO ? base : C.iso, t = (q * C.N * C.N) / iso; if (C.autoISO && t > tMaxHand) { iso = (q * C.N * C.N) / tMaxHand; setISO(iso); t = (q * C.N * C.N) / C.iso; } else if (C.autoISO) setISO(iso); setT(t); return; }
    if (C.mode === "S") { let iso = C.autoISO ? base : C.iso, n = Math.sqrt((C.t * iso) / q); if (C.autoISO && n < C.maxN()) { setISO((q * C.maxN() * C.maxN()) / C.t); n = Math.sqrt((C.t * C.iso) / q); } else if (C.autoISO) setISO(iso); setN(n); return; }
    // P: walk a program line — open up and slow down together, then raise ISO
    let iso = C.autoISO ? base : C.iso, ev = Math.log2(1 / (q * iso)) , n = clamp(Math.pow(2, (ev - 4) / 4) * 2.8 / 1.4, C.maxN(), Math.min(C.lens.nMin, 16)), t = (q * n * n) / iso;
    if (C.autoISO && t > tMaxHand) { n = C.maxN(); t = (q * n * n) / iso; if (t > tMaxHand) { setISO((q * n * n) / tMaxHand); t = (q * n * n) / C.iso; } else setISO(iso); } else if (C.autoISO) setISO(iso);
    setN(n); setT((q * C.N * C.N) / C.iso);
  };
  // exposure error in stops relative to the meter (what the scale in the viewfinder shows)
  C.meterEV = () => (C.meterL > 0 ? Math.log2((C.expFactor() * C.meterL) / 0.15) : 0);
  C.hyperfocal = () => { const coc = Math.hypot(C.body.sw, C.body.sh) / 1500; return (C.focal * C.focal) / (C.N * coc) / 1000; };
  C._init = true; C.setBody("a7m4"); C._init = false;
  return C;
}
