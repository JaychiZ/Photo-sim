import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { clone } from "three/addons/utils/SkeletonUtils.js";
import { gunzipSync } from "three/addons/libs/fflate.module.js";
import sources from "scene-assets";

export function createSceneAssets(renderer) {
  const loader = new GLTFLoader();
  const templates = new Map();
  const pending = new Map();

  function prepare(id, scene, animations) {
    scene.updateMatrixWorld(true);
    const bounds = new THREE.Box3().setFromObject(scene, true);
    const size = bounds.getSize(new THREE.Vector3());
    if (bounds.isEmpty() || ![size.x, size.y, size.z].every((n) => Number.isFinite(n) && n > 0)) {
      throw new Error("Model has invalid bounds");
    }
    const center = bounds.getCenter(new THREE.Vector3());
    scene.traverse((mesh) => {
      if (!mesh.isMesh) return;
      mesh.castShadow = mesh.receiveShadow = true;
      mesh.geometry.userData.sceneAsset = true;
      for (const material of [].concat(mesh.material)) {
        if (material.map) material.map.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
      }
    });
    templates.set(id, { scene, bounds, center, size, animations });
  }

  return {
    load(ids) {
      return Promise.all(ids.map((id) => {
        if (!sources[id]) return;
        if (!pending.has(id)) {
          pending.set(id, (async () => {
            try {
              const bytes = Uint8Array.from(atob(sources[id]), (char) => char.charCodeAt(0));
              const decoded = gunzipSync(bytes);
              const buffer = decoded.buffer.slice(decoded.byteOffset, decoded.byteOffset + decoded.byteLength);
              const { scene, animations } = await loader.parseAsync(buffer, "");
              prepare(id, scene, animations);
            } catch (error) {
              console.warn(`Scene asset ${id}: ${error.message}`);
            }
          })());
        }
        return pending.get(id);
      }));
    },
    create(id, { height, length, yaw = 0, anchorY = 0, raw = false } = {}) {
      const asset = templates.get(id);
      if (!asset) return null;
      const { scene, bounds, center, size, animations } = asset;
      const mesh = clone(scene);
      if (raw) { mesh.name = id; return mesh; }
      const anchor = new THREE.Group();
      const orientation = new THREE.Group();
      orientation.rotation.y = yaw;
      mesh.position.sub(new THREE.Vector3(center.x, bounds.min.y + size.y * anchorY, center.z));
      orientation.add(mesh);
      const horizontalLength = Math.abs(Math.cos(yaw)) * size.x + Math.abs(Math.sin(yaw)) * size.z;
      anchor.scale.setScalar(height ? height / size.y : length / horizontalLength);
      anchor.name = id;
      anchor.animations = animations;
      anchor.add(orientation);
      return anchor;
    },
  };
}
