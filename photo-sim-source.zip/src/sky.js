// Sky, sun / moon, stars, clouds, weather and the light they cast. Units: 1 = 1000 cd/m² (luminance) or 1000 lux (illuminance).
// Everything is multiplied by the camera's exposure factor before it is rendered (pre-exposure), so night values keep their precision.
import * as THREE from "three";
import starsUrl from "./stars.jpg";
import moonUrl from "./moon.jpg";

const NOISE = `
float h21(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
vec3 h33(vec3 p){ p = fract(p * vec3(0.1031, 0.1030, 0.0973)); p += dot(p, p.yxz + 33.33); return fract((p.xxy + p.yxx) * p.zyx); }
float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f); return mix(mix(h21(i), h21(i + vec2(1, 0)), f.x), mix(h21(i + vec2(0, 1)), h21(i + vec2(1, 1)), f.x), f.y); }
float fbm(vec2 p){ float a = 0.5, s = 0.0; for (int i = 0; i < 5; i++){ s += a * vn(p); p = mat2(1.6, 1.2, -1.2, 1.6) * p + 7.3; a *= 0.5; } return s / 0.97; }
float fbm3(vec2 p){ float a = 0.5, s = 0.0; for (int i = 0; i < 3; i++){ s += a * vn(p); p = mat2(1.6, 1.2, -1.2, 1.6) * p + 7.3; a *= 0.5; } return s / 0.875; }`;
const FRAG = `precision highp float; varying vec3 vDir;
uniform vec3 uSun, uMoon, uZen, uHor, uGlow, uSunL, uGround, uCloudLit, uCloudDark, uPoll;
uniform float uExp, uCloud, uTime, uStars, uAurora, uEnv, uMoonL, uWind, uClamp;
uniform sampler2D tStars, tMoon; uniform vec3 uPhase;
uniform mat3 uStarRot;
${NOISE}
vec3 starLayer(vec3 sd, float sc, float thr){ vec3 p = sd * sc, ip = floor(p), fp = fract(p); vec3 r = h33(ip); float d = length(fp - (0.25 + 0.5 * r)); float b = pow(max(r.z - thr, 0.0) / (1.0 - thr), 3.0);
  vec3 tint = mix(vec3(0.75, 0.85, 1.0), vec3(1.0, 0.85, 0.65), r.x); return tint * b * smoothstep(0.11, 0.0, d); }
void main(){
  vec3 d = normalize(vDir); float h = max(d.y, 0.0); float mu = dot(d, uSun), mm = dot(d, uMoon);
  vec3 col = mix(uHor, uZen, pow(smoothstep(0.0, 1.0, h), 0.42));
  col += uGlow * pow(max(mu, 0.0), 5.0) * exp(-h * 5.0);
  col += uPoll * exp(-h * 4.0);
  vec3 extra = vec3(0.0);
  float sunUp = smoothstep(-0.03, 0.01, uSun.y);
  extra += uSunL * (pow(max(mu, 0.0), 4000.0) * 0.0006 + pow(max(mu, 0.0), 300.0) * 0.000012 + pow(max(mu, 0.0), 24.0) * 0.0000008) * sunUp;
  if (uEnv < 0.5) {
    // sun: disc with limb darkening
    float sd0 = smoothstep(0.999985, 0.999992, mu); extra += uSunL * sd0 * (0.55 + 0.45 * smoothstep(0.999985, 0.99999, mu)) * sunUp;
    // moon: real surface map (NASA LRO), lit according to the phase
    vec3 mr = normalize(cross(vec3(0.0, 1.0, 0.0), uMoon)), mup = cross(uMoon, mr); vec2 mp = vec2(dot(d, mr), dot(d, mup)) / 0.0105; float m2 = dot(mp, mp);
    if (m2 < 1.0 && mm > 0.0) { vec3 n = vec3(mp, sqrt(1.0 - m2)); vec2 muv = vec2(atan(n.x, n.z) / 6.2831853 + 0.5, asin(clamp(n.y, -1.0, 1.0)) / 3.14159265 + 0.5);
      vec3 alb = pow(texture2D(tMoon, muv).rgb, vec3(2.2)); float lit = smoothstep(-0.03, 0.1, dot(n, uPhase)) * max(dot(n, uPhase), 0.0) * 1.4; extra += alb * 9.0 * uMoonL * (lit + 0.00002) * smoothstep(1.0, 0.94, m2); }
    extra += vec3(1.0, 0.97, 0.9) * uMoonL * pow(max(mm, 0.0), 9000.0) * 0.00018;
    if (uStars > 0.0 && d.y > -0.02) { // real star map (NASA Deep Star Maps 2020), rotated with the time of night
      vec3 sd = uStarRot * d; float ext = exp(-0.12 / max(d.y, 0.04)); vec2 suv = vec2(atan(sd.z, sd.x) / 6.2831853 + 0.5, asin(clamp(sd.y, -1.0, 1.0)) / 3.14159265 + 0.5);
      vec3 st = pow(texture2D(tStars, suv).rgb, vec3(2.2)); extra += st * 4.0e-4 * uStars * ext;
    }
    if (uAurora > 0.0 && d.y > 0.03) {
      float az = atan(d.x, -d.z); float north = smoothstep(1.9, 0.4, abs(az));
      float curt = fbm(vec2(az * 3.0 + uTime * 0.02, uTime * 0.015)) ; float ray = 0.6 + 0.4 * sin(az * 90.0 + curt * 30.0 + uTime * 0.3);
      float lo = 0.10 + 0.18 * curt, band = smoothstep(lo, lo + 0.04, d.y) * exp(-(d.y - lo) * 5.0);
      vec3 ac = mix(vec3(0.15, 1.0, 0.45), vec3(0.6, 0.25, 0.9), smoothstep(0.0, 0.35, d.y - lo));
      extra += ac * band * ray * north * smoothstep(0.35, 0.65, fbm(vec2(az * 1.5 - uTime * 0.01, 3.0))) * 2.2e-5 * uAurora;
    }
  }
  // cloud deck: domain-warped noise eroded by finer detail; lit side / shadowed base from a step towards the light, silver lining near the sun,
  // and the deck thins and takes the colour of the haze towards the horizon
  vec2 wnd = vec2(uTime * 0.004 * uWind, uTime * 0.0015 * uWind), cuv = d.xz / (h + 0.07) * 0.5 + wnd;
  vec2 wp = vec2(fbm3(cuv * 0.45 + 3.0), fbm3(cuv * 0.45 + 9.1)) - 0.5;
  float dens = fbm(cuv + wp * 1.1); dens -= (fbm3(cuv * 3.1 + wp * 2.0 - wnd * 2.0) - 0.5) * 0.16 * (1.0 - uCloud * 0.5);
  float t0 = 1.02 - uCloud * 0.95; float cov = smoothstep(t0, t0 + 0.22 + uCloud * 0.12, dens) * smoothstep(0.0, 0.08, d.y);
  if (cov > 0.0) {
    vec2 sdir = normalize(uSun.xz + 1e-4) * 0.06; float ds = fbm(cuv + wp * 1.1 + sdir); float relief = clamp((dens - ds) * 5.0 + 0.5, 0.0, 1.0);
    float thick = smoothstep(t0 + 0.08, t0 + 0.55, dens);
    vec3 cc = mix(uCloudLit, uCloudDark, clamp(thick * 0.85 + (1.0 - relief) * 0.45, 0.0, 1.0));
    float edge = (1.0 - thick) * cov; cc += uSunL * sunUp * (0.0000045 * pow(max(mu, 0.0), 10.0) * (0.4 + 1.6 * edge) + 0.0000012 * pow(max(mu, 0.0), 3.0) * edge);
    cc += uPoll * 1.6 * thick; // city light bouncing off the cloud base at night
    cc = mix(cc, uHor, exp(-h * 7.0) * 0.75);
    col = mix(col + extra, cc, cov * mix(0.94, 1.0, uCloud));
  } else col += extra;
  if (d.y < 0.0) col = mix(uHor * 0.8, uGround, smoothstep(0.0, -0.2, d.y));
  gl_FragColor = vec4(min(col * uExp, vec3(uClamp)), 1.0);
}`;
const VERTS = "varying vec3 vDir; void main(){ vDir = position; vec4 p = projectionMatrix * vec4(mat3(viewMatrix) * position, 1.0); gl_Position = p.xyww; }";
const KEYS = [[-18, [1.5e-7, 2e-7, 3.5e-7], [4e-7, 4e-7, 5e-7]], [-12, [2e-5, 4e-5, 1e-4], [1.5e-4, 1.2e-4, 1.5e-4]], [-6, [4e-3, 8e-3, 2e-2], [3e-2, 2e-2, 2e-2]], [-2, [0.05, 0.09, 0.22], [0.5, 0.25, 0.12]],
  [0, [0.12, 0.2, 0.45], [1.2, 0.55, 0.25]], [5, [0.35, 0.6, 1.3], [2.4, 1.7, 1.0]], [12, [0.5, 0.95, 2.0], [2.6, 2.5, 2.4]], [30, [0.55, 1.1, 2.4], [2.2, 2.9, 3.6]], [90, [0.5, 1.05, 2.5], [2.0, 2.8, 3.6]]];
const lerp = (a, b, k) => a + (b - a) * k, clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x)), sstep = (a, b, x) => { const k = clamp((x - a) / (b - a)); return k * k * (3 - 2 * k); };
function skyCols(el) {
  let i = 0; while (i < KEYS.length - 2 && el > KEYS[i + 1][0]) i++;
  const a = KEYS[i], b = KEYS[i + 1], k = clamp((el - a[0]) / (b[0] - a[0])), L = (x, y) => Math.exp(lerp(Math.log(x), Math.log(y), k));
  return { zen: a[1].map((v, j) => L(v, b[1][j])), hor: a[2].map((v, j) => L(v, b[2][j])) };
}
export const WEATHERS = { clear: { name: "晴", clouds: 0.12, rain: 0, fog: 0, aurora: 0 }, partly: { name: "多云", clouds: 0.5, rain: 0, fog: 0, aurora: 0 }, overcast: { name: "阴", clouds: 0.98, rain: 0, fog: 0.05, aurora: 0 },
  rain: { name: "雨", clouds: 1.0, rain: 1, fog: 0.18, aurora: 0 }, fog: { name: "雾", clouds: 0.6, rain: 0, fog: 1, aurora: 0 }, aurora: { name: "极光（夜）", clouds: 0.05, rain: 0, fog: 0, aurora: 1 } };

export function createSky(scene, renderer) {
  const U = { uSun: { value: new THREE.Vector3(0, 1, 0) }, uMoon: { value: new THREE.Vector3(0, -1, 0) }, uZen: { value: new THREE.Vector3() }, uHor: { value: new THREE.Vector3() }, uGlow: { value: new THREE.Vector3() }, uSunL: { value: new THREE.Vector3() },
    uGround: { value: new THREE.Vector3() }, uCloudLit: { value: new THREE.Vector3() }, uCloudDark: { value: new THREE.Vector3() }, uPoll: { value: new THREE.Vector3() }, uExp: { value: 1 }, uCloud: { value: 0.2 }, uTime: { value: 0 }, uStars: { value: 1 },
    uAurora: { value: 0 }, uEnv: { value: 0 }, uMoonL: { value: 2.5 }, uWind: { value: 1 }, uStarRot: { value: new THREE.Matrix3() }, uClamp: { value: 1e9 }, uPhase: { value: new THREE.Vector3(0, 0, 1) }, tStars: { value: null }, tMoon: { value: null } };
  const tl = new THREE.TextureLoader(); const tS = tl.load(starsUrl); tS.colorSpace = THREE.NoColorSpace; tS.wrapS = THREE.RepeatWrapping; tS.minFilter = THREE.LinearFilter; tS.generateMipmaps = false; U.tStars.value = tS; const tM = tl.load(moonUrl); tM.colorSpace = THREE.NoColorSpace; tM.wrapS = THREE.RepeatWrapping; U.tMoon.value = tM;
  const mat = new THREE.ShaderMaterial({ uniforms: U, vertexShader: VERTS, fragmentShader: FRAG, side: THREE.BackSide, depthWrite: false, fog: false, toneMapped: false });
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(1, 40, 20), mat); mesh.frustumCulled = false; mesh.renderOrder = -1000; mesh.name = "sky"; scene.add(mesh);
  // environment light = a cube-map probe of the real scene around the camera (so lamps, windows and neon bounce and reflect), refreshed as you move
  const cubeRT = new THREE.WebGLCubeRenderTarget(96, { type: THREE.HalfFloatType, generateMipmaps: false }), cubeCam = new THREE.CubeCamera(0.15, 2000, cubeRT); const pmrem = new THREE.PMREMGenerator(renderer); let envRT = null, probeM = 1, envKey = "", probePos = new THREE.Vector3(1e9, 0, 0), probeT = -9, probeN = 0;
  // sky-only cube (no sun disc / moon / stars) that the aerial-perspective pass uses as the colour of the haze in every direction
  const skyScene = new THREE.Scene(), skyMesh = new THREE.Mesh(mesh.geometry, mat); skyMesh.scale.setScalar(900); skyMesh.frustumCulled = false; skyScene.add(skyMesh);
  const skyRT = new THREE.WebGLCubeRenderTarget(32, { type: THREE.HalfFloatType, generateMipmaps: false, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter }), skyCam = new THREE.CubeCamera(1, 2000, skyRT); let skyN = 0;
  const sun = new THREE.DirectionalLight(0xffffff, 1); sun.castShadow = true; sun.shadow.mapSize.set(4096, 4096); sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.04; sun.shadow.radius = 1.3;
  const sc = sun.shadow.camera; sc.near = 1; sc.far = 400; scene.add(sun, sun.target);
  scene.fog = new THREE.FogExp2(0x000000, 0.001);
  // rain: streaks that live in a box around the camera
  const RN = 5000, rp = new Float32Array(RN * 6), re = new Float32Array(RN * 2); for (let i = 0; i < RN; i++) { const x = Math.random() * 30, y = Math.random() * 20, z = Math.random() * 30; rp.set([x, y, z, x, y, z], i * 6); re[i * 2] = 0; re[i * 2 + 1] = 1; }
  const rg = new THREE.BufferGeometry(); rg.setAttribute("position", new THREE.BufferAttribute(rp, 3)); rg.setAttribute("aEnd", new THREE.BufferAttribute(re, 1));
  const rainMat = new THREE.ShaderMaterial({ uniforms: { uTime: { value: 0 }, uCam: { value: new THREE.Vector3() }, uCol: { value: new THREE.Vector3() }, uLen: { value: 0.5 }, uBox: { value: new THREE.Vector4(1e9, 1e9, -1e9, -1e9) }, uBoxY: { value: -1e9 } }, transparent: true, depthWrite: false, fog: false, toneMapped: false,
    vertexShader: "attribute float aEnd; uniform float uTime, uLen, uBoxY; uniform vec3 uCam; uniform vec4 uBox; void main(){ vec3 p = position; p.y = mod(p.y - uTime * (9.0 + fract(p.x * 7.3) * 4.0), 20.0); p.xz = mod(p.xz - uCam.xz, 30.0) - 15.0 + uCam.xz; p.y += uCam.y - 8.0; bool hid = p.x > uBox.x && p.x < uBox.z && p.z > uBox.y && p.z < uBox.w && p.y < uBoxY; p.y += aEnd * uLen; p.x += aEnd * 0.03; if (hid) p = vec3(0.0, -1e5, 0.0); gl_Position = projectionMatrix * viewMatrix * vec4(p, 1.0); }",
    fragmentShader: "uniform vec3 uCol; void main(){ gl_FragColor = vec4(uCol, 0.16); }" });
  const rain = new THREE.LineSegments(rg, rainMat); rain.frustumCulled = false; rain.visible = false; rain.layers.set(1); scene.add(rain);

  const S = { skyCube: skyRT.texture, skyM: 1, fogDens: 0.0004, fogH: 160, ground: "puddle", time: 16.5, weather: "clear", w: { ...WEATHERS.clear }, pollution: 0, moon: 0.5, indoor: false, sunDir: new THREE.Vector3(), moonDir: new THREE.Vector3(), lightDir: new THREE.Vector3(), el: 0, sunE: [0, 0, 0], ambient: [0, 0, 0], wet: 0, night: 0, sun, mesh, t: 0, shadowSize: 70 };
  const rotM = new THREE.Matrix4(), tmp = new THREE.Vector3();
  S.setWeather = (k) => { S.weather = k; }; S.reprobe = () => { probeN = 0; };
  S.update = (dt, camPos, m, envScale = 1) => {
    S.t += dt; const W = WEATHERS[S.weather], w = S.w, r = 1 - Math.exp(-dt * 1.5); for (const k of ["clouds", "rain", "fog", "aurora"]) w[k] += (W[k] - w[k]) * r;
    { const tgt = w.rain > 0.3 ? 1 : S.ground === "dry" ? 0 : S.ground === "damp" ? 0.5 : 1; S.wet += (tgt - S.wet) * (1 - Math.exp(-dt * (tgt > S.wet ? 0.5 : 0.15))); }
    const a = ((S.time - 6) / 12) * Math.PI; S.sunDir.set(Math.cos(a), Math.sin(a), 0.38).normalize(); const am = a + 3.66; S.moonDir.set(Math.cos(am) * 0.96, Math.sin(am), -0.08).normalize(); /* the moon stands overhead at 22:00 */
    const el = (Math.asin(S.sunDir.y) * 180) / Math.PI; S.el = el; S.night = sstep(-4, -14, el);
    const { zen, hor } = skyCols(el); const occ = sstep(0.4, 0.95, w.clouds) * 0.94, dim = 1 - 0.55 * sstep(0.5, 1, w.clouds);
    // direct sun through the atmosphere
    const air = 1 / Math.max(Math.sin((Math.max(el, 0) * Math.PI) / 180), 0.03), T = [Math.exp(-0.06 * air), Math.exp(-0.12 * air), Math.exp(-0.25 * air)], up = sstep(-1, 1.5, el);
    const sunE = T.map((t) => 100 * t * up * (1 - occ)); const moonUp = sstep(-2, 6, (Math.asin(S.moonDir.y) * 180) / Math.PI), ph = S.moon * S.moon, moonE = [0.75, 0.86, 1].map((c) => 2.6e-4 * c * moonUp * ph * (1 - occ));
    const useMoon = sunE[1] < moonE[1]; const E = useMoon ? moonE : sunE; S.sunE = E; S.lightDir.copy(useMoon ? S.moonDir : S.sunDir);
    const mx = Math.max(E[0], E[1], E[2], 1e-12); sun.color.setRGB(E[0] / mx, E[1] / mx, E[2] / mx); sun.intensity = S.indoor && useMoon ? mx * m : mx * m;
    // moonlit sky + city glow
    for (let i = 0; i < 3; i++) { zen[i] = zen[i] * dim + [1.1e-5, 1.5e-5, 2.6e-5][i] * moonUp * ph * S.night; hor[i] = hor[i] * dim + [2.0e-5, 2.3e-5, 3.2e-5][i] * moonUp * ph * S.night; } S.moonWash = moonUp * ph;
    const poll = [1.5e-3, 1.25e-3, 1.5e-3].map((v) => v * S.pollution * S.night * (1 + w.clouds * 2));
    const sunL = T.map((t) => 1.6e6 * t), skyAvg = zen.map((z, i) => (z + hor[i]) * 0.5 + poll[i] * 0.5);
    const lit = E.map((e, i) => (useMoon ? moonE[i] : 100 * T[i] * up) * 0.035 + skyAvg[i] * 1.2 + poll[i] * 2), dark = lit.map((l, i) => l * 0.28 + skyAvg[i] * 0.25);
    const ground = E.map((e, i) => (e * Math.max(S.lightDir.y, 0)) / Math.PI * 0.18 + skyAvg[i] * 0.2);
    S.ambient = skyAvg.map((v, i) => v * (1 - w.clouds * 0.3) + lit[i] * w.clouds * 0.6);
    const set = (u) => { u.uSun.value.copy(S.sunDir); u.uMoon.value.copy(S.moonDir); u.uZen.value.fromArray(zen); u.uHor.value.fromArray(hor); u.uGlow.value.set(hor[0] * 1.6, hor[1] * 0.9, hor[2] * 0.4).multiplyScalar(sstep(25, 3, el) * (1 - occ));
      u.uSunL.value.fromArray(sunL); u.uGround.value.fromArray(ground); u.uCloudLit.value.fromArray(lit); u.uCloudDark.value.fromArray(dark); u.uPoll.value.fromArray(poll); u.uCloud.value = w.clouds; u.uTime.value = S.t; u.uAurora.value = w.aurora * S.night; u.uStars.value = S.night * (1 - 0.55 * (S.moonWash || 0)) * (S.starBoost || 1); u.uMoonL.value = 2.5 * moonUp; };
    set(U); U.uExp.value = m; { const ph = Math.PI * (1 - S.moon); U.uPhase.value.set(Math.sin(ph), 0.12, Math.cos(ph)).normalize(); } rotM.makeRotationAxis(tmp.set(0.0, 0.38, -1).normalize(), -a); U.uStarRot.value.setFromMatrix4(rotM);
    mesh.position.copy(camPos); mesh.scale.setScalar(900);
    const key = [S.time.toFixed(2), w.clouds.toFixed(2), w.aurora.toFixed(1), S.pollution, S.moon.toFixed(2), S.lightsKey || ""].join("|"), moved = probePos.distanceTo(camPos) > (S.indoor ? 3.5 : 14), due = S.t - probeT;
    if (!S.noProbe && (probeN < 4 || (key !== envKey && due > 0.3) || (moved && due > 1.5) || due > 25)) { envKey = key; probeT = S.t; probeN++; probePos.copy(camPos); probeM = m; cubeCam.position.copy(camPos); U.uClamp.value = 24; const rv = rain.visible; rain.visible = false; S.preProbe?.();
      cubeCam.update(renderer, scene); S.postProbe?.(); rain.visible = rv; U.uClamp.value = 3e4; const old = envRT; envRT = pmrem.fromCubemap(cubeRT.texture); scene.environment = envRT.texture; if (old) old.dispose(); }
    scene.environmentIntensity = (m / probeM) * envScale;
    // shadows follow the camera
    const ss = S.shadowSize; sc.left = -ss; sc.right = ss; sc.top = ss; sc.bottom = -ss; sc.updateProjectionMatrix(); const tx = Math.round(camPos.x / 4) * 4, tz = Math.round(camPos.z / 4) * 4;
    sun.target.position.set(tx, 0, tz); sun.position.set(tx, 0, tz).addScaledVector(S.lightDir, 200); sun.target.updateMatrixWorld();
    // haze: extinction per metre at ground level and its scale height (valley fog hugs the ground, clear air thins out quickly with altitude)
    S.fogDens = (0.00026 + w.fog * 0.012 + w.clouds * 0.0001 + w.rain * (S.pollution > 0.5 ? 0.0016 : 0.0028) + S.pollution * (0.00008 + S.night * 0.00006)); S.fogH = 170 - w.fog * 120 - w.rain * 60;
    const fd = Math.sqrt(S.fogDens * 600) / 600, fc = scene.fog.color; fc.setRGB((hor[0] * 0.6 + zen[0] * 0.4 + lit[0] * w.fog + poll[0] * 0.8) * m, (hor[1] * 0.6 + zen[1] * 0.4 + lit[1] * w.fog + poll[1] * 0.8) * m, (hor[2] * 0.6 + zen[2] * 0.4 + lit[2] * w.fog + poll[2] * 0.8) * m); scene.fog.density = fd;
    if ((skyN++ & 3) === 0 || S.noProbe) { U.uEnv.value = 1; U.uClamp.value = 3e4; skyCam.update(renderer, skyScene); U.uEnv.value = 0; S.skyM = m; }
    rain.visible = w.rain > 0.05; { const b = S.rainBox; rainMat.uniforms.uBox.value.set(b ? b.x0 : 1e9, b ? b.z0 : 1e9, b ? b.x1 : -1e9, b ? b.z1 : -1e9); rainMat.uniforms.uBoxY.value = b ? b.y : -1e9; } if (rain.visible) { rainMat.uniforms.uTime.value = S.t; rainMat.uniforms.uCam.value.copy(camPos); const amb = S.ambient; rainMat.uniforms.uCol.value.set((amb[0] + E[0] * 0.05) * m * 1.5, (amb[1] + E[1] * 0.05) * m * 1.5, (amb[2] + E[2] * 0.05) * m * 1.5); }
  };
  return S;
}
