// In-game album: photos (JPEG) and videos, kept in memory and mirrored to IndexedDB so they survive a reload.
export function createAlbum(G) {
  const A = { items: [], onChange: null }; let db = null;
  try { const rq = indexedDB.open("photo-sim", 1); rq.onupgradeneeded = () => rq.result.createObjectStore("items", { keyPath: "id" }); rq.onsuccess = () => { db = rq.result; const all = db.transaction("items").objectStore("items").getAll(); all.onsuccess = () => { for (const it of all.result.sort((a, b) => a.id - b.id)) { it.url = URL.createObjectURL(it.blob); A.items.push(it); } A.onChange?.(); }; }; } catch (e) {}
  const save = (it) => { try { db && db.transaction("items", "readwrite").objectStore("items").put({ id: it.id, type: it.type, blob: it.blob, thumb: it.thumb, meta: it.meta, w: it.w, h: it.h, date: it.date }); } catch (e) {} };
  A.addPhoto = async ({ w, h, buf }, meta) => {
    const c = document.createElement("canvas"); c.width = w; c.height = h; const g = c.getContext("2d"), im = g.createImageData(w, h); for (let y = 0; y < h; y++) im.data.set(buf.subarray((h - 1 - y) * w * 4, (h - y) * w * 4), y * w * 4); g.putImageData(im, 0, 0);
    const blob = await new Promise((r) => c.toBlob(r, "image/jpeg", 0.93)); const tc = document.createElement("canvas"); tc.width = 360; tc.height = Math.round((360 * h) / w); tc.getContext("2d").drawImage(c, 0, 0, tc.width, tc.height);
    const it = { id: Date.now() + Math.random(), type: "photo", blob, url: URL.createObjectURL(blob), thumb: tc.toDataURL("image/jpeg", 0.8), meta, w, h, date: new Date().toISOString() }; A.items.push(it); save(it); A.onChange?.(it); return it; };
  A.addVideo = (blob, meta) => { const it = { id: Date.now() + Math.random(), type: "video", blob, url: URL.createObjectURL(blob), thumb: null, meta, date: new Date().toISOString() }; A.items.push(it); save(it); A.onChange?.(it); return it; };
  A.remove = (it) => { const i = A.items.indexOf(it); if (i >= 0) A.items.splice(i, 1); try { URL.revokeObjectURL(it.url); db && db.transaction("items", "readwrite").objectStore("items").delete(it.id); } catch (e) {} A.onChange?.(); };
  A.download = (it) => { const a = document.createElement("a"); a.href = it.url; const ext = it.type === "photo" ? "jpg" : it.blob.type.includes("mp4") ? "mp4" : "webm"; a.download = `摄影模拟器_${it.date.replace(/[:T]/g, "-").slice(0, 19)}.${ext}`; a.click(); };
  return A;
}
