// Procedural PBR textures: each surface is a few lines of GLSL ("recipe") baked on the GPU at start-up into albedo / normal / roughness-metal maps.
import * as THREE from "three";
const LIB = `precision highp float; varying vec2 vUv; uniform float uMode, uBump;
#define sat(x) clamp(x, 0.0, 1.0)
float h21(vec2 p, vec2 per){ p = mod(p, per); vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
vec2 h22(vec2 p, vec2 per){ return vec2(h21(p, per), h21(p + 19.19, per)); }
float vn(vec2 p, vec2 per){ vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f); return mix(mix(h21(i, per), h21(i + vec2(1, 0), per), f.x), mix(h21(i + vec2(0, 1), per), h21(i + vec2(1, 1), per), f.x), f.y); }
float fbm(vec2 uv, float f, int oct){ float a = 0.5, s = 0.0, t = 0.0; for (int i = 0; i < 7; i++){ if (i >= oct) break; s += a * vn(uv * f + float(i) * 13.7, vec2(f)); t += a; a *= 0.5; f *= 2.0; } return s / t; }
vec3 vor(vec2 uv, float f){ vec2 p = uv * f, i = floor(p), fr = fract(p); float d1 = 9.0, d2 = 9.0, id = 0.0; for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++){ vec2 o = vec2(float(x), float(y)); vec2 r = h22(i + o, vec2(f)); float d = length(o + r - fr); if (d < d1){ d2 = d1; d1 = d; id = h21(i + o + 7.7, vec2(f)); } else if (d < d2) d2 = d; } return vec3(d1, d2, id); }
vec3 L(float r, float g, float b){ return pow(vec3(r, g, b), vec3(2.2)); }
void surf(vec2 uv, out vec3 col, out float h, out float rough, out float metal);
void main(){ vec3 c; float h, r, m; surf(vUv, c, h, r, m);
  if (uMode < 0.5) gl_FragColor = vec4(pow(sat(c), vec3(1.0 / 2.2)), 1.0);
  else if (uMode < 1.5) { vec3 c2; float hx, hy, r2, m2; float e = 1.0 / 1024.0; surf(vUv + vec2(e, 0.0), c2, hx, r2, m2); surf(vUv + vec2(0.0, e), c2, hy, r2, m2); vec3 n = normalize(vec3((h - hx) * uBump, (h - hy) * uBump, 1.0)); gl_FragColor = vec4(n * 0.5 + 0.5, 1.0); }
  else gl_FragColor = vec4(1.0, clamp(r, 0.04, 1.0), sat(m), 1.0); }
`;
const R = {
  terrain: [6, `float n = fbm(uv, 6.0, 6), f = fbm(uv, 60.0, 3); col = vec3(0.62 + 0.5 * n) * (0.85 + 0.3 * f); h = n * 0.6 + f * 0.4; rough = 0.92; metal = 0.0;`],
  rock: [9, `float n = fbm(uv, 4.0, 6); vec3 v = vor(uv + (n - 0.5) * 0.15, 6.0); float cr = smoothstep(0.06, 0.0, v.y - v.x); float f = fbm(uv, 50.0, 3);
    col = mix(L(0.42, 0.41, 0.4), L(0.6, 0.57, 0.52), n) * (0.8 + 0.4 * f) * (1.0 - cr * 0.5); col = mix(col, L(0.35, 0.4, 0.28), smoothstep(0.62, 0.8, fbm(uv, 9.0, 4)) * 0.5); h = n * 0.7 + f * 0.2 - cr * 0.4 + v.z * 0.15; rough = 0.88; metal = 0.0;`],
  bark: [10, `float n = fbm(uv * vec2(1.0, 0.18), 22.0, 4); float f = fbm(uv, 70.0, 2); col = mix(L(0.2, 0.15, 0.11), L(0.42, 0.33, 0.25), n) * (0.8 + 0.4 * f); h = n + f * 0.2; rough = 0.95; metal = 0.0;`],
  leaves: [5, `vec3 v = vor(uv, 26.0); float f = fbm(uv, 40.0, 3); col = mix(L(0.22, 0.42, 0.14), L(0.45, 0.62, 0.2), v.z) * (0.75 + 0.5 * f) * (1.0 - smoothstep(0.3, 0.0, v.y - v.x) * 0.45); h = (1.0 - v.x) * 0.8 + f * 0.2; rough = 0.72; metal = 0.0;`],
  asphalt: [3, `vec3 v = vor(uv, 150.0); float n = fbm(uv, 5.0, 5), f = fbm(uv, 220.0, 2); float st = smoothstep(0.4, 0.2, v.x) * step(v.z, 0.6);
    col = L(0.16, 0.16, 0.17) * (0.75 + 0.5 * n); col = mix(col, mix(L(0.3, 0.3, 0.31), L(0.45, 0.43, 0.4), v.z), st * 0.6); float crk = smoothstep(0.012, 0.0, abs(fbm(uv + 0.3, 3.0, 4) - 0.5)); col *= 1.0 - crk * 0.6;
    h = st * 0.6 + f * 0.3 - crk; rough = mix(0.9, 0.72, st) ; metal = 0.0;`],
  concrete: [5, `float n = fbm(uv, 4.0, 6), f = fbm(uv, 160.0, 3); vec3 v = vor(uv, 60.0); float pore = smoothstep(0.1, 0.02, v.x) * step(v.z, 0.3);
    col = L(0.6, 0.59, 0.56) * (0.72 + 0.45 * n) * (0.92 + 0.16 * f); col *= 1.0 - pore * 0.4; col *= 1.0 - smoothstep(0.6, 0.85, fbm(uv, 3.0, 4)) * 0.25; h = 0.6 + (f - 0.5) * 0.2 - pore * 0.5; rough = 0.86; metal = 0.0;`],
  brick: [4, `float rows = 16.0, cols = 6.0; float y = uv.y * rows, row = floor(y); float x = uv.x * cols + 0.5 * mod(row, 2.0); vec2 f = vec2(fract(x), fract(y)); float id = h21(vec2(floor(x), row), vec2(cols, rows));
    vec2 d = min(f, 1.0 - f) * vec2(3.0, 1.0); float br = smoothstep(0.05, 0.11, min(d.x, d.y) + (fbm(uv, 40.0, 3) - 0.5) * 0.05); float n = fbm(uv, 90.0, 3);
    vec3 c = mix(L(0.55, 0.28, 0.2), L(0.4, 0.2, 0.15), id); c = mix(c, L(0.62, 0.42, 0.3), step(0.85, fract(id * 7.3))); col = mix(L(0.55, 0.53, 0.5), c * (0.8 + 0.4 * n), br) * (1.0 - smoothstep(0.5, 0.85, fbm(uv, 3.0, 4)) * 0.3);
    h = br * (0.7 + n * 0.2); rough = mix(0.95, 0.85, br); metal = 0.0;`],
  plaster: [4, `float n = fbm(uv, 5.0, 5), f = fbm(uv, 120.0, 3); col = L(0.86, 0.84, 0.8) * (0.9 + 0.14 * n) * (0.96 + 0.08 * f); h = f * 0.5 + n * 0.3; rough = 0.9; metal = 0.0;`],
  planks: [3, `float pl = 8.0; float x = uv.x * pl, ix = floor(x); float off = h21(vec2(ix, 1.0), vec2(pl, 64.0)); float y = uv.y * 2.0 + off; float id = h21(vec2(ix, floor(y)), vec2(pl, 2.0));
    float g = fbm(vec2(uv.x * 3.0 + id * 9.0, uv.y * 0.12 + id), 40.0, 4); float gap = smoothstep(0.03, 0.0, min(fract(x), 1.0 - fract(x))) + smoothstep(0.006, 0.0, min(fract(y), 1.0 - fract(y)));
    col = mix(L(0.5, 0.34, 0.2), L(0.68, 0.5, 0.32), g) * (0.85 + 0.3 * id); col *= 1.0 - sat(gap) * 0.7; h = 0.7 + g * 0.15 - sat(gap); rough = 0.42 + g * 0.2; metal = 0.0;`],
  wood: [4, `float g = fbm(vec2(uv.x * 2.0, uv.y * 0.1), 50.0, 4); float kn = fbm(uv, 4.0, 3); col = mix(L(0.33, 0.22, 0.13), L(0.52, 0.37, 0.23), g) * (0.85 + 0.3 * kn); h = g; rough = 0.6; metal = 0.0;`],
  tiles: [4, `float t = 8.0; vec2 p = uv * t; vec2 f = fract(p); float id = h21(floor(p), vec2(t)); vec2 d = min(f, 1.0 - f); float gr = smoothstep(0.02, 0.05, min(d.x, d.y)); float n = fbm(uv, 80.0, 3);
    col = mix(L(0.4, 0.4, 0.4), mix(L(0.78, 0.76, 0.72), L(0.7, 0.68, 0.66), id) * (0.94 + 0.1 * n), gr); h = gr * 0.8; rough = mix(0.9, 0.3 + n * 0.1, gr); metal = 0.0;`],
  fabric: [10, `float w = sin(uv.x * 6.2832 * 90.0) * sin(uv.y * 6.2832 * 90.0); float n = fbm(uv, 30.0, 3); col = vec3(0.78 + 0.1 * w) * (0.9 + 0.2 * n); h = w * 0.5 + 0.5; rough = 0.95; metal = 0.0;`],
  metal: [2, `float b = fbm(vec2(uv.x * 0.05, uv.y), 200.0, 3); float n = fbm(uv, 6.0, 4); col = vec3(0.78) * (0.9 + 0.2 * b); h = b; rough = 0.3 + 0.2 * n + b * 0.1; metal = 1.0;`],
  roof: [6, `float rows = 14.0; float y = uv.y * rows, row = floor(y); float x = uv.x * 10.0 + 0.5 * mod(row, 2.0); float id = h21(vec2(floor(x), row), vec2(10.0, rows)); float fy = fract(y), fx = fract(x);
    float ed = smoothstep(0.0, 0.12, fy) * smoothstep(0.0, 0.06, min(fx, 1.0 - fx)); col = mix(L(0.3, 0.16, 0.12), L(0.45, 0.24, 0.17), id) * (0.6 + 0.4 * ed) * (0.8 + 0.4 * fbm(uv, 50.0, 3)); h = fy * 0.8 * ed; rough = 0.8; metal = 0.0;`],
  cobble: [3, `vec3 v = vor(uv, 14.0); float e = smoothstep(0.03, 0.12, v.y - v.x); float n = fbm(uv, 80.0, 3); col = mix(L(0.2, 0.2, 0.2), mix(L(0.45, 0.44, 0.42), L(0.6, 0.58, 0.54), v.z) * (0.85 + 0.3 * n), e); h = e * (0.7 + 0.3 * (1.0 - v.x)); rough = mix(0.95, 0.6, e); metal = 0.0;`],
  water: [30, `float a = fbm(uv, 6.0, 5), b = fbm(uv + 0.37, 14.0, 4); col = vec3(0.5); h = a * 0.65 + b * 0.35; rough = 0.05; metal = 0.0;`],
  sand: [3, `float n = fbm(uv, 5.0, 5), f = fbm(uv, 200.0, 2); float rip = sin((uv.y + n * 0.06) * 6.2832 * 40.0) * 0.5 + 0.5; col = L(0.76, 0.68, 0.5) * (0.85 + 0.25 * n) * (0.94 + 0.12 * f); h = rip * 0.5 + f * 0.3; rough = 0.95; metal = 0.0;`],
  leather: [8, `vec3 v = vor(uv, 60.0); float e = smoothstep(0.0, 0.08, v.y - v.x); col = vec3(0.8) * (0.85 + 0.15 * e); h = e; rough = 0.45 + 0.2 * (1.0 - e); metal = 0.0;`],
};
export function createTex(renderer, size = 1024) {
  const tri = new THREE.BufferGeometry(); tri.setAttribute("position", new THREE.Float32BufferAttribute([-1, -1, 0, 3, -1, 0, -1, 3, 0], 3));
  const cam = new THREE.Camera(), cache = {};
  const aniso = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  function get(name) {
    if (cache[name]) return cache[name];
    const [bump, body] = R[name];
    const m = new THREE.ShaderMaterial({ vertexShader: "varying vec2 vUv; void main(){ vUv = position.xy * 0.5 + 0.5; gl_Position = vec4(position.xy, 0.0, 1.0); }", fragmentShader: LIB + "void surf(vec2 uv, out vec3 col, out float h, out float rough, out float metal){" + body + "}", uniforms: { uMode: { value: 0 }, uBump: { value: bump } }, depthTest: false, depthWrite: false });
    const mesh = new THREE.Mesh(tri, m); mesh.frustumCulled = false; const out = [];
    for (let k = 0; k < 3; k++) { const t = new THREE.WebGLRenderTarget(size, size, { depthBuffer: false, generateMipmaps: true, minFilter: THREE.LinearMipmapLinearFilter, magFilter: THREE.LinearFilter, wrapS: THREE.RepeatWrapping, wrapT: THREE.RepeatWrapping, anisotropy: aniso });
      if (k === 0) t.texture.colorSpace = THREE.SRGBColorSpace; m.uniforms.uMode.value = k; renderer.setRenderTarget(t); renderer.render(mesh, cam); out.push(t.texture); }
    renderer.setRenderTarget(null); m.dispose();
    return (cache[name] = { map: out[0], normalMap: out[1], orm: out[2] });
  }
  return { get, names: Object.keys(R) };
}
