import * as THREE from "three";
import { MarchingCubes } from "three/addons/objects/MarchingCubes.js";
import { mergeGeometries, mergeVertices } from "three/addons/utils/BufferGeometryUtils.js";
import { detail, loft } from "./kit.js";

const { clamp, smoothstep } = THREE.MathUtils;
export const mix = THREE.MathUtils.lerp;
export const ease = (a, b, x) => smoothstep(x, a, b);
const v3 = (p) => new THREE.Vector3(...p);
export const ball = (x, y, z, a, b, c, angle = 0) => [x, y, z, a, b, c, angle];
const coat = detail(new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .84 }),
  { S: [33, 185, 650], A: [.38, .38, .10], W: [0, 50] });
const plumage = detail(new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .79, side: THREE.DoubleSide }),
  { S: [51, 220, 840], A: [.21, .29, .12], W: [0, 50] });
const wool = detail(new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .94 }),
  { S: [48, 210, 650], A: [.7, 1.05, .22], W: [0, 50] });
const eye = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .24, envMapIntensity: .52 });
const scale = detail(new THREE.MeshStandardMaterial({ vertexColors: true, roughness: .52, side: THREE.DoubleSide }),
  { S: [89, 250, 670], A: [.22, .35, .18], W: [0, 50] });
const materials = { coat, plumage, wool, eye, scale };

function implicit(shapes, blend, noise, resolution) {
  const fields = shapes.map(([x,y,z,a,b,c,angle]) => {
    const s = Math.sin(angle), t = Math.cos(angle);
    return { x,y,z,a,b,c,s,t, dx: Math.hypot(a*t,b*s), dy: Math.hypot(a*s,b*t) };
  });
  const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  const pad = blend * 1.8 + .01;
  for (const {x,y,z,dx,dy,c} of fields) {
    [x,y,z].forEach((n,i) => { const d = [dx,dy,c][i] + pad; min[i] = Math.min(min[i],n-d); max[i] = Math.max(max[i],n+d); });
  }
  const spans = min.map((n,i) => (max[i]-n)/2);
  const center = min.map((n,i) => n + spans[i]);
  const mc = new MarchingCubes(resolution, coat, false, false, resolution * resolution * 8);
  mc.isolation = 0;
  let index = 0;
  for (let k=0;k<resolution;k++) {
    const z = center[2] + (k * mc.delta - 1) * spans[2];
    for (let j=0;j<resolution;j++) {
      const y = center[1] + (j * mc.delta - 1) * spans[1];
      for (let i=0;i<resolution;i++) {
        const x = center[0] + (i * mc.delta - 1) * spans[0];
        let d = Infinity;
        for (const p of fields) {
          const px=x-p.x, py=y-p.y;
          const u=(px*p.t+py*p.s)/p.a, v=(py*p.t-px*p.s)/p.b, w=(z-p.z)/p.c;
          const k0=Math.hypot(u,v,w), k1=Math.hypot(u/p.a,v/p.b,w/p.c);
          const sd=k1>1e-8 ? k0*(k0-1)/k1 : -Math.min(p.a,p.b,p.c);
          const h = blend ? Math.max(0, blend-Math.abs(d-sd))/blend : 0;
          d = Math.min(d,sd) - h*h*blend*.25;
        }
        mc.field[index++] = (noise ? noise(x,y,z) : 0) - d;
      }
    }
  }
  mc.update();
  const g = new THREE.BufferGeometry();
  const pos = mc.positionArray.slice(0, mc.count*3);
  for(let i=0;i<pos.length;i++) pos[i] = pos[i]*spans[i%3]+center[i%3];
  g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  const n = mc.normalArray.slice(0, mc.count*3);
  for (let i=0;i<n.length;i+=3) {
    const len = Math.hypot(n[i]/spans[0],n[i+1]/spans[1],n[i+2]/spans[2]) || 1;
    for(let j=0;j<3;j++) n[i+j] /= spans[j]*len;
  }
  g.setAttribute("normal", new THREE.BufferAttribute(n, 3));
  mc.geometry.dispose();
  const joined = mergeVertices(g, 1e-5);
  g.dispose();
  return joined;
}

export function buildAnimal() {
  const joints = [], batches = new Map(), scratch = new THREE.Color();
  function joint(name, at = [0,0,0], parent = -1) {
    joints.push({ name, at, parent });
    return joints.length - 1;
  }
  function add(geo, paint, weights = 0, material = "coat", close = false) {
    geo.deleteAttribute("uv");
    const p = geo.attributes.position, n = geo.attributes.normal;
    const colors = new Float32Array(p.count*3), ids = new Uint16Array(p.count*4), ws = new Float32Array(p.count*4);
    for (let i=0;i<p.count;i++) {
      const x=p.getX(i), y=p.getY(i), z=p.getZ(i);
      const c = typeof paint === "function" ? paint(x,y,z,n.getY(i)) : paint;
      scratch.set(c).toArray(colors,i*3);
      const influence = typeof weights === "function" ? weights(x,y,z) : [[weights,1]];
      let total = 0;
      for (const [j,[bone,weight]] of influence.entries()) {
        ids[i*4+j] = bone;
        ws[i*4+j] = weight;
        total += weight;
      }
      for (let j=0;j<influence.length;j++) ws[i*4+j] /= total || 1;
    }
    geo.setAttribute("color", new THREE.BufferAttribute(colors,3));
    geo.setAttribute("skinIndex", new THREE.BufferAttribute(ids,4));
    geo.setAttribute("skinWeight", new THREE.BufferAttribute(ws,4));
    if (!geo.index) geo = mergeVertices(geo);
    const key=close?material+":detail":material;
    if (!batches.has(key)) batches.set(key, []);
    batches.get(key).push(geo);
  }
  return {
    joint, add,
    volume(shapes, paint, weights, { blend = .018, noise, resolution = 49, material = "coat" } = {}) {
      add(implicit(shapes, blend, noise, resolution), paint, weights, material);
    },
    tube(points, paint, weights, material = "coat", options = {}) {
      const pts = points.map(([x,y,z,r,h]) => ({p:[x,y,z],r:h === undefined ? r : [r,h]}));
      add(loft(pts, {seg:12,sub:4,cap:3,...options}),paint,weights,material);
    },
    oval(at, axes, paint, weights, material = "coat", angle = 0) {
      const g=new THREE.SphereGeometry(1, 14, 10).scale(...axes).rotateZ(angle).translate(...at);
      add(g,paint,weights,material);
    },
    // A feather has a rounded leading edge, a cambered vane and a thin trailing edge.
    vane(a,b,width,bend,paint,weights,material="plumage",close=false) {
      const start=v3(a), delta=v3(b).sub(start), axis=delta.clone().normalize();
      const across=new THREE.Vector3(-axis.z,0,axis.x).normalize();
      const pos=[],idx=[];
      for(let j=0;j<=5;j++) {
        const t=j/5, w=width*(.06+.94*Math.pow(Math.sin(Math.PI*t),.65));
        for(let i=0;i<=3;i++) {
          const u=i/3, p=start.clone().addScaledVector(delta,t).addScaledVector(across,(u-.46)*w);
          p.y+=Math.sin(Math.PI*u)*w*.15 + Math.sin(t*Math.PI)*bend;
          pos.push(p.x,p.y,p.z);
          if(j<5&&i<3){const k=j*4+i;idx.push(k,k+1,k+4,k+1,k+5,k+4);}
        }
      }
      const g=new THREE.BufferGeometry();
      g.setAttribute("position",new THREE.Float32BufferAttribute(pos,3));
      g.setIndex(idx);g.computeVertexNormals();add(g,paint,weights,material,close);
    },
    sheet(rows, paint, weights, material = "plumage") {
      const g=new THREE.BufferGeometry(), idx=[], columns=rows[0].length;
      g.setAttribute("position",new THREE.Float32BufferAttribute(rows.flat(2),3));
      for(let j=0;j<rows.length-1;j++) for(let i=0;i<columns-1;i++) {
        const a=j*columns+i;idx.push(a,a+1,a+columns,a+1,a+columns+1,a+columns);
      }
      g.setIndex(idx);g.computeVertexNormals();add(g,paint,weights,material);
    },
    finish(name) {
      const meshes = [...batches].map(([key, geos]) => {
        const g = mergeGeometries(geos);
        geos.forEach(geo=>geo.dispose());
        g.computeBoundingSphere();
        const [material,detail] = key.split(":");
        return {g, mat:materials[material], material, detail, bound:g.boundingSphere.clone()};
      });
      const animatedBounds=new THREE.Sphere();
      animatedBounds.makeEmpty();
      for(const {bound} of meshes) animatedBounds.union(bound);
      animatedBounds.radius *= 1.55;
      return () => {
        const root = new THREE.Group();
        root.name = name;
        root.userData.wildlife = true;
        const bones = joints.map(({ name: label, at, parent }) => {
          const bone = new THREE.Bone();
          bone.name = label;
          bone.position.fromArray(at);
          if (parent >= 0) bone.position.sub(v3(joints[parent].at));
          return bone;
        });
        joints.forEach(({parent},i) => (parent < 0 ? root : bones[parent]).add(bones[i]));
        root.updateMatrixWorld(true);
        const skeleton = new THREE.Skeleton(bones);
        const detailMeshes=[];
        for (const {g,mat,material,detail} of meshes) {
          const skin = new THREE.SkinnedMesh(g,mat);
          skin.name=material;
          skin.bind(skeleton, new THREE.Matrix4());
          skin.boundingSphere=animatedBounds;
          skin.castShadow = material !== "eye" && !detail;
          if(detail) detailMeshes.push(skin);
          // Receiving its own low-resolution shadow hides feather and fur detail at telephoto.
          root.add(skin);
        }
        if(detailMeshes.length) root.userData.setClose=(visible)=>{
          for(const mesh of detailMeshes) mesh.visible=visible;
        };
        return root;
      };
    },
  };
}

export function tones(...colors) {
  const palette=colors.map(c=>new THREE.Color(c)), sample=new THREE.Color();
  return (a=0,b=0,t=0,light=1)=>sample.copy(palette[a]).lerp(palette[b],clamp(t,0,1)).multiplyScalar(light);
}

export function grain(x,y,z,k=1) {
  return Math.sin((x*63+y*42+z*82)*k)*Math.sin((x*117-y*94+z*51)*k)*Math.sin((x*35-y*71-z*98)*k);
}

export function transition(a,b,t) { return [[a,1-t],[b,t]]; }
