// Nature: a lake under snow peaks, meadow, forest, a cabin with a pier, a lighthouse and a few landmarks worth walking to.
import * as THREE from "three";
import { createWater, waveY } from "./water.js";
import { clamp, lerp, sstep, fbm, vnoise, rng } from "./util.js";
import { makeTree, forest, foliage } from "./models.js";
import { build as buildVilla } from "./scene_indoor.js";
import { loft, lathe } from "./kit.js";
const TERR = 480, LAKE = { x: -28, z: 14, r: 46 }, MESA = { x: 96, z: 118, r: 20, h: 58 }, FD = [-1, 0], FALL = { x: 71, z: 118 }, POOL = { x: 60, z: 118 }, DK = { x: 30, z: 106 }, ISLE = { x: -28, z: 17.1, y: 1.3 };
const dseg = (x, z, ax, az, bx, bz) => { const dx = bx - ax, dz = bz - az, t = clamp(((x - ax) * dx + (z - az) * dz) / (dx * dx + dz * dz)); return Math.hypot(x - ax - dx * t, z - az - dz * t); };
const PADS = [[40, 20, 9, 2.2], [31, 12, 4, 1.6], [46, -32, 10, 9.5], [-66, -22, 7, 3.0], [8, -72, 8, 12]]; // flattened spots: x, z, radius, height
function H(x, z) {
  const r = Math.hypot(x, z); let h = 1.6 + (fbm(x * 0.011 + 5, z * 0.011 + 9, 4) - 0.5) * 8;
  h += 7.5 * Math.exp(-((x - 46) ** 2 + (z + 32) ** 2) / 500) + 10 * Math.exp(-((x - 8) ** 2 + (z + 72) ** 2) / 700);
  const dl = Math.hypot(x - LAKE.x, (z - LAKE.z) * 1.25); h = lerp(h, -3.6, sstep(LAKE.r + 16, LAKE.r - 14, dl)); h = Math.min(h, lerp(h, 0.25, sstep(LAKE.r + 22, LAKE.r + 4, dl) * 0.8));
  // the valley opens to the sea in the south (a fjord mouth between flanking cliffs)
  const seaK = sstep(84, 140, z + (fbm(x * 0.02, 3, 2) - 0.5) * 22) * sstep(120, 62, Math.abs(x - 6));
  const mt = sstep(118, 188, r) * (1 - seaK), ridge = 1 - Math.abs(fbm(x * 0.0085 + 1, z * 0.0085 + 4, 5) * 2 - 1); h += mt * mt * (10 + 128 * Math.pow(ridge, 2.6) * (0.4 + fbm(x * 0.021, z * 0.021, 4))) + mt * (fbm(x * 0.09, z * 0.09, 3) - 0.5) * 5; { const cr = 1 - Math.abs(fbm(x * 0.045 + 9, z * 0.045 + 2, 4) * 2 - 1), cr2 = 1 - Math.abs(fbm(x * 0.13 + 4, z * 0.13 + 7, 3) * 2 - 1); h += mt * mt * (cr * cr * 22 + cr2 * cr2 * 6 - 9); }
  h = lerp(h, -12 + (fbm(x * 0.03, z * 0.03, 3) - 0.5) * 3, seaK); { const cl = sstep(60, 78, Math.abs(x - 6)) * sstep(80, 100, z) * sstep(200, 150, z); h += cl * (22 + 30 * fbm(x * 0.03, z * 0.03, 3)) * sstep(64, 70, Math.abs(x - 6)); }
  // a flat-topped mesa with sheer walls, a waterfall off its lip, a plunge pool and a stream down to the lake
  // the eastern headland: a plateau joined to the mountains behind it, ending in a sheer sea cliff; a river crosses it and drops into the fjord
  { const pn = fbm(x * 0.03 + 2, z * 0.03 + 7, 3), pk = sstep(66, 73, x + (pn - 0.5) * 9) * sstep(64, 84, z + (fbm(x * 0.04, 1.5, 2) - 0.5) * 10); if (pk > 0) { const top = MESA.h + (fbm(x * 0.03, z * 0.03, 3) - 0.5) * 7 + sstep(110, 170, x) * 14; h = lerp(h, Math.max(h, top), pk); } }
  // an island in the middle of the lake for the villa
  h = lerp(h, ISLE.y - 0.25, sstep(27, 19.5, Math.hypot((x - ISLE.x) * 1.25, z - ISLE.z)));
  for (const [px, pz, pr, ph] of PADS) h = lerp(h, ph, sstep(pr * 1.6, pr * 0.7, Math.hypot(x - px, z - pz)));
  return h;
}
const slope = (x, z) => Math.hypot(H(x + 0.7, z) - H(x - 0.7, z), H(x, z + 0.7) - H(x, z - 0.7)) / 1.4;
const lin = (r, g, b) => [Math.pow(r, 2.2), Math.pow(g, 2.2), Math.pow(b, 2.2)];

export function build(G) {
  { let best = 1e9; for (let x = 10; x < 60; x += 2) for (let z = 84; z < 122; z += 2) { const h = H(x, z); if (h > 0.7 && h < 4 && slope(x, z) < 0.3) { const d = Math.hypot(x - 46, z - 112); if (d < best) { best = d; DK.x = x; DK.z = z; } } } }
  const K = G.kit, rnd = rng(77), group = new THREE.Group(), circles = [];
  // ---- terrain
  const SEG = 300, tg = new THREE.PlaneGeometry(TERR, TERR, SEG, SEG); tg.rotateX(-Math.PI / 2);
  const P = tg.attributes.position, col = new Float32Array(P.count * 3), uv = tg.attributes.uv;
  const cg = lin(0.2, 0.3, 0.1), cy = lin(0.36, 0.36, 0.14), cs = lin(0.5, 0.46, 0.35), cr = lin(0.36, 0.34, 0.33), cw = lin(0.93, 0.95, 0.98), cm = lin(0.2, 0.2, 0.16);
  for (let i = 0; i < P.count; i++) { const x = P.getX(i), z = P.getZ(i), h = H(x, z); P.setY(i, h); const s = slope(x, z), n = fbm(x * 0.05, z * 0.05, 3);
    let c = cg.map((v, k) => lerp(v, cy[k], sstep(0.35, 0.7, n))); const sand = sstep(1.1, 0.3, h); c = c.map((v, k) => lerp(v, cs[k], sand)); const mud = sstep(0.0, -1.2, h); c = c.map((v, k) => lerp(v, cm[k], mud));
    const rock = Math.max(sstep(0.5, 0.9, s), sstep(16, 30, h + n * 8)); const strata = 0.7 + 0.5 * vnoise(h * 0.35 + n * 3, x * 0.01); c = c.map((v, k) => lerp(v, cr[k] * strata * (k === 0 ? 1.06 : 1), rock)); const snow = sstep(30, 44, h + n * 16) * sstep(1.9, 0.75, s); c = c.map((v, k) => lerp(v, cw[k], snow));
    col.set(c, i * 3); uv.setXY(i, x / 5, z / 5); }
  tg.setAttribute("color", new THREE.BufferAttribute(col, 3)); tg.computeVertexNormals();
  const terrain = new THREE.Mesh(tg, K.mat("terrain", { vc: true, ns: 1.2, wet: 0.5, detail: { S: [0.22, 1.9, 13], A: [0.7, 0.5, 0.26], W: [0, 10] } })); terrain.receiveShadow = true; terrain.castShadow = true; group.add(terrain);
  // rock and meadow detail in world space: triplanar rock strata on steep or high ground (with bump), slow patches of drier / greener grass,
  // so mountains read as rock faces instead of smooth vertex colour at every distance
  { const tm = terrain.material, prev = tm.onBeforeCompile, rk = G.tex.get("rock"); tm.onBeforeCompile = (sh, rr) => { prev?.(sh, rr); sh.uniforms.tRock = { value: rk.map };
      sh.vertexShader = sh.vertexShader.replace("#include <common>", "#include <common>\nvarying vec3 vTw; varying vec3 vTn;").replace("#include <begin_vertex>", "#include <begin_vertex>\nvTw = (modelMatrix * vec4(position, 1.0)).xyz; vTn = normalize(mat3(modelMatrix) * normal);");
      sh.fragmentShader = sh.fragmentShader.replace("#include <common>", `#include <common>
        varying vec3 vTw; varying vec3 vTn; uniform sampler2D tRock;
        vec3 triR(vec3 p, vec3 w){ return pow(texture2D(tRock, p.zy).rgb, vec3(2.2)) * w.x + pow(texture2D(tRock, p.xz).rgb, vec3(2.2)) * w.y + pow(texture2D(tRock, p.xy).rgb, vec3(2.2)) * w.z; }`)
        .replace("#include <color_fragment>", `#include <color_fragment>
        vec3 tw = pow(abs(vTn), vec3(4.0)); tw /= dot(tw, vec3(1.0)); float tSl = 1.0 - clamp(vTn.y, 0.0, 1.0), tDist = length(vTw - cameraPosition);
        vec3 tc = diffuseColor.rgb; float tSat = max(tc.r, max(tc.g, tc.b)) - min(tc.r, min(tc.g, tc.b)), tLum = dot(tc, vec3(0.3, 0.59, 0.11));
        float tRockK = clamp(smoothstep(0.32, 0.62, tSl) + smoothstep(0.06, 0.0, tSat) * smoothstep(0.75, 0.5, tLum), 0.0, 1.0);
        vec3 r1 = triR(vTw / 6.0, tw), r2 = triR(vTw / 27.0 + 0.37, tw), r3 = triR(vTw / 120.0 + 0.71, tw);
        float rl1 = dot(r1, vec3(0.33)), rl2 = dot(r2, vec3(0.33)), rl3 = dot(r3, vec3(0.33)), tFar = smoothstep(40.0, 160.0, tDist);
        float rockMod = mix(rl1 / 0.2, 1.0, tFar * 0.6) * (rl2 / 0.2) * mix(0.8, 1.2, rl3 / 0.4);
        diffuseColor.rgb *= mix(vec3(1.0), clamp(vec3(rockMod) * mix(vec3(1.0), r2 / max(rl2, 1e-3), 0.35), 0.25, 2.2), tRockK * 0.85);
        diffuseColor.rgb *= mix(1.0, 0.78 + 0.44 * smoothstep(0.1, 0.32, rl3), (1.0 - tRockK) * 0.8);
        float tSnow = smoothstep(0.62, 0.8, tLum) * (1.0 - smoothstep(0.07, 0.14, tSat)), bare = smoothstep(0.36, 0.58, tSl + (rl2 - 0.2) * 1.4 + (rl3 - 0.2) * 0.8);
        diffuseColor.rgb = mix(diffuseColor.rgb, vec3(0.13, 0.125, 0.12) * clamp(rockMod, 0.4, 1.8), tSnow * bare);
        diffuseColor.rgb *= mix(1.0, 0.86 + 0.14 * smoothstep(0.1, 0.35, rl2), tSnow * (1.0 - bare));
        float tH = (rl1 * (1.0 - tFar) + rl2 * 2.5) * max(tRockK, tSnow * bare);`)
        .replace("#include <clearcoat_normal_fragment_begin>", "normal = dBump(normal, tH * 0.35);\n#include <clearcoat_normal_fragment_begin>"); };
    const ck = tm.customProgramCacheKey; tm.customProgramCacheKey = () => ck() + "|triRock"; tm.needsUpdate = true; }
  // height + grass mask for the grass shader
  const HS = 512, hd = new Float32Array(HS * HS * 4); for (let j = 0; j < HS; j++) for (let i = 0; i < HS; i++) { const x = (i / (HS - 1) - 0.5) * TERR, z = (j / (HS - 1) - 0.5) * TERR, h = H(x, z), k = (j * HS + i) * 4; hd[k] = h;
    hd[k + 1] = sstep(0.5, 1.0, h) * sstep(0.6, 0.35, slope(x, z)) * sstep(20, 12, h) * (PADS.slice(0, 2).some(([px, pz, pr]) => Math.hypot(x - px, z - pz) < pr * 0.8) ? 0 : 1) * (Math.abs(x - ISLE.x) < 10.5 && Math.abs(z - ISLE.z) < 15.5 ? 0 : 1); hd[k + 2] = fbm(x * 0.08, z * 0.08, 3); hd[k + 3] = 1; }
  const htex = new THREE.DataTexture(hd, HS, HS, THREE.RGBAFormat, THREE.FloatType); htex.magFilter = htex.minFilter = THREE.LinearFilter; htex.needsUpdate = true;
  // ---- grass: tufts in a tile that wraps around the camera, planted on the height map inside the vertex shader
  const blade = []; const br = rng(5);
  for (let b = 0; b < 12; b++) { const a = br() * 6.28, ox = (br() - 0.5) * 0.34, oz = (br() - 0.5) * 0.34, hh = 0.16 + br() * 0.34, w = 0.008 + br() * 0.007, lean = 0.06 + br() * 0.2, c = Math.cos(a), s = Math.sin(a);
    const pt = (u, v) => [ox + c * u * w + s * lean * v * v, v * hh, oz + s * u * w - c * lean * v * v, v]; const q = [pt(-1, 0), pt(1, 0), pt(-0.7, 0.5), pt(0.7, 0.5), pt(0, 1)];
    for (const [i0, i1, i2] of [[0, 1, 2], [1, 3, 2], [2, 3, 4]]) blade.push(q[i0], q[i1], q[i2]); }
  const bg = new THREE.BufferGeometry(); bg.setAttribute("position", new THREE.Float32BufferAttribute(blade.flatMap((p) => p.slice(0, 3)), 3)); bg.setAttribute("uv", new THREE.Float32BufferAttribute(blade.flatMap((p) => [0.5, p[3]]), 2));
  bg.setAttribute("normal", new THREE.Float32BufferAttribute(blade.flatMap(() => [0, 1, 0]), 3));
  const GN = G.quality.grass, GS = 46, gmat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.75, side: THREE.DoubleSide });
  const gu = { uCam: { value: new THREE.Vector3() }, uHeight: { value: htex }, uTime: { value: 0 }, uWind: { value: 1 } };
  gmat.onBeforeCompile = (s) => { Object.assign(s.uniforms, gu);
    s.vertexShader = "uniform vec3 uCam; uniform sampler2D uHeight; uniform float uTime, uWind; varying float vGy; varying float vGn;\n" + s.vertexShader
      .replace("#include <project_vertex>", `mat4 gim = instanceMatrix; vec2 go = mod(gim[3].xz - uCam.xz + ${(GS / 2).toFixed(1)}, ${GS.toFixed(1)}) - ${(GS / 2).toFixed(1)} + uCam.xz; vec4 gh = texture2D(uHeight, go / ${TERR.toFixed(1)} + 0.5);
        float gf = (1.0 - smoothstep(0.7, 1.0, length(go - uCam.xz) / ${(GS / 2).toFixed(1)})) * gh.g * (0.6 + 0.8 * gh.b); gim[3].xyz = vec3(go.x, gh.r, go.y);
        vec3 gp = transformed * vec3(1.0, gf, 1.0); float sw = sin(uTime * 1.6 + go.x * 0.35 + go.y * 0.27) + 0.5 * sin(uTime * 3.1 + go.x * 1.3); gp.xz += vec2(0.07, 0.04) * sw * uv.y * uv.y * uWind; vGy = uv.y; vGn = gh.b;
        vec4 gWorld = modelMatrix * (gim * vec4(gp, 1.0)); vec4 mvPosition = viewMatrix * gWorld; gl_Position = projectionMatrix * mvPosition;`)
      .replace("#include <worldpos_vertex>", "vec4 worldPosition = gWorld;");
    s.fragmentShader = "varying float vGy; varying float vGn;\n" + s.fragmentShader.replace("#include <color_fragment>", "diffuseColor.rgb = mix(vec3(0.012, 0.024, 0.008), mix(vec3(0.055, 0.092, 0.026), vec3(0.13, 0.125, 0.05), vGn), vGy) * (0.5 + 0.5 * vGy);"); };
  const grass = new THREE.InstancedMesh(bg, gmat, GN); const m4 = new THREE.Matrix4(), q4 = new THREE.Quaternion(), e4 = new THREE.Euler(), v3 = new THREE.Vector3(), s3 = new THREE.Vector3();
  for (let i = 0; i < GN; i++) grass.setMatrixAt(i, m4.compose(v3.set(rnd() * GS, 0, rnd() * GS), q4.setFromEuler(e4.set(0, rnd() * 6.28, 0)), s3.setScalar(0.8 + rnd() * 0.7)));
  grass.frustumCulled = false; grass.receiveShadow = true; grass.layers.set(1); group.add(grass);
  // ---- trees: real branch structure + leaf cards, instanced
  const paint = (g, c0, c1, y0, y1) => { const p = g.attributes.position, c = new Float32Array(p.count * 3); for (let i = 0; i < p.count; i++) { const k = clamp((p.getY(i) - y0) / (y1 - y0)), n = vnoise(p.getX(i) * 3, p.getZ(i) * 3 + p.getY(i)); for (let j = 0; j < 3; j++) c[i * 3 + j] = lerp(c0[j], c1[j], clamp(k * 0.7 + n * 0.5)); } g.setAttribute("color", new THREE.BufferAttribute(c, 3)); return g; };
  const merge = (list) => { const B = K.builder(), m = K.mat("terrain", { vc: true, ns: 1.6, color: 0xffffff }); for (const g of list) B.add(g, m); const gr = new THREE.Group(); B.finish(gr); return gr.children[0].geometry; };
  const fol = foliage(K), bark = K.mat("bark", { wet: 0.3, color: 0x6e5a48 });
  const scatter = (n, pick, sc) => { const out = []; let guard = 0; while (out.length < n && guard++ < n * 60) { const a = rnd() * 6.28, r = 16 + Math.sqrt(rnd()) * 175, x = Math.cos(a) * r, z = Math.sin(a) * r, h = H(x, z); if (!pick(x, z, h)) continue; const s = sc[0] + rnd() * (sc[1] - sc[0]); out.push({ x, y: h - 0.1, z, s, sy: 0.9 + rnd() * 0.25, ry: rnd() * 6.28 }); if (r < 120) circles.push({ x, z, r: 0.3 * s }); } return out; };
  const clear = (x, z) => PADS.some(([px, pz, pr]) => Math.hypot(x - px, z - pz) < pr * 1.3) || Math.hypot(x - 30, z - 14) < 12 || Math.hypot((x - ISLE.x) * 1.25, z - ISLE.z) < 29;
  const forestN = (x, z) => fbm(x * 0.018 + 3, z * 0.018 + 8, 3);
  for (let v = 0; v < 3; v++) forest(K, makeTree("pine", 11 + v), { bark, leaf: fol.pine }, scatter(Math.round(G.quality.trees / 3), (x, z, h) => h > 1.4 && h < 46 && slope(x, z) < 0.9 && !clear(x, z) && (forestN(x, z) > 0.5 || h > 14) && rnd() < 0.8, [0.75, 1.35]), group);
  for (let v = 0; v < 2; v++) forest(K, makeTree("leafy", 21 + v), { bark, leaf: fol.leafy }, scatter(Math.round(G.quality.trees * 0.13), (x, z, h) => h > 1.2 && h < 12 && slope(x, z) < 0.5 && !clear(x, z) && forestN(x, z) > 0.4 && forestN(x, z) < 0.56, [0.8, 1.4]), group);
  forest(K, makeTree("leafy", 5, { h: 4.2, depth: 4, cards: 6, leaf: 1.2 }), { bark, leaf: fol.leafy }, [{ x: 46, y: 9.3, z: -32, s: 2.1, ry: 1 }], group); circles.push({ x: 46, z: -32, r: 0.9 });
  // ---- rocks
  const rg = new THREE.IcosahedronGeometry(1, 4); { const p = rg.attributes.position; for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i), z = p.getZ(i), n = 0.72 + 0.5 * fbm(x * 1.3 + 5 + y, z * 1.3 + y * 0.7, 3) + 0.16 * (fbm(x * 3.1 + 2, z * 3.1 + y * 2.3, 3) - 0.5); p.setXYZ(i, x * n, y * n, z * n); } rg.computeVertexNormals(); } const ruv = rg.attributes.uv; for (let i = 0; i < ruv.count; i++) ruv.setXY(i, ruv.getX(i) * 3, ruv.getY(i) * 2);
  const rocks = new THREE.InstancedMesh(rg, K.mat("rock", { wet: 0.6, color: 0x9a968c, detail: { S: [1.2, 9, 60], A: [0.8, 1.2, 0.3], W: [0.2, 6] } }), 220); for (let i = 0; i < 220; i++) { const a = rnd() * 6.28, r = 12 + Math.sqrt(rnd()) * 130, x = Math.cos(a) * r, z = Math.sin(a) * r, h = H(x, z), s = (Math.pow(rnd(), 2.2) * 2.6 + 0.25) * (Math.hypot(x - 30, z - 15.5) < 12 ? 0.15 : 1) * (Math.hypot((x - ISLE.x) * 1.25, z - ISLE.z) < 30 || (x > -10 && x < -2 && z > 70) ? 0 : 1);
    rocks.setMatrixAt(i, m4.compose(v3.set(x, h + s * 0.15, z), q4.setFromEuler(e4.set(rnd() * 3, rnd() * 6, rnd() * 3)), s3.set(s, s * (0.5 + rnd() * 0.4), s * (0.7 + rnd() * 0.5)))); if (s > 0.8 && !clear(x, z)) circles.push({ x, z, r: s * 0.8 }); }
  rocks.castShadow = rocks.receiveShadow = true; group.add(rocks);
  // ---- flowers
  const fgList = []; for (let i = 0; i < 5; i++) { const p = new THREE.CircleGeometry(0.035, 6); p.translate(0.04, 0, 0); p.rotateZ((i / 5) * 6.28); fgList.push(p); } const fgeo = merge([...fgList.map((g) => { g.rotateX(-1.1); g.translate(0, 0.3, 0); return paint(g, [1, 1, 1], [1, 1, 1], 0, 1); }), paint(new THREE.CylinderGeometry(0.004, 0.006, 0.3, 4).translate(0, 0.15, 0), lin(0.1, 0.3, 0.05), lin(0.1, 0.3, 0.05), 0, 1)]);
  const flowers = new THREE.InstancedMesh(fgeo, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.7, side: THREE.DoubleSide }), 5000); const fc = new THREE.Color(), pal = [0xffd23a, 0xf4f1e6, 0xd94a7a, 0x8b6ae6, 0xff7b2e];
  let fk = 0; for (let t = 0; t < 60000 && fk < 5000; t++) { const x = (rnd() - 0.5) * 220, z = (rnd() - 0.5) * 220, h = H(x, z); if (h < 0.9 || h > 12 || slope(x, z) > 0.4 || fbm(x * 0.06 + 20, z * 0.06, 3) < 0.55) continue; const s = 0.8 + rnd() * 0.9;
    flowers.setMatrixAt(fk, m4.compose(v3.set(x, h, z), q4.setFromEuler(e4.set(0, rnd() * 6.28, 0)), s3.setScalar(s))); flowers.setColorAt(fk++, fc.setHex(pal[Math.floor(fbm(x * 0.03, z * 0.03, 2) * 9 + rnd() * 1.5) % 5])); }
  flowers.count = fk; flowers.receiveShadow = true; flowers.layers.set(1); group.add(flowers);
  // ---- lake
  const water = createWater(G, { y: 0, streak: 0.03, chop: 0.32, scale: 1.3, deep: [0.01, 0.026, 0.022], waves: true, heightTex: htex, terr: TERR, parts: [[-2500, 2500, -2500, 75, 1, 1], [-300, 300, 75, 595, 240, 208], [-2500, -300, 75, 595, 1, 1], [300, 2500, 75, 595, 1, 1], [-2500, 2500, 595, 2500, 1, 1]] }); group.add(water);
  // ---- things people built
  const B = K.builder(), wood = K.mat("wood", { wet: 0.4 }), plank = K.mat("planks", { wet: 0.5, rough: 1.4 }), stone = K.mat("cobble", { wet: 0.5 }), roofM = K.mat("roof", { wet: 0.5 }), white = K.mat("plaster"), dark = K.flat(0x22252a, { rough: 0.5, metal: 0.6 });
  // cabin (door faces the lake, -x)
  const cx = 40, cz = 20, cy0 = 2.2; B.box(stone, 7.4, 0.5, 6.4, cx, cy0 - 0.3, cz, { col: true });
  for (const [w, d, x, z] of [[7, 0.25, 0, -2.9], [7, 0.25, 0, 2.9], [0.25, 6, 3.4, 0], [0.25, 2.2, -3.4, -1.9], [0.25, 2.2, -3.4, 1.9]]) B.box(wood, w, 2.8, d, cx + x, cy0 + 0.2, cz + z, { col: true, tile: 1.5 });
  B.box(wood, 0.25, 0.7, 1.6, cx - 3.4, cy0 + 2.3, cz, { tile: 1.5 }); B.box(plank, 6.6, 0.1, 5.6, cx, cy0 + 0.2, cz, { floor: true });
  for (const s of [-1, 1]) B.box(roofM, 8.2, 0.16, 4.3, cx, cy0 + 3.05 + 1.02, cz + s * 1.82, { rx: s * 0.56, tile: 3 }); for (const s of [-1, 1]) B.add(new THREE.CylinderGeometry(0.01, 3.6, 2.2, 3, 1).rotateY(Math.PI / 2), wood, cx + s * 3.45, cy0 + 4.1, cz, 0, 0, 0, [0.05, 1, 1]);
  B.box(stone, 1.0, 5.6, 1.0, cx + 2.2, cy0, cz - 2.2, { tile: 1 });
  const winM = K.glow(0xffb060, 0.25, { group: "cabin" }); B.box(winM, 1.4, 1.1, 0.06, cx - 0.5, cy0 + 1.3, cz + 3.0); B.box(winM, 0.06, 1.1, 1.3, cx - 3.5, cy0 + 1.3, cz + 1.9); B.box(winM, 1.4, 1.1, 0.06, cx + 1, cy0 + 1.3, cz - 3.0);
  K.light(group, "point", 0xffa050, 0.09, cx, cy0 + 2.2, cz, { dist: 14, group: "cabin" }); K.light(group, "point", 0xffb070, 0.03, cx - 4.4, cy0 + 2.4, cz, { dist: 12, group: "cabin" }); B.sph(K.glow(0xffc080, 6, { group: "cabin" }), 0.07, cx - 3.75, cy0 + 2.5, cz);
  // pier + boat
  for (let i = -3; i < 19; i++) { const x = 19 - i * 2; B.box(plank, 2, 0.1, 2.2, x, 0.55 + sstep(-8, -17, x) * 0.5, 15, { floor: true, tile: 1.6 }); for (const s of [-1, 1]) { B.cyl(wood, 0.09, 0.09, 2.9, x - 0.8, -1.8, 15 + s * 1.05, {}); if (i > -3) { B.cyl(wood, 0.035, 0.035, 0.95, x - 0.8, 0.6 + sstep(-8, -17, x) * 0.5, 15 + s * 1.05, {}); B.box(wood, 2, 0.05, 0.05, x, 1.5 + sstep(-8, -17, x) * 0.5, 15 + s * 1.05, {}); } } }
  B.cyl(dark, 0.03, 0.03, 1.5, 2.6, 0.6, 15.8, {}); B.sph(K.glow(0xffd9a0, 8, { group: "cabin" }), 0.08, 2.6, 2.15, 15.8); K.light(group, "point", 0xffc890, 0.035, 2.6, 2.2, 15.8, { dist: 14, group: "cabin" });
  const hull = new THREE.SphereGeometry(1, 14, 8, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2); B.add(hull, K.flat(0x2f5f7a, { rough: 0.5, side: THREE.DoubleSide }), 6, 0.42, 11.4, 0.5, 0, 0, [0.62, 0.45, 1.9]); B.box(wood, 1.0, 0.05, 0.25, 6, 0.3, 11.4, { ry: 0.5 });
  // campfire, tent, bench, fence, sign
  const fx = 31, fz = 12, fy = 1.6; for (let i = 0; i < 9; i++) { const a = (i / 9) * 6.28; B.sph(K.mat("rock"), 0.17, fx + Math.cos(a) * 0.6, fy + 0.06, fz + Math.sin(a) * 0.6, { s: [1, 0.7, 1] }); }
  for (let i = 0; i < 4; i++) B.cyl(wood, 0.06, 0.05, 0.9, fx, fy + 0.2, fz, { rz: 1.0, ry: i * 1.57 + 0.4 });
  const flame = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.75, 7), K.glow(0xff8a2a, 9, { group: "campfire", flicker: 0.5 })); flame.position.set(fx, fy + 0.5, fz); group.add(flame); const flame2 = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.5, 6), K.glow(0xffe08a, 16, { group: "campfire", flicker: 0.4 })); flame2.position.set(fx + 0.05, fy + 0.42, fz); group.add(flame2);
  K.light(group, "point", 0xff8030, 0.22, fx, fy + 0.7, fz, { dist: 22, group: "campfire", flicker: 0.45, shadow: true });
  B.add(new THREE.ConeGeometry(1.7, 1.7, 4, 1, true).rotateY(Math.PI / 4), K.flat(0xd9682a, { rough: 0.8, side: THREE.DoubleSide }), 35, 2.2 + 0.85, 6, 0.4, 0, 0, [1, 1, 1.4]);
  for (const s of [-1, 1]) { B.cyl(wood, 0.05, 0.05, 0.45, 26 + s * 0.7, H(26, 27), 27, {}); } B.box(plank, 1.8, 0.07, 0.45, 26, H(26, 27) + 0.45, 27, { tile: 1 }); B.box(plank, 1.8, 0.45, 0.06, 26, H(26, 27) + 0.6, 27.25, { tile: 1, rx: -0.2 });
  for (let i = 0; i < 22; i++) { const x = 50 + Math.cos(i * 0.21) * 16 - 16, z = 2 - i * 2.6, h = H(x, z); B.cyl(wood, 0.06, 0.05, 1.1, x, h - 0.1, z, {}); if (i) { const px = 50 + Math.cos((i - 1) * 0.21) * 16 - 16, pz = 2 - (i - 1) * 2.6, ph = H(px, pz), dx = x - px, dz = z - pz, L = Math.hypot(dx, dz);
      for (const y of [0.45, 0.85]) B.add(new THREE.BoxGeometry(L, 0.07, 0.04), wood, (x + px) / 2, (h + ph) / 2 + y, (z + pz) / 2, Math.atan2(-dz, dx), 0, Math.atan2(h - ph, L)); } }
  const sh = H(33, 18); B.cyl(wood, 0.05, 0.05, 2.2, 33, sh, 18, {}); const sign = (txt, y, ry) => { const t = K.canvasTex(256, 64, (g) => { g.fillStyle = "#5a4630"; g.fillRect(0, 0, 256, 64); g.fillStyle = "#f2e6c8"; g.font = "bold 34px sans-serif"; g.textAlign = "center"; g.textBaseline = "middle"; g.fillText(txt, 128, 34); });
    const m = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.26, 0.04), new THREE.MeshStandardMaterial({ map: t, roughness: 0.8 })); m.position.set(33, sh + y, 18); m.rotation.y = ry; m.castShadow = true; group.add(m); };
  sign("← 栈桥 · 湖", 2.0, 0.2); sign("孤树山丘 →", 1.68, 2.2); sign("灯塔 ↑", 1.36, -1.2);
  // lighthouse on the far shore
  const lx = -66, lz = -22, ly = 3.0; B.cyl(stone, 3.2, 3.0, 1.2, lx, ly - 0.6, lz, { seg: 20, col: true });
  const towerModel = G.sceneAssets.create("lighthouse", { height: 13.75 });
  if (towerModel) {
    towerModel.position.set(lx, ly + 0.6, lz); group.add(towerModel);
    B.colliders.push({ x0: lx - 1.7, x1: lx + 1.7, z0: lz - 1.7, z1: lz + 1.7, y0: ly + 0.6, y1: ly + 11.6 });
    const glass = new Map();
    const lightGlass = (material) => {
      if (material.name !== "Lantern glass") return material;
      if (!glass.has(material)) {
        const lit = material.clone();
        lit.transparent = true; lit.opacity = 0.44; lit.depthWrite = false;
        lit.roughness = 0.17; lit.metalness = 0;
        K.lit(lit, 0xffe4ad, 0.2, { map: lit.map, night: true, group: "lighthouse" });
        glass.set(material, lit);
      }
      return glass.get(material);
    };
    towerModel.traverse((mesh) => {
      if (!mesh.isMesh) return;
      if (Array.isArray(mesh.material)) mesh.material = mesh.material.map(lightGlass);
      else { mesh.material = lightGlass(mesh.material); if (mesh.material.transparent) mesh.castShadow = false; }
    });
  } else {
    B.cyl(white, 1.7, 1.15, 11, lx, ly + 0.6, lz, { seg: 20, col: true }); B.cyl(K.flat(0xb23a2e, { rough: 0.6 }), 1.5, 1.4, 1.6, lx, ly + 4.2, lz, { seg: 20 });
    B.cyl(dark, 1.6, 1.6, 0.15, lx, ly + 11.6, lz, { seg: 20 }); B.cyl(K.flat(0x99c4d8, { rough: 0.1, opacity: 0.35 }), 0.9, 0.9, 1.5, lx, ly + 11.75, lz, { seg: 12, open: true }); B.add(new THREE.ConeGeometry(1.25, 1.1, 12), K.flat(0xb23a2e, { rough: 0.6 }), lx, ly + 13.8, lz);
  }
  const lamp = new THREE.Group(); lamp.position.set(lx, ly + 12.5, lz); group.add(lamp); const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.3, 12, 8), K.glow(0xfff0c0, 3000, { night: true, group: 'lighthouse' })); lamp.add(bulb);
  const beamG = new THREE.CylinderGeometry(0.25, 5, 120, 16, 1, true).rotateZ(Math.PI / 2).translate(60, 0, 0); for (const s of [0, Math.PI]) { const bm = new THREE.Mesh(beamG, K.glow(0xfff0c0, 0.00002, { night: true, group: 'lighthouse', add: true, transparent: true, opacity: 1, side: THREE.DoubleSide, fog: false })); bm.rotation.y = s; lamp.add(bm); }
  const spot = K.light(lamp, "spot", 0xfff0c0, 220, 0, 0, 0, { dist: 260, angle: 0.09, pen: 0.5, night: true, group: 'lighthouse', target: [10, -0.6, 0] }); lamp.add(spot.l.target);
  // standing stones on the west meadow, windmill on the north hill
  for (let i = 0; i < 9; i++) { const a = (i / 9) * 6.28, x = -8 + Math.cos(a) * 6, z = -44 + Math.sin(a) * 6, hh = 1.6 + rnd() * 1.6; B.box(K.mat("rock"), 0.9, hh, 0.5, x, H(x, z) - 0.2, z, { ry: -a + 1.57 + (rnd() - 0.5) * 0.3, rz: (rnd() - 0.5) * 0.12, col: true, tile: 1.5 }); }
  B.cyl(white, 0.9, 0.35, 16, 8, 12, -72, { seg: 14, col: true }); const rotor = new THREE.Group(); rotor.position.set(8, 28.2, -70.9); group.add(rotor); for (let i = 0; i < 3; i++) { const bl = new THREE.Mesh(new THREE.BoxGeometry(0.5, 9, 0.08).translate(0, 4.6, 0), K.flat(0xf2f2f0, { rough: 0.4 })); bl.rotation.z = (i / 3) * 6.28; bl.castShadow = true; rotor.add(bl); } B.box(white, 1, 1, 2.4, 8, 27.7, -71.7, {});
  const fallU = { uTime: { value: 0 }, uCol: { value: new THREE.Vector3() } }, mistM = { color: { setRGB() {} } }, mist = [];
  // viewing deck by the pool, sea stacks off the beach, a sailing boat
  B.box(plank, 5, 0.12, 4, DK.x, H(DK.x, DK.z) + 0.5, DK.z, { floor: true, ry: 0.5, col: false }); for (const s of [-1, 1]) B.box(wood, 5, 1.0, 0.08, DK.x + s * 0.9, H(DK.x, DK.z) + 0.6, DK.z + s * 1.7, { ry: 0.5 });
  for (const [x, z, hh, w] of [[-30, 150, 26, 7], [-18, 162, 15, 5], [40, 158, 34, 9], [52, 170, 12, 4], [0, 190, 20, 6]]) { const g = new THREE.CylinderGeometry(w * 0.55, w, hh, 9, 6); const p = g.attributes.position; for (let i = 0; i < p.count; i++) { const n = 0.75 + 0.5 * fbm(p.getX(i) * 0.3 + x, p.getY(i) * 0.25 + p.getZ(i) * 0.3, 3); p.setX(i, p.getX(i) * n); p.setZ(i, p.getZ(i) * n); } g.computeVertexNormals(); const uvA = g.attributes.uv; for (let i = 0; i < uvA.count; i++) uvA.setXY(i, uvA.getX(i) * 6, uvA.getY(i) * hh / 4); B.add(g, K.mat("rock", { wet: 0.6, color: 0x7a746a }), x, hh / 2 - 3, z); }
  const sail = new THREE.Group(); group.add(sail); { const hullG = new THREE.SphereGeometry(1, 16, 8, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2); const hm = new THREE.Mesh(hullG, K.flat(0xf2efe6, { rough: 0.4, side: THREE.DoubleSide })); hm.scale.set(1.3, 1.0, 4.2); hm.position.y = 0.55; sail.add(hm); const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.07, 9, 8), K.flat(0xd8d2c4, { rough: 0.5 })); mast.position.y = 5; sail.add(mast);
    const sg = new THREE.BufferGeometry(); sg.setAttribute("position", new THREE.Float32BufferAttribute([0, 1.2, 0.2, 0, 9.2, 0.2, 0, 1.2, -3.6, 0, 1.4, 0.4, 0, 8.4, 0.4, 0, 1.4, 3.4], 3)); sg.computeVertexNormals(); const sm = new THREE.Mesh(sg, K.flat(0xfaf6ee, { rough: 0.8, side: THREE.DoubleSide })); sm.castShadow = true; sail.add(sm); hm.castShadow = mast.castShadow = true; }
  // ---- a long jetty from the beach out into the sea: ramp off the sand, deck on piles, railings, lamps, bollards, a T-head with a moored boat
  const ramps = []; { const jx = -6, z0 = 84, z1 = 158, dy = 1.7, gw = 3.2, dark2 = K.flat(0x2a2620, { rough: 0.7 });
    const gz = H(jx, 74); ramps.push({ x0: jx - gw / 2, x1: jx + gw / 2, z0: 73, z1: z0 + 0.1, axis: "z", a0: 74, a1: z0, y0: gz + 0.06, y1: dy });
    for (let z = 74; z < z0; z += 1) { const y = lerp(gz + 0.06, dy, (z + 0.5 - 74) / (z0 - 74)); B.box(plank, gw, 0.12, 1.02, jx, y - 0.12, z + 0.5, { tile: 1.6, rx: -Math.atan2(dy - gz, z0 - 74) }); }
    B.box(plank, gw, 0.14, z1 - z0, jx, dy - 0.14, (z0 + z1) / 2, { floor: true, tile: 1.6 }); B.box(plank, 14, 0.14, 7, jx, dy - 0.14, z1 + 3.5, { floor: true, tile: 1.6 }); B.floors.push({ x0: jx - gw / 2, x1: jx + gw / 2, z0, z1: z1 + 0.1, y: dy });
    for (let z = z0; z <= z1 + 7; z += 4) for (const q of z > z1 ? [-6.8, -2.4, 2.4, 6.8] : [-1.45, 1.45]) B.cyl(wood, 0.16, 0.16, 18, jx + q, dy - 18.1, z, { seg: 10 });
    for (const q of [-1, 1]) { const rx = jx + q * (gw / 2 - 0.05); B.colliders.push({ x0: rx - 0.05, x1: rx + 0.05, z0, z1, y0: dy, y1: dy + 1.05 }); for (const y of [0.5, 1.0]) B.box(wood, 0.07, 0.06, z1 - z0, rx, dy + y, (z0 + z1) / 2, {}); for (let z = z0; z <= z1; z += 2) B.box(wood, 0.09, 1.04, 0.09, rx, dy, z, {}); }
    for (let z = z0 + 6; z < z1; z += 12) { B.cyl(dark2, 0.06, 0.07, 4.2, jx + 1.45, dy, z, {}); B.sph(K.glow(0xffd9a8, 9, { night: true }), 0.16, jx + 1.45, dy + 4.25, z, { seg: 12, seg2: 8 }); }
    K.light(group, "point", 0xffd0a0, 0.06, jx + 1.3, dy + 4, z1 - 6, { dist: 16, night: true }); K.light(group, "point", 0xffd0a0, 0.06, jx + 1.3, dy + 4, (z0 + z1) / 2, { dist: 16, night: true });
    for (const [bx2, bz2] of [[-6.6, 0.4], [6.6, 0.4], [-6.6, 6.6], [6.6, 6.6], [0, 6.6]]) { B.add(lathe([[0, 0], [0.16, 0], [0.16, 0.25], [0.11, 0.32], [0.2, 0.42], [0.2, 0.47], [0, 0.47]], 14), dark2, jx + bx2, dy, z1 + bz2); }
    B.colliders.push({ x0: jx - 7, x1: jx + 7, z0: z1 + 6.9, z1: z1 + 7.2, y0: dy, y1: dy + 1 }); }
  // boats: a moored fishing boat, a motor yacht and a coaster under way, a second yacht far out; all ride the swell
  const boats = []; { const hull = (L, Wd, Hh, mat) => loft([{ p: [-L / 2, Hh * 0.62, 0], r: [Wd * 0.42, Hh * 0.48] }, { p: [-L * 0.3, Hh * 0.52, 0], r: [Wd * 0.5, Hh * 0.55] }, { p: [L * 0.18, Hh * 0.52, 0], r: [Wd * 0.48, Hh * 0.55] }, { p: [L * 0.42, Hh * 0.62, 0], r: [Wd * 0.28, Hh * 0.48] }, { p: [L / 2, Hh * 0.85, 0], r: [0.04, Hh * 0.3] }], { seg: 18, sub: 6 });
    const mk = (fn) => { const g = new THREE.Group(), b = K.builder(); fn(b); b.finish(g, { whole: true }); group.add(g); return g; };
    const white2 = K.flat(0xf2f0ea, { rough: 0.35 }), navy = K.flat(0x1c2a44, { rough: 0.4 }), redH = K.flat(0x8a1c18, { rough: 0.5 }), glassB = K.flat(0x101a22, { rough: 0.05, metal: 0.8 }), teak = K.mat("wood", { color: 0x9a6a3c });
    const fishing = mk((b) => { b.add(hull(9, 2.8, 1.6, K.flat(0x2a6a8a, { rough: 0.45 })), K.flat(0x2a6a8a, { rough: 0.45 })); b.box(white2, 3.0, 1.8, 2.0, -1.0, 1.4, 0, { bev: 0.06 }); b.box(glassB, 0.05, 0.6, 1.6, 0.52, 2.4, 0, {}); b.box(redH, 3.2, 0.12, 2.2, -1.0, 3.2, 0, {}); b.cyl(white2, 0.06, 0.06, 5, 1.6, 1.4, 0, {}); b.box(white2, 0.06, 0.06, 3.5, 1.6, 4.6, 0, {}); for (let i = 0; i < 5; i++) b.sph(K.flat([0xe8c020, 0xd84a1a][i % 2], { rough: 0.5 }), 0.18, 2.4 + (i % 2) * 0.4, 1.5, -0.7 + i * 0.35, { seg: 10, seg2: 8 }); b.sph(K.glow(0xfff0d0, 6, { night: true }), 0.1, 1.6, 6.4, 0); });
    const yacht = mk((b) => { b.add(hull(16, 4.2, 2.0, white2), white2); b.box(white2, 7, 1.4, 3.4, -1.0, 1.8, 0, { bev: 0.3 }); b.box(glassB, 6.6, 0.7, 3.5, -1.0, 2.2, 0, { bev: 0.1 }); b.box(white2, 4, 1.0, 3.0, -1.8, 3.2, 0, { bev: 0.25 }); b.box(glassB, 3.6, 0.55, 3.1, -1.6, 3.45, 0, { bev: 0.1 }); b.box(teak, 4, 0.06, 3.6, -6.0, 1.75, 0, {}); b.box(navy, 15, 0.25, 4.25, 0, 0.9, 0, { bev: 0.1 }); for (let i = 0; i < 8; i++) b.box(K.glow(0xffe8c0, 0.8, { night: true }), 0.6, 0.3, 0.05, -4 + i * 1, 2.25, 1.76, { bev: 0 }); });
    const coaster = mk((b) => { b.box(redH, 46, 3.5, 9, 0, 0, 0, { bev: 0.3 }); b.box(K.flat(0x2a2c30, { rough: 0.6 }), 46.2, 3.2, 9.2, 0, 3.4, 0, { bev: 0.2 }); for (let i = 0; i < 12; i++) b.box(K.flat([0x2a6a9a, 0xb8221a, 0xd9b21c, 0x1f6a44, 0x8a8f96][i % 5], { rough: 0.6, metal: 0.3 }), 6, 2.6, 2.5, -14 + (i % 4) * 6.3, 6.6 + Math.floor(i / 8) * 2.6, -3 + (Math.floor(i / 4) % 2) * 5.5, { bev: 0.04 }); b.box(white2, 6, 7, 8, 18, 6.6, 0, { bev: 0.1 }); b.box(glassB, 0.05, 1, 7, 14.95, 11.5, 0, {}); b.cyl(K.flat(0x111111, { rough: 0.6 }), 0.9, 0.9, 3, 19, 13.6, 0, {}); b.sph(K.glow(0xff2a1a, 8, { night: true }), 0.2, 18, 15, 3.5); b.sph(K.glow(0x2aff4a, 8, { night: true }), 0.2, 18, 15, -3.5); });
    const sail2 = sail.clone(); group.add(sail2);
    boats.push({ g: fishing, at: () => [-6 + 9.5, 158 + 3.5], yaw: 0, draft: 0.5, k: 0.6 }, { g: yacht, at: (t) => [-170 + ((t * 4) % 380), 260], yaw: 0, draft: 0.8, k: 1 }, { g: coaster, at: (t) => [260 - ((t * 2.2) % 560), 470], yaw: Math.PI, draft: 1.2, k: 0.6 }, { g: sail2, at: (t) => [80 + Math.sin(t * 0.012) * 70, 330 + Math.cos(t * 0.009) * 30], yaw: 0, draft: 0, k: 1, sail: true }); }
  // a far range of great peaks beyond the valley walls (aerial perspective turns them blue), snow above ~260 m
  { const pos = [], col = [], idx = [], NA = 640, NR = 22, rp = rng(77); const pk = [...Array(12)].map(() => [rp() * 6.283, 150 + rp() * 190, 0.22 + rp() * 0.35]);
    for (let j = 0; j <= NR; j++) for (let i = 0; i <= NA; i++) { const a = (i / NA) * 6.283, t = j / NR, rr = 520 + t * 900; let hh = 0; for (const [pa, ph, pw] of pk) { const da = Math.abs(((a - pa + 9.42) % 6.283) - 3.14); hh = Math.max(hh, ph * Math.pow(Math.max(0, 1 - da / pw), 1.1)); }
      const rid = 1 - Math.abs(fbm(Math.cos(a) * 6 + t * 2, Math.sin(a) * 6 + 3, 5) * 2 - 1), rid2 = 1 - Math.abs(fbm(Math.cos(a) * 21 + t * 6, Math.sin(a) * 21 + 7, 4) * 2 - 1); let y = (hh * (0.55 + 0.45 * rid) + 90 * Math.pow(rid, 3) + 45 * Math.pow(rid2, 3) + 18 * fbm(a * 40, t * 9, 3)) * Math.sin(Math.PI * Math.min(1, t * 1.6)) - 8; { const gap = sstep(0.78, 0.9, Math.sin(a)); y = lerp(y, -60, gap); } /* the ring opens fully towards the sea: no low dark wall on the horizon */
      pos.push(Math.cos(a) * rr, y, Math.sin(a) * rr); const sn = sstep(250, 300, y + 70 * (fbm(a * 46, t * 11, 3) - 0.5) + 30 * rid2) * sstep(0.42, 0.7, fbm(a * 150, t * 26, 3) * 0.7 + rid2 * 0.45), rk = 0.055 + 0.035 * fbm(a * 30, t * 9, 2); col.push(lerp(rk, 0.92, sn), lerp(rk * 0.98, 0.94, sn), lerp(rk * 0.95, 0.98, sn)); }
    for (let j = 0; j < NR; j++) for (let i = 0; i < NA; i++) { const a0 = j * (NA + 1) + i, b0 = a0 + 1, c0 = a0 + NA + 1, d0 = c0 + 1; idx.push(a0, b0, c0, b0, d0, c0); }
    // islands and a far coast out to sea, so the horizon is never an empty line
    { const ri = rng(91); for (let n = 0; n < 9; n++) { const ang = 1.57 + (ri() - 0.5) * 1.5, dd = 1100 + ri() * 1100, cx = Math.cos(ang) * dd, cz = Math.sin(ang) * dd, R = 90 + ri() * 260, Hh = 25 + ri() * 90 * (R / 250), NI = 24, base = pos.length / 3;
        for (let j = 0; j <= 6; j++) for (let i = 0; i <= NI; i++) { const t = j / 6, aa = (i / NI) * 6.283, rr = R * (1 - t) * (0.8 + 0.4 * fbm(Math.cos(aa) * 3 + n, Math.sin(aa) * 3, 3)), h = j === 0 ? -6 : Hh * Math.pow(Math.sin(t * Math.PI / 2), 1.5) * (0.7 + 0.5 * fbm(aa * 2 + n * 7, t * 3, 3)); pos.push(cx + Math.cos(aa) * rr, h, cz + Math.sin(aa) * rr * 0.7); const k2 = 0.05 + 0.03 * fbm(aa * 6, t * 5 + n, 2); col.push(k2 * 0.8, k2 * 1.05, k2 * 0.75); }
        for (let j = 0; j < 6; j++) for (let i = 0; i < NI; i++) { const a0 = base + j * (NI + 1) + i, b0 = a0 + 1, c0 = a0 + NI + 1, d0 = c0 + 1; idx.push(a0, c0, b0, b0, c0, d0); } } }
    const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute("color", new THREE.Float32BufferAttribute(col, 3)); g.setIndex(idx); g.computeVertexNormals(); const far = new THREE.Mesh(g, K.flat(0xffffff, { rough: 0.85, vc: true, detail: false })); far.castShadow = false; far.receiveShadow = false; far.userData.noCull = true; group.add(far); }
  // ---- close-range detail: reeds and lily pads along the shore, pebbles, shrubs, fallen logs, stumps and mushrooms
  { const rd = rng(61), shore = (a) => { for (let d = LAKE.r + 14; d > LAKE.r - 16; d -= 0.5) { const x = LAKE.x + Math.cos(a) * d, z = LAKE.z + (Math.sin(a) * d) / 1.25, h = H(x, z); if (h < 0.12) return { x, z, h }; } return null; };
    const rp = [], rc = [], ri = []; for (let b = 0; b < 11; b++) { const a = rd() * 6.28, ox = (rd() - 0.5) * 0.5, oz = (rd() - 0.5) * 0.5, hh = 1.1 + rd() * 1.1, w = 0.012 + rd() * 0.012, lean = (rd() - 0.3) * 0.5, c = Math.cos(a), sn = Math.sin(a), q = rp.length / 3; for (const [u, v] of [[-1, 0], [1, 0], [-0.7, 0.55], [0.7, 0.55], [0, 1]]) { rp.push(ox + c * u * w + sn * lean * v * v, v * hh - 0.3, oz + sn * u * w - c * lean * v * v); const k = 0.5 + 0.5 * v; rc.push(0.05 * k + 0.04 * v, 0.1 * k + 0.05 * v, 0.03 * k); } ri.push(q, q + 1, q + 2, q + 1, q + 3, q + 2, q + 2, q + 3, q + 4);
      if (b % 3 === 0) { const cy = new THREE.CylinderGeometry(0.022, 0.022, 0.2, 6).translate(ox + sn * lean, hh - 0.36, oz - c * lean), p2 = cy.toNonIndexed().attributes.position, q2 = rp.length / 3; for (let i = 0; i < p2.count; i++) { rp.push(p2.getX(i), p2.getY(i), p2.getZ(i)); rc.push(0.09, 0.045, 0.02); ri.push(q2 + i); } } }
    const rgeo = new THREE.BufferGeometry(); rgeo.setAttribute("position", new THREE.Float32BufferAttribute(rp, 3)); rgeo.setAttribute("color", new THREE.Float32BufferAttribute(rc, 3)); rgeo.setIndex(ri); rgeo.computeVertexNormals();
    const reeds = new THREE.InstancedMesh(rgeo, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.7, side: THREE.DoubleSide }), 900), pads = new THREE.InstancedMesh(new THREE.CircleGeometry(0.26, 14, 0.25, 5.9).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x2f5a26, roughness: 0.45, side: THREE.DoubleSide }), 260), rgLow = (() => { const g = new THREE.IcosahedronGeometry(1, 1), p = g.attributes.position; for (let i = 0; i < p.count; i++) { const k = 0.8 + 0.4 * vnoise(p.getX(i) * 2 + 3, p.getY(i) * 2 + p.getZ(i) * 2); p.setXYZ(i, p.getX(i) * k, p.getY(i) * k, p.getZ(i) * k); } g.computeVertexNormals(); return g; })(), peb = new THREE.InstancedMesh(rgLow, K.mat("rock", { wet: 1 }), 2600);
    let nr = 0, np = 0, nb = 0; for (let i = 0; i < 4000 && (nr < 900 || nb < 2600); i++) { const a = rd() * 6.28, sp = shore(a); if (!sp) continue; const clump = vnoise(a * 9, 2) > 0.45; if (clump && nr < 900) for (let k = 0; k < 3 && nr < 900; k++) { const x = sp.x + (rd() - 0.5) * 2.2, z = sp.z + (rd() - 0.5) * 2.2, h = H(x, z); if (h > 0.3 || h < -0.5) continue; reeds.setMatrixAt(nr++, m4.compose(v3.set(x, Math.max(h, -0.25), z), q4.setFromEuler(e4.set(0, rd() * 6.28, 0)), s3.setScalar(0.8 + rd() * 0.6))); }
      if (nb < 2600) for (let k = 0; k < 2; k++) { const x = sp.x + (rd() - 0.5) * 5, z = sp.z + (rd() - 0.5) * 5, h = H(x, z); if (h < -0.4 || h > 1.2) continue; const sc = 0.03 + Math.pow(rd(), 2) * 0.16; peb.setMatrixAt(nb++, m4.compose(v3.set(x, h + sc * 0.2, z), q4.setFromEuler(e4.set(rd() * 3, rd() * 6, rd() * 3)), s3.set(sc, sc * (0.4 + rd() * 0.4), sc * (0.7 + rd() * 0.6)))); }
      if (!clump && np < 260 && rd() < 0.5) { const d = 2 + rd() * 5, x = sp.x - Math.cos(a) * d, z = sp.z - (Math.sin(a) * d) / 1.25; if (H(x, z) < -0.3 && Math.hypot((x - ISLE.x) * 1.25, z - ISLE.z) > 28) pads.setMatrixAt(np++, m4.compose(v3.set(x, 0.03, z), q4.setFromEuler(e4.set(0, rd() * 6.28, 0)), s3.setScalar(0.7 + rd() * 0.9))); } }
    reeds.count = nr; pads.count = np; peb.count = nb; reeds.castShadow = true; peb.layers.set(1); pads.layers.set(1); reeds.receiveShadow = pads.receiveShadow = peb.receiveShadow = true; for (const o of [reeds, pads, peb]) { o.frustumCulled = false; group.add(o); }
    const shrubs = []; for (let i = 0; i < 4000 && shrubs.length < 170; i++) { const a = rd() * 6.28, d = 14 + Math.sqrt(rd()) * 90, x = 6 + Math.cos(a) * d, z = 4 + Math.sin(a) * d, h = H(x, z); if (h < 0.9 || h > 12 || slope(x, z) > 0.5 || clear(x, z) || forestN(x, z) < 0.36) continue; shrubs.push({ x, y: h - 0.25, z, s: 0.32 + rd() * 0.3, ry: rd() * 6.28 }); }
    forest(K, makeTree("leafy", 71, { h: 0.5, depth: 2, cards: 9, leaf: 1.5 }), { bark, leaf: fol.leafy }, shrubs.slice(0, 85), group); forest(K, makeTree("leafy", 73, { h: 0.3, depth: 2, cards: 11, leaf: 1.8 }), { bark, leaf: fol.leafy }, shrubs.slice(85), group);
    const moss = K.flat(0x3c5226, { rough: 0.95 }), cap = K.flat(0xa8442a, { rough: 0.5 }), stem = K.flat(0xe6dcc6, { rough: 0.7 });
    for (let i = 0; i < 400 && i < 4000; i++) { const a = rd() * 6.28, d = 12 + rd() * 80, x = 20 + Math.cos(a) * d, z = 2 + Math.sin(a) * d, h = H(x, z); if (h < 1 || h > 11 || slope(x, z) > 0.35 || clear(x, z)) continue; const k = i % 9;
      if (k === 0) { const ry = rd() * 3.14, L2 = 2.2 + rd() * 2.4, c = Math.cos(ry), sn = Math.sin(ry), rr = 0.16 + rd() * 0.12; B.add(loft([{ p: [x - c * L2 / 2, h + rr * 0.8, z - sn * L2 / 2], r: rr * 1.1 }, { p: [x, h + rr * 0.75, z], r: rr }, { p: [x + c * L2 / 2, H(x + c * L2 / 2, z + sn * L2 / 2) + rr * 0.7, z + sn * L2 / 2], r: rr * 0.8 }], { seg: 12, capK: 0.15 }), bark); B.add(loft([{ p: [x - c * 0.6, h + rr * 1.5, z - sn * 0.6], r: [rr * 0.7, 0.03] }, { p: [x + c * 0.5, h + rr * 1.45, z + sn * 0.5], r: [rr * 0.6, 0.03] }], { seg: 8, up: [0, 1, 0] }), moss); circles.push({ x, z, r: 0.5 }); }
      else if (k === 1) { B.add(lathe([[0, 0], [0.34, 0], [0.3, 0.12], [0.26, 0.4], [0.25, 0.46], [0, 0.48]], 14), bark, x, h - 0.1, z); circles.push({ x, z, r: 0.35 }); }
      else if (k < 5) for (let q = 0; q < 3; q++) { const mx = x + (rd() - 0.5) * 0.5, mz = z + (rd() - 0.5) * 0.5, s2 = 0.5 + rd() * 0.8; B.add(lathe([[0, 0], [0.012, 0], [0.01, 0.07], [0, 0.07]], 6), stem, mx, H(mx, mz), mz, 0, 0, 0, s2); B.add(lathe([[0, 0.06], [0.045, 0.06], [0.04, 0.08], [0.02, 0.1], [0, 0.105]], 10), cap, mx, H(mx, mz), mz, 0, 0, 0, s2); } } }
  // the villa on the island, rotated a quarter turn so its doors face the bridge (local +z -> world +x)
  const V = buildVilla(G, { embed: true }); V.group.position.set(ISLE.x, ISLE.y, ISLE.z); V.group.rotation.y = Math.PI / 2; group.add(V.group);
  const vx = (x, z) => ISLE.x + z, vz = (x, z) => ISLE.z - x, inside = (x, z) => Math.abs(ISLE.z - z) < V.X + 0.3 && Math.abs(x - ISLE.x) < V.Z + 0.3;
  for (const c of V.colliders) B.colliders.push({ x0: ISLE.x + c.z0, x1: ISLE.x + c.z1, z0: ISLE.z - c.x1, z1: ISLE.z - c.x0, y0: c.y0 + ISLE.y, y1: c.y1 + ISLE.y });
  for (const f of V.floors) B.floors.push({ x0: ISLE.x + f.z0, x1: ISLE.x + f.z1, z0: ISLE.z - f.x1, z1: ISLE.z - f.x0, y: f.y + ISLE.y }); B.floors.push({ x0: ISLE.x - V.Z, x1: ISLE.x + V.Z + 0.4, z0: ISLE.z - V.X, z1: ISLE.z + V.X, y: ISLE.y });
  const VS = V.spots.map((q) => ({ name: "别墅 · " + q.name, x: vx(q.x, q.z), z: vz(q.x, q.z), y: ISLE.y, yaw: (q.yaw || 0) + Math.PI / 2, pitch: q.pitch || 0 })), VSND = V.sounds.map((q) => ({ ...q, x: vx(q.x, q.z), z: vz(q.x, q.z) }));
  B.box(stone, 5, 0.3, 4.4, ISLE.x + V.Z + 3.6, ISLE.y - 0.5, 15, { floor: true, tile: 1.5 });
  B.finish(group);
  const floors = B.floors, colliders = B.colliders;
  const L = { mirror: { y: 0 }, ramps, rainBox: { x0: ISLE.x - V.Z - 0.6, x1: ISLE.x + V.Z + 0.6, z0: ISLE.z - V.X - 0.6, z1: ISLE.z + V.X + 0.6, y: ISLE.y + V.H + 5 }, startTime: 14, name: "自然风光", group, colliders, circles, floors, indoor: false, probeSkyOnly: true, pollution: 0.06, envScale: 1.6, shadowSize: 46, spawn: { x: 30, z: 15.5, yaw: 1.45 }, bounds: 185, water: 0,
    sounds: [{ type: "water", x: LAKE.x, z: LAKE.z, r: 85 }, ...VSND, { type: "sea", x: 5, z: 150, r: 110 }, { type: "fire", x: 31, z: 12, r: 14 }], fallPos: FALL, mesa: MESA,
    spots: [{ name: "营地", x: 30, z: 15.5, yaw: 1.45 }, { name: "海边码头", x: -6, z: 150, y: 1.7, yaw: Math.PI, pitch: 0.02 }, { name: "码头看海浪", x: -2, z: 90, y: 1.7, yaw: Math.PI, pitch: -0.1 }, { name: "雪山（远景）", x: 30, z: -20, y: 30, yaw: -0.6, pitch: 0.12, fly: true }, { name: "海崖观景台", x: DK.x, z: DK.z, y: H(DK.x, DK.z) + 0.62, yaw: Math.atan2(-(FALL.x - DK.x), -(FALL.z - DK.z)), pitch: 0.28 }, { name: "海崖顶", x: FALL.x + 6, z: FALL.z + 9, yaw: 1.9, pitch: -0.25 }, { name: "海滩", x: 6, z: 104, yaw: Math.PI, pitch: 0 }, { name: "峡湾上空", x: 6, z: 60, y: 70, yaw: Math.PI, pitch: -0.25, fly: true }, { name: "湖心栈桥", x: 4, z: 15, yaw: 1.57 }, ...VS, { name: "孤树山丘", x: 40, z: -26, yaw: -0.8 }, { name: "灯塔脚下", x: -58, z: -18, yaw: 1.2 }, { name: "石阵", x: -8, z: -34, yaw: 0 }, { name: "湖对岸看小屋", x: -70, z: 30, yaw: -1.5 }, { name: "风车山顶", x: 12, z: -64, yaw: 2.6 }],
    groups: [["lighthouse", "灯塔", true], ["campfire", "营火", true], ["cabin", "小屋与栈桥灯", true], ...V.groups.map(([g, n, on]) => [g, "别墅 · " + n, on])], lake: LAKE,
    groundAt: (x, z) => (inside(x, z) ? ISLE.y : H(x, z)), slope, inside, villaSpawn: VS[0], pets: [...V.pets.map(([k, x, z]) => [k, ISLE.x + z, ISLE.z - x]), ["catL", 33, 17], ["catT", 27, 13], ["cat", 36, 10], ["catC", 4, 80], ["catW", -14, 78]],
    randGround: (r, r0 = 10, r1 = 90, wantWater = false, home = null) => { for (let i = 0; i < 80; i++) { const a = r() * 6.28, d = r0 + r() * (r1 - r0), x = (home ? home.x : 20) + Math.cos(a) * d, z = (home ? home.z : 0) + Math.sin(a) * d, h = H(x, z); if (!(home && Math.hypot((home.x - ISLE.x) * 1.25, home.z - ISLE.z) < 31) && Math.hypot((x - ISLE.x) * 1.25, z - ISLE.z) < 31) continue; if (wantWater ? h < -1 : h > 0.8 && h < 14 && slope(x, z) < 0.5) return { x, z, y: h }; } return { x: 30, z: 0, y: H(30, 0) }; },
    update(dt, t, G) { const m = G.m, sky = G.sky, E = sky.sunE, a = sky.ambient; water.userData.update(dt, t, G);
      gu.uCam.value.copy(G.camera.position); gu.uTime.value = t; fallU.uTime.value = t; { const c = [0, 1, 2].map((i) => (a[i] * 2.6 + E[i] * 0.22) * m); fallU.uCol.value.set(c[0], c[1], c[2]); mistM.color.setRGB(c[0] * 0.75, c[1] * 0.75, c[2] * 0.75); mist.forEach((sp, i) => { const u = sp.userData, w = Math.sin(t * 0.13 + u.p); sp.position.set(POOL.x - 3 - i * 5 + w * 2, 5 + i * 1.5 + Math.sin(t * 0.2 + u.p) * 0.8, POOL.z + w * 3 - i * 2); sp.scale.set(u.s * (1 + 0.08 * w), u.s * 0.5, 1); }); V.update(dt, t, G); { const sx = -40 + Math.sin(t * 0.01) * 60, sz = 175 + Math.cos(t * 0.013) * 25; sail.position.set(sx, waveY(sx, sz, t) * 0.9, sz); sail.rotation.x = (waveY(sx + 2, sz, t) - waveY(sx - 2, sz, t)) * 0.12; } for (const b of boats) { const [bx, bz] = b.at(t), y = waveY(bx, bz, t) * b.k; b.g.position.set(bx, y - b.draft, bz); if (!b.sail) b.g.rotation.y = b.yaw; b.g.rotation.z = (waveY(bx + 3, bz, t) - waveY(bx - 3, bz, t)) * 0.08 * b.k; b.g.rotation.x = (waveY(bx, bz + 3, t) - waveY(bx, bz - 3, t)) * 0.06 * b.k; } sail.rotation.y = Math.cos(t * 0.01) > 0 ? 1.57 : -1.57; sail.rotation.z = Math.sin(t * 0.7) * 0.04; } lamp.rotation.y = t * 0.5; rotor.rotation.z = t * 0.7; flame.scale.y = 1 + 0.25 * Math.sin(t * 17) * Math.sin(t * 7.1); flame.rotation.y = t * 3; flame2.scale.y = 1 + 0.3 * Math.sin(t * 23 + 1); },
    dispose() { htex.dispose(); water.material.dispose(); } };
  return L;
}
