// Hong Kong Island seen across Victoria Harbour, described entirely in code (no model): towers are plain prisms whose curtain walls are drawn
// by a shader from world position (floors, mullions, office / flat lighting that varies per floor and per window, LED façades, glowing crowns),
// so there are no coplanar faces to flicker at 1 km. Layout follows the real waterfront: Sheung Wan / Central on the right of a viewer in
// Tsim Sha Tsui, then Admiralty, Wan Chai and the Convention Centre on the left; the Peak and the Mid-Levels rise behind.
import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { rng, vnoise } from "./util.js";

const FACADE_V = `attribute vec4 aB; attribute vec3 aC; attribute float aX; varying vec4 vB; varying vec3 vC; varying vec3 vFp; varying vec3 vFn; varying float vX;`;
const FACADE_F = `varying vec4 vB; varying vec3 vC; varying vec3 vFp; varying vec3 vFn; varying float vX; uniform float uT, uLit, uDay;
float fh1(vec3 p){ p = fract(p * vec3(0.1031, 0.1030, 0.0973)); p += dot(p, p.yxz + 33.33); return fract((p.x + p.y) * p.z); }
vec3 rainbow(float t){ return clamp(abs(fract(t + vec3(0.0, 0.333, 0.667)) * 6.0 - 3.0) - 1.0, 0.0, 1.0); }`;

export function buildIsland(G, group, o) {
  const K = G.kit, r = rng(o.seed || 1897), SH = o.shore, Y0 = o.y0 ?? -1.2, list = [], uni = { uT: { value: 0 }, uLit: { value: 0.6 }, uDay: { value: 1 } };
  // ---- one material for every tower: base colour / glass from aC, windows and lights from the shader
  const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.35, metalness: 0.5, emissive: 0xffffff });
  K.lit(mat, 0xffffff, 0.17, { night: true });
  mat.onBeforeCompile = (sh) => { Object.assign(sh.uniforms, uni);
    sh.vertexShader = sh.vertexShader.replace("#include <common>", "#include <common>\n" + FACADE_V).replace("#include <begin_vertex>", "#include <begin_vertex>\n vB = aB; vC = aC; vX = aX; vFp = (modelMatrix * vec4(position, 1.0)).xyz; vFn = normalize(mat3(modelMatrix) * normal);");
    sh.fragmentShader = sh.fragmentShader.replace("#include <common>", "#include <common>\n" + FACADE_F)
      .replace("#include <color_fragment>", `#include <color_fragment>
        float fSide = 1.0 - step(0.6, abs(vFn.y)); float fU = abs(vFn.x) > abs(vFn.z) ? vFp.z * sign(vFn.x) : -vFp.x * sign(vFn.z); float fY = vFp.y - vB.w;
        float fFl = vB.y, fCw = vB.z, kind = floor(vB.x + 1e-3), seed = floor(fract(vB.x + 1e-3) * 977.0); /* quantised: interpolation jitter must not reach the hash */
        vec2 fc = vec2(fU / fCw, fY / fFl), fi = floor(fc), ff = fract(fc); vec2 fw = fwidth(fc);
        float aaX = smoothstep(0.32, 0.75, fw.x), aaY = smoothstep(0.32, 0.75, fw.y), fAA = max(aaX, aaY); // sub-pixel columns / floors fade to their average, separately, so distant walls keep their floor pattern but never sparkle
        float glassW = kind > 0.5 && kind < 1.5 ? 0.5 : 0.72, glassH = kind > 0.5 && kind < 1.5 ? 0.55 : 0.62;
        float mx = smoothstep(0.5 - glassW * 0.5 - fw.x, 0.5 - glassW * 0.5 + fw.x, ff.x) * (1.0 - smoothstep(0.5 + glassW * 0.5 - fw.x, 0.5 + glassW * 0.5 + fw.x, ff.x));
        float my = smoothstep(0.12 - fw.y, 0.12 + fw.y, ff.y) * (1.0 - smoothstep(0.12 + glassH - fw.y, 0.12 + glassH + fw.y, ff.y));
        float fWin = mix(mx, glassW, aaX) * mix(my, glassH, aaY) * fSide;
        float fh = fh1(vec3(fi, seed)), fEpoch = floor(uT * 0.035 + seed * 0.37 + fi.y * 0.061), fflo = fh1(vec3(fEpoch, fi.y, seed + 3.0)), fWinE = floor(uT * 0.02 + fh * 13.0);
        float fhA = mix(fh, 0.5, aaX); vec3 frameC = vC, glassC = mix(vec3(0.05, 0.07, 0.085), vC * 0.35, 0.35) * (0.8 + 0.4 * fhA);
        diffuseColor.rgb = mix(frameC * (0.85 + 0.3 * fflo), glassC, fWin);`)
      .replace("#include <roughnessmap_fragment>", "#include <roughnessmap_fragment>\n roughnessFactor = mix(0.7, 0.08 + 0.1 * fhA, fWin);")
      .replace("#include <metalnessmap_fragment>", "#include <metalnessmap_fragment>\n metalnessFactor = mix(0.1, 0.85, fWin);")
      .replace("#include <emissivemap_fragment>", `#include <emissivemap_fragment>
        { float office = kind < 0.5 ? 1.0 : 0.0, resi = kind > 0.5 && kind < 1.5 ? 1.0 : 0.0;
          // offices light whole floors (some left dark); flats are lit window by window; colour from 3000 K to cool fluorescent
          // every building has its own occupancy and brightness: some nearly dark, some blazing, so the skyline reads building by building
          float bh = fh1(vec3(seed, 1.7, 3.3)), bLit = clamp(uLit * mix(0.08, 1.9, bh * bh * (3.0 - 2.0 * bh)), 0.03, 0.97), bGain = mix(0.55, 1.6, fh1(vec3(seed, 9.1, 0.4)));
          float floorOn = mix(step(fflo, bLit), bLit, aaY);
          float fhw = fh1(vec3(fi, seed + fWinE)); float on = office * floorOn * mix(step(0.18, fh), 0.82, aaX) + resi * mix(step(fhw, bLit * 0.82), bLit * 0.82, max(aaX, aaY)) + (1.0 - office - resi) * mix(step(fflo, bLit * 0.9), bLit * 0.9, aaY);
          float warm = office > 0.5 ? 1.0 - step(0.3, fh1(vec3(fi.y, seed, 7.0))) : mix(1.0 - step(0.72, fh), 0.72, aaX);
          vec3 ec = mix(vec3(0.78, 0.92, 1.0), vec3(1.0, 0.62, 0.3), warm) * mix(0.55 + 0.9 * fh1(vec3(fi, seed + 11.0)), 1.0, aaX);
          float flick = step(0.985, fh1(vec3(fi, floor(uT * 9.0)))) * step(0.9, fh); vec3 em = ec * on * fWin * bGain * (1.0 - flick * 0.8);
          if (kind > 1.5 && kind < 2.5) { // LED façades, four programmes: spectrum bands, a vertical sweep, a slow colour wash, a sparkle grid
            float prog = mod(seed, 4.0), band = mix(smoothstep(0.1, 0.25, ff.y) * (1.0 - smoothstep(0.75, 0.9, ff.y)), 0.65, aaY); vec3 led;
            if (prog < 1.0) led = rainbow(fi.y * 0.045 - uT * 0.06 + seed * 0.1) * band;
            else if (prog < 2.0) led = mix(vec3(0.15, 0.4, 1.0), vec3(1.0, 0.2, 0.6), 0.5 + 0.5 * sin(fY * 0.05 - uT * 0.8)) * band * (0.4 + 0.6 * smoothstep(0.6, 1.0, sin(fY * 0.03 - uT * 0.5)));
            else if (prog < 3.0) led = rainbow(uT * 0.015 + seed * 0.1) * 0.8 * mix(mx * my, 0.45, max(aaX, aaY));
            else led = vec3(0.7, 0.85, 1.0) * mix(step(0.7, fract(fh * 7.0 + uT * 0.3)), 0.3, max(aaX, aaY)) * mix(mx * my, 0.45, max(aaX, aaY));
            em = em * 0.4 + led * fSide * 1.8; }
          if (kind > 2.5) { float crown = smoothstep(vX - 1.0, vX, fY); em += mix(vec3(1.0, 0.35, 0.15), vec3(0.2, 0.5, 1.0), 0.5 + 0.5 * sin(uT * 0.25 + seed)) * crown * 1.6; }
          totalEmissiveRadiance *= em; }`);
    mat.userData.shader = sh; };
  mat.customProgramCacheKey = () => "hkIsland";
  // kind: 0 office glass, 1 residential, 2 LED-band façade, 3 office whose top (above aX metres) glows
  const add = (geo, x, y, z, ry, kind, flH, colW, color, seed, crown = 1e6) => { geo = geo.index ? geo.toNonIndexed() : geo; for (const k of Object.keys(geo.attributes)) if (k !== "position" && k !== "normal") geo.deleteAttribute(k);
    geo.rotateY(ry || 0); geo.translate(x, y, z); const n = geo.attributes.position.count, B = new Float32Array(n * 4), C = new Float32Array(n * 3), X = new Float32Array(n).fill(crown), c = new THREE.Color(color);
    const sd = (Math.floor((seed ?? r()) * 900) + 0.5) / 977; for (let i = 0; i < n; i++) { B.set([kind + sd, flH, colW, Y0], i * 4); C.set([c.r, c.g, c.b], i * 3); }
    geo.setAttribute("aB", new THREE.BufferAttribute(B, 4)); geo.setAttribute("aC", new THREE.BufferAttribute(C, 3)); geo.setAttribute("aX", new THREE.BufferAttribute(X, 1)); list.push(geo); };
  const box = (w, h, d) => new THREE.BoxGeometry(w, h, d).translate(0, h / 2, 0);
  const prism = (rad, h, seg, rot = 0) => new THREE.CylinderGeometry(rad, rad, h, seg, 1).rotateY(rot).translate(0, h / 2, 0);
  const tower = (x, z, w, d, h, kind = 0, o2 = {}) => { const y = o2.y ?? Y0, flH = o2.fl || (kind === 1 ? 2.9 : 3.8), colW = o2.cw || (kind === 1 ? 2.6 : 1.6), col = o2.color ?? [0x9aa4ac, 0xb8b2a4, 0x7d8a90, 0xc9c4b8, 0x5d6b74, 0xa8b4b8][Math.floor(r() * 6)];
    const g = o2.round ? prism(w / 2, h, o2.round) : o2.oct ? prism(w / 2 / Math.cos(Math.PI / 8), h, 8, Math.PI / 8) : box(w, h, d); add(g, x, y, z, o2.ry || 0, kind, flH, colW, col, o2.seed);
    if (!o2.flat && h > 60 && r() < 0.55) add(box(w * 0.6, Math.min(12, h * 0.07), d * 0.6), x, y + h - 0.5, z, o2.ry || 0, 0, 4, 3, 0x6a6e72); // plant room on the roof (inset: never shares a face)
    return y + h; };
  const crownT = (x, z, w, h, hc, color, ry = 0) => { const g = box(w, h, w); add(g, x, Y0, z, ry, 3, 3.8, 1.6, color, undefined, h - hc); };

  // ---- the landmarks (heights ~0.65 of real so the skyline sits in a photographer's frame from 1 km)
  const S = 0.65, Z = (dz) => SH + dz, tops = [];
  // Two IFC: tapering shaft with stepped crown "claws"
  { const x = -230, z = Z(40); let y = Y0, w = 52; for (const [hh, k] of [[150, 1], [70, 0.93], [44, 0.86], [20, 0.8], [12, 0.7]]) { const g = box(w * k, hh * S * 1.6, w * k * 0.9); add(g, x, y, z, 0, 0, 3.8, 1.6, 0xb7c3c8); y += hh * S * 1.6; } for (const q of [-1, 1]) for (const p of [-1, 1]) add(box(5, 22, 5), x + q * w * 0.27, y - 4, z + p * w * 0.24, 0, 0, 4, 2, 0xd0d6d8); tops.push([x, y + 10, z]);
    o.glow(0xffffff, 3.2, 1.6, 30, 0.5, x, y + 4, z - w * 0.25); }
  // Central Plaza: triangular tower, pyramid top + mast, colour-cycling crown
  { const x = 420, z = Z(150), h = 374 * S * 0.86; add(prism(34, h, 3, 0.1), x, Y0, z, 0, 3, 3.8, 1.6, 0xc8a86a, undefined, h - 26); add(new THREE.ConeGeometry(30, 26, 3).rotateY(0.1).translate(0, 13, 0), x, Y0 + h - 0.5, z, 0, 3, 3.8, 1.6, 0xb8984a, undefined, -1); tops.push([x, Y0 + h + 60, z]); o.glow(0xffffff, 1.0, 1.2, 60, 1.2, x, Y0 + h + 26, z); }
  // Bank of China: four triangular shafts of a square plan, ending at different heights, white outline lights along the X-bracing
  { const x = -30, z = Z(250), a = 26, hs = [367 * S * 0.82, 300 * S * 0.82, 240 * S * 0.82, 180 * S * 0.82], col = 0x7f9aa8;
    const tri = (rot) => { const s = new THREE.Shape([new THREE.Vector2(0, 0), new THREE.Vector2(a, -a), new THREE.Vector2(a, a)]); return s; };
    [0, Math.PI / 2, Math.PI, -Math.PI / 2].forEach((rot, i) => { const g = new THREE.ExtrudeGeometry(tri(), { depth: hs[i], bevelEnabled: false }); g.rotateX(-Math.PI / 2); g.rotateY(rot); add(g, x, Y0, z, 0, 0, 3.8, 2.2, col); });
    tops.push([x, Y0 + hs[0] + 30, z]); for (const q of [-1, 1]) add(box(1.2, 40, 1.2), x + q * 5, Y0 + hs[0], z + 8, 0, 0, 4, 2, 0xd8d8d0);
    // outline tubes stand 2 m off the glass (depth-precision safe at this range)
    const L = (x0, y0, z0, x1, y1, z1) => o.line(x + x0, Y0 + y0, z + z0, x + x1, Y0 + y1, z + z1, 0xf2f4ff, 1.4);
    for (const [sx, sz] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) L(sx * (a + 1.4), 0, sz * (a + 1.4), sx * (a + 1.4), hs[sx > 0 ? (sz > 0 ? 3 : 0) : sz > 0 ? 2 : 1], sz * (a + 1.4));
    for (let k = 0; k < 4; k++) { const y0 = k * 52, y1 = y0 + 52; if (y1 > hs[3]) break; for (const s of [-1, 1]) { L(-a, y0, s * (a + 1.6), a, y1, s * (a + 1.6)); L(a, y0, s * (a + 1.6), -a, y1, s * (a + 1.6)); L(s * (a + 1.6), y0, -a, s * (a + 1.6), y1, a); L(s * (a + 1.6), y0, a, s * (a + 1.6), y1, -a); } } }
  // The Center: LED bands that sweep through the spectrum
  { const x = -470, z = Z(170); tower(x, z, 40, 40, 346 * S * 0.82, 2, { oct: 1, fl: 4.4, cw: 3, color: 0x6a7a86 }); tops.push([x, Y0 + 346 * S * 0.82 + 20, z]); }
  // Cheung Kong Center, HSBC, Jardine House (round windows: residential-sized cells), Hopewell (round)
  tower(-110, Z(230), 44, 44, 283 * S * 0.86, 0, { color: 0x8c9aa2, fl: 3.6 }); tops.push([-110, Y0 + 283 * S * 0.86 + 20, Z(230)]);
  { const x = -170, z = Z(205); for (const [dx, hh] of [[-16, 150], [0, 178], [16, 132]]) tower(x + dx, z, 15, 34, hh * S * 0.9, 0, { color: 0xb0b4b4, flat: true, fl: 4.2, cw: 2.4 }); }
  tower(-300, Z(70), 46, 46, 178 * S, 1, { color: 0xd8d4c8, fl: 3.6, cw: 2.0 });
  tower(170, Z(320), 46, 46, 216 * S, 0, { round: 28, color: 0x9a948a, fl: 3.4, cw: 2.2 });
  crownT(240, Z(200), 40, 230 * S, 20, 0x9aa0a6); // Times Square-ish crown
  crownT(-360, Z(210), 34, 255 * S, 16, 0x8a98a2);
  // ---- the rest of the waterfront: dense blocks, taller towards Central, rows climbing inland
  for (let i = 0; i < 230; i++) { const x = -1100 + r() * 2200, row = r(), z = Z(50 + row * 330 + (r() - 0.5) * 30), cen = Math.exp(-((x + 120) ** 2) / 260000), wan = Math.exp(-((x - 380) ** 2) / 90000), far = Math.min(1, Math.abs(x) / 1300);
    let h = (36 + Math.pow(r(), 1.4) * (90 + 210 * cen + 120 * wan)) * (1 - far * 0.5); if (Math.abs(x + 30) < 40 && z < Z(300)) continue; if (Math.abs(x + 230) < 45 && z < Z(90)) continue;
    const kind = r() < 0.28 + far * 0.4 ? 1 : h > 70 && r() < 0.14 ? 2 : 0, w = 18 + r() * 22; if (kind === 0 && h > 110 && r() < 0.3) crownT(x, z, w, h, 6 + r() * 10, [0x9aa4ac, 0x7d8a90, 0xb8b2a4][Math.floor(r() * 3)], (r() - 0.5) * 0.12); else tower(x, z, w, 16 + r() * 20, h, kind, { ry: (r() - 0.5) * 0.12 }); }
  if (o.extra) o.extra({ tower, glow: o.glow }); /* the far street city shares this mesh and its window shader */
  // ---- the Peak behind: ridge height field, Mid-Levels towers on its slopes
  const ridge = (x) => { const peak = 500 * Math.exp(-((x + 260) ** 2) / 160000) + 330 * Math.exp(-((x - 480) ** 2) / 230000) + 190; return (peak + 70 * vnoise(x * 0.004, 2) + 30 * vnoise(x * 0.013, 5)) * (1 - Math.min(1, Math.abs(x) / 2600)); };
  const hill = (x, z) => { const d = z - Z(300); if (d < 0) return 0; const t = Math.min(1, d / 640), s = t * t * (3 - 2 * t); return ridge(x) * s * (0.85 + 0.15 * vnoise(x * 0.02, z * 0.02)); };
  { const NX = 150, NZ = 34, pos = [], col = [], idx = []; for (let j = 0; j <= NZ; j++) for (let i = 0; i <= NX; i++) { const x = -2400 + (i / NX) * 4800, z = Z(300) + (j / NZ) * 900, y = Y0 + hill(x, z); pos.push(x, y, z); const k = 0.6 + 0.4 * vnoise(x * 0.01, z * 0.01); col.push(0.05 * k, 0.075 * k, 0.045 * k); }
    for (let j = 0; j < NZ; j++) for (let i = 0; i < NX; i++) { const a = j * (NX + 1) + i, b = a + 1, c = a + NX + 1, d = c + 1; idx.push(a, c, b, b, c, d); }
    const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute("color", new THREE.Float32BufferAttribute(col, 3)); g.setIndex(idx); g.computeVertexNormals();
    const hm = new THREE.Mesh(g, K.flat(0xffffff, { rough: 0.95, vc: true, detail: false })); hm.receiveShadow = false; hm.castShadow = false; group.add(hm); o.layer(hm); }
  for (let i = 0; i < 260; i++) { const x = -1300 + r() * 2300, z = Z(330 + Math.pow(r(), 0.8) * 420), hy = hill(x, z), top = ridge(x); if (hy > top * 0.86) continue; const h = 45 + r() * 95; tower(x, z, 16 + r() * 10, 16 + r() * 10, h, 1, { y: Y0 + hy - 6, color: [0xd8d2c2, 0xc8ccc8, 0xb8b0a0, 0xe0dcd0][Math.floor(r() * 4)], ry: r() * 0.4 }); }
  // the Peak Tower (wok on a plinth) on the ridge, lit
  { const x = -220, z = Z(780), y = Y0 + hill(x, z); add(box(40, 18, 30), x, y, z, 0, 0, 4.5, 3, 0x9a9a92); add(new THREE.CylinderGeometry(34, 18, 12, 20).translate(0, 6, 0), x, y + 24, z, 0, 0, 4, 6, 0xbab6aa); o.glow(0xfff2d8, 0.6, 42, 2, 32, x, y + 17.5, z); }
  // ---- waterfront: sea wall, promenade lamps (a string of points that the water turns into pillars), Convention Centre wing, observation wheel
  { o.box(K.flat(0x6a6660, { rough: 0.9 }), 3000, 4, 10, 0, Y0 - 2, SH + 3); for (let x = -1400; x <= 1400; x += 24) o.glow(0xffc887, 2.4, 0.9, 0.9, 0.9, x + (r() - 0.5) * 6, Y0 + 6, SH + 6);
    for (let x = -900; x <= 900; x += 150) if (r() < 0.6) o.glow(0xfff4e0, 0.9, 14, 2.2, 0.6, x, Y0 + 3.5, SH - 0.8); }
  { const x = 330, z = SH - 40; add(box(170, 24, 70), x, Y0, z, 0, 0, 6, 4, 0x8a9aa4); const g = new THREE.SphereGeometry(1, 30, 10, 0, Math.PI * 2, 0, 1.25).scale(110, 30, 60); add(g, x, Y0 + 22, z, 0, 0, 30, 30, 0xd8dad8); o.glow(0xcfe2ff, 0.8, 160, 1.2, 1.2, x, Y0 + 20, z - 36); }
  const wheel = o.wheel(-150, Y0, SH - 10);
  // searchlights of the nightly show from the tallest roofs
  const beams = [...tops, ...tops.slice(0, 4)].slice(0, 10).map((p, i) => o.beam(p[0], p[1], p[2], [0x9ad0ff, 0xffffff, 0xb0ffb8, 0xffd0f0][i % 4]));
  const geo = mergeGeometries(list, false); const mesh = new THREE.Mesh(geo, mat); mesh.castShadow = false; mesh.receiveShadow = false; mesh.frustumCulled = false; group.add(mesh); o.layer(mesh);
  return { update(dt, t, G) { uni.uT.value = t; const tod = G.sky.time; if (mat.envMap !== G.scene.environment) mat.envMap = G.scene.environment; mat.envMapIntensity = G.scene.environmentIntensity * (0.003 + 0.997 * (1 - G.sky.night) ** 2); /* the camera's probe is lit by the street around it, not by what lights a tower 1 km away */ uni.uLit.value = tod > 23 || tod < 6 ? 0.22 : tod > 19 ? 0.36 : 0.32; wheel?.(t); { /* searchlight show: sweep, fan out, meet overhead, chase pulses, scissors - a new figure every 24 s with a cross-fade */ const T = t / 24, k = Math.floor(T), u = T - k, fade = Math.min(1, u * 5, (1 - u) * 5), fig = (n, i) => { const ph = t * 0.4, a = i / beams.length;
      if (n === 0) return [Math.sin(t * 0.17 + i * 1.3) * 0.65, -0.25 + Math.sin(t * 0.11 + i * 2.1) * 0.3, 1];
      if (n === 1) return [(a - 0.5) * 1.6 + Math.sin(ph) * 0.15, -0.35, 1];
      if (n === 2) return [-(beams[i].position.x - 0) * 0.0009, -(beams[i].position.z - 900) * 0.0007, 0.6 + 0.4 * Math.sin(t * 3 + i)];
      if (n === 3) return [Math.sin(ph + a * 6.28) * 0.5, -0.2, Math.sin(t * 2.2 - a * 9) > 0.3 ? 1.3 : 0.15];
      return [Math.sin(ph * 1.6 + (i % 2) * 3.14) * 0.8, -0.3 + Math.cos(ph) * 0.2, 1]; };
      beams.forEach((bm, i) => { const f = fig(k % 5, i); bm.rotation.z = f[0]; bm.rotation.x = f[1]; const e = bm.material.userData.emit; if (e) { e.lum0 ??= e.lum; e.lum = e.lum0 * f[2] * (0.25 + 0.75 * fade) * (0.8 + 0.2 * Math.sin(t * 0.5 + i)); } e && (bm.material.userData.hue ??= i); }); } }, hill, ridge };
}
