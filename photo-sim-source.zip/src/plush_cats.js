// The eight plush cats sculpted in Blender (毛绒猫猫-八款模型.blend), decimated and packed as quantised meshes (src/cat-assets/*.cat):
// body (coat, ears, nose, mouth), glazed eyes, and the tail on its own pivot so it can sway. They sit; they breathe, look at you and flick the tail.
import * as THREE from "three";
import { gunzipSync } from "three/addons/libs/fflate.module.js";
import sources from "scene-assets";
import { detail } from "./kit.js";

export const PLUSH_NAMES = { cat: "橘猫", cat2: "黑猫", catW: "白猫", catG: "英短蓝猫", catC: "三花猫", catS: "暹罗猫", catT: "奶牛猫", catL: "狸花猫" };
const cache = new Map(); let mats = null;
function decode(kind) {
  if (cache.has(kind)) return cache.get(kind);
  const b64 = sources["cat:" + kind]; if (!b64) { cache.set(kind, null); return null; }
  const raw = gunzipSync(Uint8Array.from(atob(b64), (c) => c.charCodeAt(0))), dv = new DataView(raw.buffer, raw.byteOffset, raw.byteLength); let o = 0; const parts = {};
  const n = dv.getUint32(o, true); o += 4;
  for (let p = 0; p < n; p++) { const nl = dv.getUint8(o); o += 1; const name = new TextDecoder().decode(raw.subarray(o, o + nl)); o += nl; const nv = dv.getUint32(o, true), ni = dv.getUint32(o + 4, true); o += 8;
    const mn = [0, 1, 2].map((k) => dv.getFloat32(o + k * 4, true)), mx = [0, 1, 2].map((k) => dv.getFloat32(o + 12 + k * 4, true)); o += 24;
    const pos = new Float32Array(nv * 3), nor = new Float32Array(nv * 3), col = new Float32Array(nv * 3);
    for (let i = 0; i < nv * 3; i++) { const k = i % 3; pos[i] = mn[k] + (dv.getUint16(o + i * 2, true) / 65535) * (mx[k] - mn[k]); } o += nv * 6;
    for (let i = 0; i < nv * 3; i++) nor[i] = dv.getInt8(o + i) / 127; o += nv * 3;
    for (let i = 0; i < nv * 3; i++) col[i] = Math.pow(dv.getUint8(o + i) / 255, 2.2); o += nv * 3; if (o % 2) o++;
    const idx = new Uint16Array(ni); for (let i = 0; i < ni; i++) idx[i] = dv.getUint16(o + i * 2, true); o += ni * 2; if (o % 4) o += 4 - (o % 4);
    const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.BufferAttribute(pos, 3)); g.setAttribute("normal", new THREE.BufferAttribute(nor, 3)); g.setAttribute("color", new THREE.BufferAttribute(col, 3)); g.setIndex(new THREE.BufferAttribute(idx, 1)); g.computeBoundingBox(); parts[name] = g; }
  // stand on y = 0, face +x (the way every animal in the game faces), find the tail root
  const bb = parts.body.boundingBox, c = bb.getCenter(new THREE.Vector3()), ec = parts.eyes ? parts.eyes.boundingBox.getCenter(new THREE.Vector3()) : c.clone().add(new THREE.Vector3(0, 0, 1)), ang = Math.atan2(ec.z - c.z, ec.x - c.x);
  for (const g of Object.values(parts)) { g.translate(-c.x, -bb.min.y, -c.z); g.rotateY(ang); g.computeBoundingBox(); }
  let pivot = new THREE.Vector3(); if (parts.tail) { const p = parts.tail.attributes.position, bc = new THREE.Vector3(0, (bb.max.y - bb.min.y) * 0.25, 0); let best = 1e9; for (let i = 0; i < p.count; i++) { const v = new THREE.Vector3().fromBufferAttribute(p, i), d = v.distanceTo(bc); if (d < best) { best = d; pivot.copy(v); } } }
  const r = { parts, height: bb.max.y - bb.min.y, pivot }; cache.set(kind, r); return r;
}
// ---- rig built in code from the sitting sculpt: a joint layout measured on the calico (model units, facing +x, base y = 0), scaled to each cat's
// bounding box; skin weights from distance to the bone segments (computed once per breed), the tail weighted along its surface geodesic.
const J0 = { hips: [-0.35, 0.36, 0], spine: [-0.12, 0.66, 0], chest: [0.12, 0.86, 0], neck: [0.16, 1.04, 0], head: [0.3, 1.28, 0], tip: [0.42, 1.7, 0],
  fl: [0.24, 0.78, 0.17], fe: [0.33, 0.38, 0.17], fp: [0.4, 0.05, 0.18], rl: [-0.3, 0.42, 0.27], rk: [0.0, 0.2, 0.3], rf: [0.25, 0.05, 0.24] };
const REF = new THREE.Vector3(1.442, 1.975, 1.14);
function rig(d) {
  if (d.rig) return d.rig;
  const bb = d.parts.body.boundingBox, sz = bb.getSize(new THREE.Vector3()), k = new THREE.Vector3(sz.x / REF.x, sz.y / REF.y, sz.z / REF.z), P = (a, side = 1) => new THREE.Vector3(a[0] * k.x, a[1] * k.y, a[2] * k.z * side);
  // bone list: name, parent, head joint, segment end (for weights)
  const B = [["root", -1, new THREE.Vector3(), null], ["hips", 0, P(J0.hips), P(J0.spine)], ["spine", 1, P(J0.spine), P(J0.chest)], ["chest", 2, P(J0.chest), P(J0.neck)], ["neck", 3, P(J0.neck), P(J0.head)], ["head", 4, P(J0.head), P(J0.tip)]];
  for (const s of [1, -1]) { const t = s > 0 ? "L" : "R"; const ub = B.length; B.push(["fu" + t, 3, P(J0.fl, s), P(J0.fe, s)], ["fd" + t, ub, P(J0.fe, s), P(J0.fp, s)]); const rb = B.length; B.push(["ru" + t, 1, P(J0.rl, s), P(J0.rk, s)], ["rd" + t, rb, P(J0.rk, s), P(J0.rf, s)]); }
  const seg = (p, a, b) => { const ab = b.clone().sub(a), t = Math.max(0, Math.min(1, p.clone().sub(a).dot(ab) / ab.lengthSq())); return p.distanceTo(a.clone().addScaledVector(ab, t)); };
  const skin = (geo, list, extra) => { const pos = geo.attributes.position, n = pos.count, si = new Uint16Array(n * 4), sw = new Float32Array(n * 4), v = new THREE.Vector3();
    for (let i = 0; i < n; i++) { v.fromBufferAttribute(pos, i); const w = list.map(([bi, a, b, bias = 1]) => [bi, bias / Math.pow(seg(v, a, b) * seg(v, a, b) + 0.0004, 2)]); if (extra) extra(v, w); w.sort((p, q) => q[1] - p[1]); const top = w.slice(0, 4), tot = top.reduce((s, q) => s + q[1], 0);
      top.forEach(([bi, ww], j) => { si[i * 4 + j] = bi; sw[i * 4 + j] = ww / tot; }); }
    geo.setAttribute("skinIndex", new THREE.Uint16BufferAttribute(si, 4)); geo.setAttribute("skinWeight", new THREE.Float32BufferAttribute(sw, 4)); };
  const segs = B.map((b, i) => [i, b[2], b[3]]).filter((q) => q[2]);
  // the head owns everything high and forward (ears, cheeks), legs never reach into the torso middle
  skin(d.parts.body, segs, (v, w) => { if (v.y > P(J0.neck)[1] && v.x > P(J0.neck)[0] - 0.12 * k.x) for (const q of w) if (B[q[0]][0] === "head") q[1] *= 40; if (Math.abs(v.z) < 0.08 * k.z) for (const q of w) if (/^[fr][ud]/.test(B[q[0]][0])) q[1] *= 0.05; });
  // tail: geodesic distance from its root vertex, split into a chain of six bones
  const T = d.parts.tail, tp = T.attributes.position, tn = tp.count, idx = T.index.array, nb = Array.from({ length: tn }, () => []), V = (i) => new THREE.Vector3().fromBufferAttribute(tp, i);
  for (let t = 0; t < idx.length; t += 3) for (const [a, b] of [[idx[t], idx[t + 1]], [idx[t + 1], idx[t + 2]], [idx[t + 2], idx[t]]]) { const l = V(a).distanceTo(V(b)); nb[a].push([b, l]); nb[b].push([a, l]); }
  let s0 = 0, best = 1e9; for (let i = 0; i < tn; i++) { const dd = V(i).distanceTo(d.pivot); if (dd < best) { best = dd; s0 = i; } }
  const dist = new Float32Array(tn).fill(1e9), done = new Uint8Array(tn); dist[s0] = 0; for (let it = 0; it < tn; it++) { let u = -1, m = 1e9; for (let i = 0; i < tn; i++) if (!done[i] && dist[i] < m) { m = dist[i]; u = i; } if (u < 0) break; done[u] = 1; for (const [w, l] of nb[u]) if (dist[u] + l < dist[w]) dist[w] = dist[u] + l; }
  let dmax = 0; for (let i = 0; i < tn; i++) if (dist[i] < 1e8) dmax = Math.max(dmax, dist[i]);
  const NT = 6, cent = Array.from({ length: NT + 1 }, () => [new THREE.Vector3(), 0]); for (let i = 0; i < tn; i++) { const b = Math.min(NT, Math.round((dist[i] / dmax) * NT)); cent[b][0].add(V(i)); cent[b][1]++; }
  const joints = cent.map(([c, n], i) => (n ? c.divideScalar(n) : i ? null : d.pivot.clone())); for (let i = 1; i <= NT; i++) if (!joints[i]) joints[i] = joints[i - 1].clone();
  joints[0] = d.pivot.clone(); const tb0 = B.length; for (let i = 0; i < NT; i++) B.push(["tail" + i, i ? tb0 + i - 1 : 1, joints[i], joints[i + 1]]);
  { const si = new Uint16Array(tn * 4), sw = new Float32Array(tn * 4); for (let i = 0; i < tn; i++) { const f = Math.min(NT - 1e-3, (dist[i] / dmax) * NT), b = Math.floor(f), u = f - b; si[i * 4] = tb0 + b; si[i * 4 + 1] = tb0 + Math.min(NT - 1, b + 1); sw[i * 4] = 1 - u * 0.5; sw[i * 4 + 1] = u * 0.5; }
    T.setAttribute("skinIndex", new THREE.Uint16BufferAttribute(si, 4)); T.setAttribute("skinWeight", new THREE.Float32BufferAttribute(sw, 4)); }
  return (d.rig = { B, k });
}
function makeSkeleton(R) { const bones = R.B.map(([name]) => { const b = new THREE.Bone(); b.name = name; return b; });
  R.B.forEach(([, parent, head], i) => { if (parent < 0) bones[i].position.copy(head); else { bones[i].position.copy(head).sub(R.B[parent][2]); bones[parent].add(bones[i]); } });
  bones[0].updateMatrixWorld(true); return { bones, skeleton: new THREE.Skeleton(bones), by: Object.fromEntries(bones.map((b) => [b.name, b])) }; }
export function createPlushCat(K, kind, height = 0.6) {
  const d = decode(kind); if (!d) return null; const R = rig(d);
  if (!mats) { const body = new THREE.MeshPhysicalMaterial({ vertexColors: true, roughness: 0.92, sheen: 1, sheenRoughness: 0.45, sheenColor: new THREE.Color(0.9, 0.9, 0.9) }); detail(body, "fur");
    mats = { body, eyes: new THREE.MeshPhysicalMaterial({ vertexColors: true, roughness: 0.12, clearcoat: 1, clearcoatRoughness: 0.03, side: THREE.DoubleSide }) }; }
  const root = new THREE.Group(), s = height / d.height, inner = new THREE.Group(); inner.scale.setScalar(s); root.add(inner);
  const S = makeSkeleton(R); inner.add(S.bones[0]);
  const body = new THREE.SkinnedMesh(d.parts.body, mats.body); body.bind(S.skeleton, new THREE.Matrix4()); inner.add(body); body.frustumCulled = false;
  const tail = new THREE.SkinnedMesh(d.parts.tail, mats.body); tail.bind(S.skeleton, new THREE.Matrix4()); inner.add(tail); tail.frustumCulled = false;
  if (d.parts.eyes) { const em = new THREE.Mesh(d.parts.eyes, mats.eyes), hj = R.B[5][2]; em.position.copy(hj).negate(); const ec = d.parts.eyes.boundingBox.getCenter(new THREE.Vector3()); em.position.x += 0.035 + ec.x * 0.07 - ec.x * 0.04; em.position.y -= ec.y * 0.04 - ec.y * 0.0; S.by.head.add(em); }
  root.traverse((m) => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; } });
  return { root, inner, bones: S.by, body, name: PLUSH_NAMES[kind] || "猫", length: height * 1.1, scale: s, k: R.k };
}
