// Building kit: materials from baked recipes, exposure-aware emitters and lamps, and a builder that merges static geometry per material.
import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
const M4 = new THREE.Matrix4(), Q = new THREE.Quaternion(), E = new THREE.Euler(), V = new THREE.Vector3(), S = new THREE.Vector3(1, 1, 1);
export function boxUV(w, h, d, tile = 2) {
  const g = new THREE.BoxGeometry(w, h, d), n = g.attributes.normal, uv = g.attributes.uv;
  for (let i = 0; i < uv.count; i++) { const ax = Math.abs(n.getX(i)), ay = Math.abs(n.getY(i)); const su = ax > 0.5 ? d : w, sv = ay > 0.5 ? d : h; uv.setXY(i, (uv.getX(i) * su) / tile, (uv.getY(i) * sv) / tile); }
  return g;
}

const clampN = (v, a, b) => Math.max(a, Math.min(b, v));
// Chamfered box with smoothed bevel normals (so edges catch a highlight instead of ending in a razor line).
export function rbox(w, h, d, r, tile = 2) {
  r = Math.min(r, w / 2 - 1e-4, h / 2 - 1e-4, d / 2 - 1e-4); if (!(r > 0.0004)) return boxUV(w, h, d, tile);
  const g = new THREE.BoxGeometry(w, h, d, 3, 3, 3), p = g.attributes.position, n = g.attributes.normal, uv = g.attributes.uv, c = [w / 2, h / 2, d / 2], P = [0, 0, 0], I = [0, 0, 0];
  for (let i = 0; i < p.count; i++) { let on = 0, l = 0; for (let k = 0; k < 3; k++) { const v = p.getComponent(i, k), a = Math.abs(v), sg = Math.sign(v); P[k] = a > c[k] - 1e-5 ? sg * c[k] : sg * (c[k] - r); I[k] = clampN(P[k], -(c[k] - r), c[k] - r); if (Math.abs(P[k]) > c[k] - 1e-5) on++; l += (P[k] - I[k]) ** 2; }
    if (on >= 2 && l > 1e-12) { l = Math.sqrt(l); const nx = (P[0] - I[0]) / l, ny = (P[1] - I[1]) / l, nz = (P[2] - I[2]) / l; P[0] = I[0] + nx * r; P[1] = I[1] + ny * r; P[2] = I[2] + nz * r; n.setXYZ(i, nx, ny, nz); }
    p.setXYZ(i, P[0], P[1], P[2]); const ax = Math.abs(n.getX(i)), ay = Math.abs(n.getY(i)), az = Math.abs(n.getZ(i));
    if (ax >= ay && ax >= az) uv.setXY(i, P[2] / tile, P[1] / tile); else if (ay >= az) uv.setXY(i, P[0] / tile, P[2] / tile); else uv.setXY(i, P[0] / tile, P[1] / tile); }
  return g;
}
// Hard-edged lathe: every profile segment keeps its own normal, so chamfers read as machined facets. pts = [[radius, y], ...] bottom to top.
export function lathe(pts, seg = 24, tile = 1) {
  const pos = [], nor = [], uv = [], idx = []; let b = 0;
  for (let k = 0; k < pts.length - 1; k++) { const [r0, y0] = pts[k], [r1, y1] = pts[k + 1], dr = r1 - r0, dy = y1 - y0, l = Math.hypot(dr, dy); if (l < 1e-7) continue; const nr = dy / l, ny = -dr / l;
    for (let i = 0; i <= seg; i++) { const a = (i / seg) * Math.PI * 2, c = Math.cos(a), s = Math.sin(a); pos.push(r0 * c, y0, r0 * s, r1 * c, y1, r1 * s); nor.push(nr * c, ny, nr * s, nr * c, ny, nr * s); const u = (a * Math.max(r0, r1)) / tile; uv.push(u, y0 / tile, u, y1 / tile); }
    for (let i = 0; i < seg; i++) { const q = b + i * 2; idx.push(q, q + 1, q + 2, q + 2, q + 1, q + 3); } b += (seg + 1) * 2; }
  const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute("normal", new THREE.Float32BufferAttribute(nor, 3)); g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx); return g;
}
// Bevelled extrusion of a 2D outline (optionally with holes), centred on z.
export function extrude(outline, depth, bevel = 0.002, holes = null, curve = 8) {
  const sh = new THREE.Shape(); outline.forEach((q, i) => (i ? sh.lineTo(q[0], q[1]) : sh.moveTo(q[0], q[1]))); sh.closePath(); if (holes) for (const h of holes) sh.holes.push(new THREE.Path(h.map((q) => new THREE.Vector2(q[0], q[1]))));
  bevel = Math.min(bevel, depth / 2 - 1e-4); const g = new THREE.ExtrudeGeometry(sh, { depth: Math.max(1e-4, depth - 2 * bevel), bevelEnabled: bevel > 0, bevelThickness: bevel, bevelSize: bevel, bevelOffset: -bevel, bevelSegments: 1, steps: 1, curveSegments: curve }); g.translate(0, 0, -depth / 2 + bevel); return g;
}

// Organic loft: a smooth tube through control points with an elliptical section per point ({ p:[x,y,z], r:[side, up] | number }), rounded ends.
export function loft(pts, o = {}) {
  const seg = o.seg || 16, sub = o.sub || 6, cap = o.cap ?? 4, P = pts.map((q) => new THREE.Vector3(...q.p)), R = pts.map((q) => (typeof q.r === "number" ? [q.r, q.r] : q.r)), curve = new THREE.CatmullRomCurve3(P, false, "centripetal"), n = (pts.length - 1) * sub, rings = [];
  for (let i = 0; i <= n; i++) { const u = i / n, f = u * (pts.length - 1), k = Math.min(Math.floor(f), pts.length - 2), t = f - k, ts = t * t * (3 - 2 * t); rings.push({ c: curve.getPoint(u), t: curve.getTangent(u), rx: R[k][0] + (R[k + 1][0] - R[k][0]) * ts, ry: R[k][1] + (R[k + 1][1] - R[k][1]) * ts }); }
  const ends = (ring, dir, on) => { const out = []; if (!on) return out; for (let j = 1; j <= cap; j++) { const a = (j / cap) * Math.PI * 0.5, k = Math.max(Math.cos(a), 0.02), l = Math.sin(a) * Math.min(ring.rx, ring.ry) * (o.capK ?? 1); out.push({ c: ring.c.clone().addScaledVector(ring.t, dir * l), t: ring.t, rx: ring.rx * k, ry: ring.ry * k }); } return out; };
  const all = [...ends(rings[0], -1, o.capStart ?? true).reverse(), ...rings, ...ends(rings[n], 1, o.capEnd ?? true)];
  const pos = [], uv = [], idx = [], N = new THREE.Vector3(...(o.up || [0, 1, 0])), B = new THREE.Vector3(); let len = 0;
  all.forEach((r, i) => { N.addScaledVector(r.t, -N.dot(r.t)).normalize(); B.crossVectors(r.t, N); if (i) len += r.c.distanceTo(all[i - 1].c); for (let j = 0; j < seg; j++) { const a = (j / seg) * Math.PI * 2, ca = Math.cos(a) * r.ry, sa = Math.sin(a) * r.rx; pos.push(r.c.x + N.x * ca + B.x * sa, r.c.y + N.y * ca + B.y * sa, r.c.z + N.z * ca + B.z * sa); uv.push(j / seg, len); } });
  for (let i = 0; i < all.length - 1; i++) for (let j = 0; j < seg; j++) { const a = i * seg + j, b = i * seg + ((j + 1) % seg), c = a + seg, d = b + seg; idx.push(a, b, c, b, d, c); }
  const g = new THREE.BufferGeometry(); g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2)); g.setIndex(idx); g.computeVertexNormals(); return g;
}
// Micro-surface detail injected into a standard material: roughness breakup (smudges, scuffs), fine bump, albedo grime and wear on convex edges.
// S = three noise frequencies (1/m), A = [roughness, bump, albedo] amounts, W = [edge wear amount, curvature threshold (1/m)]
export const DETAIL = { paint: { S: [5, 46, 380], A: [0.9, 0.5, 0.12], W: [0.22, 30] }, metal: { S: [9, 80, 700], A: [1.1, 0.35, 0.1], W: [0.5, 24] }, plastic: { S: [14, 220, 1500], A: [0.7, 0.9, 0.06], W: [0.12, 60] }, rubber: { S: [30, 900, 2600], A: [0.5, 1.6, 0.05], W: [0.05, 80] }, tex: { S: [0.7, 6, 48], A: [0.7, 0.35, 0.2], W: [0.25, 10] }, cloth: { S: [8, 600, 2200], A: [0.3, 1.2, 0.1], W: [0, 50] }, skin: { S: [40, 700, 2400], A: [0.5, 0.5, 0.08], W: [0, 50] }, glass: { S: [3, 30, 200], A: [0.18, 0, 0], W: [0, 50] }, fur: { S: [25, 260, 900], A: [0.4, 1.8, 0.22], W: [0, 50] } };
let dnTex = null; const dnoise = () => { if (dnTex) return dnTex; const n = 256, d = new Uint8Array(n * n * 4); let sd = 12345; for (let i = 0; i < d.length; i++) { sd = (sd * 1664525 + 1013904223) >>> 0; d[i] = sd >>> 24; } dnTex = new THREE.DataTexture(d, n, n, THREE.RGBAFormat); dnTex.wrapS = dnTex.wrapT = THREE.RepeatWrapping; dnTex.magFilter = THREE.LinearFilter; dnTex.minFilter = THREE.LinearMipmapLinearFilter; dnTex.generateMipmaps = true; dnTex.needsUpdate = true; return dnTex; };
const D_COMMON = `varying vec3 vObjP; uniform vec3 uDS, uDA; uniform vec2 uDW; uniform sampler2D tDN;
vec3 dBump(vec3 n, float h){ vec3 dpx = dFdx(-vViewPosition), dpy = dFdy(-vViewPosition); float hx = dFdx(h), hy = dFdy(h); vec3 r1 = cross(dpy, n), r2 = cross(n, dpx); float det = dot(dpx, r1); vec3 g = sign(det) * (hx * r1 + hy * r2); return normalize(abs(det) * n - g); }`;
export function detail(m, kind = "paint") { const P = typeof kind === "string" ? DETAIL[kind] : kind; if (!P || m.userData.detail) return m; m.userData.detail = P;
  m.onBeforeCompile = (sh) => { sh.uniforms.uDS = { value: new THREE.Vector3(...P.S) }; sh.uniforms.uDA = { value: new THREE.Vector3(...P.A) }; sh.uniforms.uDW = { value: new THREE.Vector2(...P.W) }; sh.uniforms.tDN = { value: dnoise() };
    sh.vertexShader = sh.vertexShader.replace("#include <common>", "#include <common>\nvarying vec3 vObjP;").replace("#include <begin_vertex>", "#include <begin_vertex>\nvObjP = position;");
    sh.fragmentShader = sh.fragmentShader.replace("#include <common>", "#include <common>\n" + D_COMMON)
      .replace("#include <roughnessmap_fragment>", `#include <roughnessmap_fragment>
  float dPx = length(fwidth(vObjP)); vec3 dF = vec3(1.0) - smoothstep(vec3(0.12), vec3(0.45), dPx * uDS);
  vec2 dQ = (vObjP.xz + vObjP.y * vec2(0.731, 0.419)) / 256.0; float dN1 = texture2D(tDN, dQ * uDS.x).r, dN2 = texture2D(tDN, dQ * uDS.y + 0.37).g, dN3 = texture2D(tDN, dQ * uDS.z + 0.11).b, dN0 = texture2D(tDN, dQ * uDS.x * 0.31 + 0.53).a;
  float dScuff = smoothstep(0.62, 0.85, texture2D(tDN, dQ * uDS.x * 2.3 + 0.21).g) * dF.x;
  roughnessFactor = clamp(roughnessFactor + ((dN1 - 0.5) * 0.26 * dF.x + (dN2 - 0.5) * 0.14 * dF.y + (dN3 - 0.5) * 0.08 * dF.z + dScuff * 0.16 - smoothstep(0.6, 0.85, dN0) * 0.1) * uDA.x, 0.05, 1.0);
  diffuseColor.rgb *= 1.0 + ((dN0 - 0.5) * 1.3 + (dN1 - 0.5) * 0.7 * dF.x) * uDA.z;
  float dHt = ((dN2 - 0.5) / uDS.y * dF.y * 0.45 + (dN3 - 0.5) / uDS.z * dF.z * 0.7 - dScuff / uDS.x * 0.01) * uDA.y;`)
      .replace("#include <normal_fragment_maps>", `#include <normal_fragment_maps>
  { float dCurv = length(fwidth(nonPerturbedNormal)) / max(length(fwidth(vViewPosition)), 1e-6); float dWear = smoothstep(uDW.y, uDW.y * 3.0, dCurv) * smoothstep(0.25, 0.75, dN1 * 0.6 + dN2 * 0.4) * uDW.x * dF.x;
    diffuseColor.rgb = mix(diffuseColor.rgb, diffuseColor.rgb * 1.9 + 0.035, dWear); roughnessFactor = mix(roughnessFactor, roughnessFactor * 0.72, dWear); }
  normal = dBump(normal, dHt);`); };
  m.customProgramCacheKey = () => "det" + P.S.join() + P.A.join() + P.W.join(); return m; }
export function createKit(tex) {
  const K = { mats: new Map(), emis: [], lights: [], wet: [], groups: {}, cull: [] };
  K.cullUpdate = (p) => { for (const e of K.cull) { const dx = e.c.x - p.x, dy = e.c.y - p.y, dz = e.c.z - p.z; e.m.visible = Math.sqrt(dx * dx + dy * dy + dz * dz) - e.r < e.d; } };
  K.pool = [];
  K.reset = () => { K.pool = []; K.cull.length = 0; K.emis.length = 0; K.lights.length = 0; K.wet.length = 0; K.groups = {}; K.mats.clear(); };
  K.mat = (name, o = {}) => {
    const key = name + JSON.stringify(o); if (K.mats.has(key)) return K.mats.get(key);
    const t = tex.get(name), m = new THREE.MeshStandardMaterial({ map: t.map, normalMap: t.normalMap, roughnessMap: t.orm, metalnessMap: t.orm, roughness: o.rough ?? 1, metalness: o.metal ?? 1, color: o.color ?? 0xffffff, vertexColors: !!o.vc, side: o.side ?? THREE.FrontSide });
    if (o.ns != null) m.normalScale.set(o.ns, o.ns); m.userData.baseRough = m.roughness; if (o.detail !== false) detail(m, o.detail || (name === 'fabric' ? 'cloth' : 'tex')); if (o.wet) K.wet.push({ m, k: o.wet });
    K.mats.set(key, m); return m;
  };
  K.flat = (color, o = {}) => { const key = "f" + color + JSON.stringify(o); if (K.mats.has(key)) return K.mats.get(key);
    const m = new (o.coat ? THREE.MeshPhysicalMaterial : THREE.MeshStandardMaterial)({ ...(o.coat ? { clearcoat: 1, clearcoatRoughness: 0.05 } : {}), color, roughness: o.rough ?? 0.6, metalness: o.metal ?? 0, transparent: !!o.opacity, opacity: o.opacity ?? 1, side: o.side ?? THREE.FrontSide, vertexColors: !!o.vc, flatShading: !!o.flat }); m.userData.baseRough = m.roughness; if (o.detail !== false && !o.flat) detail(m, o.detail || (o.opacity ? 'glass' : (o.metal ?? 0) > 0.5 ? 'metal' : 'paint')); if (o.wet) K.wet.push({ m, k: o.wet }); K.mats.set(key, m); return m; };
  // an emitter whose brightness is a real luminance (×1000 cd/m²); `group` lets the UI switch it, `night` makes it follow darkness
  K.glow = (color, lum, o = {}) => { const m = new THREE.MeshBasicMaterial({ color: 0x000000, toneMapped: false, fog: o.fog ?? true, transparent: !!o.transparent, opacity: o.opacity ?? 1, side: o.side ?? THREE.FrontSide, map: o.map || null, blending: o.add ? THREE.AdditiveBlending : THREE.NormalBlending, depthWrite: !o.add });
    const e = { m, c: new THREE.Color(color), lum, on: 1, group: o.group, night: !!o.night, flicker: o.flicker || 0, neon: o.neon || null, ph: Math.random() * 97 }; K.emis.push(e); m.userData.emit = e; return m; };
  K.lit = (mat, color, lum, o = {}) => { mat.emissive = new THREE.Color(color); if (o.map) mat.emissiveMap = o.map; K.emis.push({ m: mat, std: true, lum, on: 1, group: o.group, night: !!o.night, flicker: 0 }); return mat; };
  // lamp intensity in ×1000 cd
  K.light = (parent, kind, color, cd, x, y, z, o = {}) => { const l = kind === "spot" ? new THREE.SpotLight(color, 1, o.dist || 30, o.angle || 0.7, o.pen ?? 0.6, 2) : new THREE.PointLight(color, 1, o.dist || 20, 2); l.position.set(x, y, z);
    if (kind === "spot" && o.target) { l.target.position.set(...o.target); parent.add(l.target); } if (o.shadow && K.noPointShadows) o = { ...o, shadow: false }; if (o.shadow) { l.castShadow = true; l.shadow.mapSize.set(512, 512); l.shadow.bias = -0.002; l.shadow.radius = 4; l.shadow.autoUpdate = false; l.shadow.needsUpdate = true; }
    parent.add(l); if (!o.shadow) l.visible = false; const e = { l, base: cd, on: 1, group: o.group, night: !!o.night, flicker: o.flicker || 0, shadow: !!o.shadow, kind, wp: null }; K.lights.push(e); return e; };
  // Forward shading pays for every light at every pixel. Logical lamps stay invisible; a fixed pool of real lights (constant count, so no shader
  // recompiles) is handed to the lamps nearest the camera every few frames. 26 lights per pixel became 8 + 3.
  const _wp = new THREE.Vector3(), _wt = new THREE.Vector3();
  K.poolInit = (group, nPoint = 8, nSpot = 3) => { K.pool = []; const logical = K.lights.filter((e) => !e.shadow); const np = Math.min(nPoint, logical.filter((e) => e.kind !== "spot").length), ns = Math.min(nSpot, logical.filter((e) => e.kind === "spot").length);
    for (let i = 0; i < np; i++) { const l = new THREE.PointLight(0xffffff, 0, 10, 2); group.add(l); K.pool.push({ l, kind: "point", e: null }); }
    for (let i = 0; i < ns; i++) { const l = new THREE.SpotLight(0xffffff, 0, 10, 0.7, 0.6, 2); group.add(l, l.target); K.pool.push({ l, kind: "spot", e: null }); }
    group.updateMatrixWorld(true); for (const e of logical) { e.wp = e.l.getWorldPosition(new THREE.Vector3()); if (e.kind === "spot") e.wt = e.l.target.getWorldPosition(new THREE.Vector3()); } };
  K.poolUpdate = (cam) => { if (!K.pool.length) return; const cand = K.lights.filter((e) => !e.shadow && e.wp && e.l.intensity > 1e-5);
    for (const e of cand) e.score = e.wp.distanceTo(cam) - e.l.distance * 0.6;
    for (const kind of ["point", "spot"]) { const slots = K.pool.filter((s) => s.kind === kind), list = cand.filter((e) => (e.kind === "spot") === (kind === "spot")).sort((a, b) => a.score - b.score);
      // keep lights that are still among the best where they are, so a lamp does not jump between slots
      const best = new Set(list.slice(0, slots.length)); for (const s of slots) if (s.e && !best.has(s.e)) s.e = null; const used = new Set(slots.map((s) => s.e).filter(Boolean));
      for (const e of best) if (!used.has(e)) { const s = slots.find((q) => !q.e); if (!s) break; s.e = e; }
      for (const s of slots) { const e = s.e; if (!e) { s.l.intensity = 0; continue; } s.l.position.copy(e.wp); s.l.distance = e.l.distance; s.l.decay = e.l.decay; s.l.color.copy(e.l.color); s.l.intensity = e.l.intensity;
        if (kind === "spot") { s.l.angle = e.l.angle; s.l.penumbra = e.l.penumbra; s.l.target.position.copy(e.wt); s.l.target.updateMatrixWorld(); } } } };
  // a point-light shadow is six extra renders of the whole scene: refresh it only now and then, and only when the camera is close enough to see it
  const _lp = new THREE.Vector3(); let _st = 0;
  K.shadowTick = (cam) => { _st++; for (const e of K.lights) { if (!e.shadow || !e.l.visible) continue; e.l.getWorldPosition(_lp); const d = _lp.distanceTo(cam); if (d < 26 && _st % (d < 10 ? 2 : 5) === 0) e.l.shadow.needsUpdate = true; } };
  K.setGroup = (g, on) => { K.groups[g] = on; };
  // old neon: a buzzing ballast, a dying tube that stutters every few seconds, a slow sign blink, a dead tube that sparks now and then
  const hh = (x) => { const v = Math.sin(x * 127.1 + 311.7) * 43758.5453; return v - Math.floor(v); };
  function neonK(kind, t, ph) {
    if (kind === "buzz") return hh(Math.floor(t * 24)) < 0.16 ? 0.12 : 0.88 + 0.12 * hh(Math.floor(t * 60) + 0.5);
    if (kind === "dying") { const c = (t % (3.5 + (ph % 4))); return c < 0.9 ? (hh(Math.floor(t * 17)) < 0.55 ? 0.05 : 0.8) : 0.72 + 0.08 * Math.sin(t * 90); }
    if (kind === "blink") return Math.sin(t * 1.9 + ph) > -0.25 ? 1 : 0.04;
    if (kind === "chase") return 0.35 + 0.65 * (Math.sin(t * 5 + ph) * 0.5 + 0.5);
    if (kind === "dead") return hh(Math.floor(t * 7)) > 0.975 ? 0.5 : 0.03;
    return 1; }
  K.expose = (m, night, t) => {
    for (const e of K.emis) { const on = (e.group != null ? (K.groups[e.group] ? 1 : 0) : 1) * (e.night ? night : 1) * e.on, f = (e.flicker ? 1 - e.flicker * (0.5 + 0.5 * Math.sin(t * 13 + e.lum * 7) * Math.sin(t * 7.3)) : 1) * (e.neon ? neonK(e.neon, t + e.ph, e.ph) : 1); if (e.std) e.m.emissiveIntensity = e.lum * on * m * f; else e.m.color.copy(e.c).multiplyScalar(e.lum * on * m * f); }
    for (const e of K.lights) { const on = (e.group != null ? (K.groups[e.group] ? 1 : 0) : 1) * (e.night ? night : 1) * e.on, f = e.flicker ? 1 - e.flicker * (0.5 + 0.5 * Math.sin(t * 11 + e.base * 31) * Math.sin(t * 6.1)) : 1; e.l.intensity = e.base * on * m * f; if (e.shadow) e.l.visible = true; }
    for (const s of K.pool) { const e = s.e; s.l.intensity = e ? e.l.intensity : 0; if (e) s.l.color.copy(e.l.color); }
  };
  K.setWet = (w) => { for (const e of K.wet) { const m = e.m; m.roughness = m.userData.baseRough * (1 - Math.min(0.85, 0.78 * Math.sqrt(w)) * e.k); if (!m.userData.baseCol) m.userData.baseCol = m.color.clone(); m.color.copy(m.userData.baseCol).multiplyScalar(1 - (0.5 * Math.min(w, 0.5) + 0.2 * Math.max(w - 0.5, 0)) * e.k); } }; // water fills the pores: wet ground is darker as well as glossier
  K.builder = () => {
    const parts = new Map(), B = { colliders: [], floors: [] };
    B.add = (geo, mat, x = 0, y = 0, z = 0, ry = 0, rx = 0, rz = 0, s = 1) => { if (geo.index) geo = geo.toNonIndexed(); for (const k of Object.keys(geo.attributes)) if (!["position", "normal", "uv"].includes(k) && !(k === "color" && mat.vertexColors)) geo.deleteAttribute(k);
      if (!geo.attributes.uv) geo.setAttribute("uv", new THREE.BufferAttribute(new Float32Array(geo.attributes.position.count * 2), 2));
      if (typeof s === "number") S.set(s, s, s); else S.set(...s); geo.applyMatrix4(M4.compose(V.set(x, y, z), Q.setFromEuler(E.set(rx, ry, rz, "YXZ")), S)); if (!parts.has(mat)) parts.set(mat, []); parts.get(mat).push(geo); return B; };
    const coll = (w, h, d, x, y, z, ry) => { const c = Math.abs(Math.cos(ry)), s = Math.abs(Math.sin(ry)), ex = (w * c + d * s) / 2, ez = (w * s + d * c) / 2; B.colliders.push({ x0: x - ex, x1: x + ex, z0: z - ez, z1: z + ez, y0: y, y1: y + h }); };
    // y is the bottom of the box
    B.box = (mat, w, h, d, x, y, z, o = {}) => { const mn = Math.min(w, h, d), mx = Math.max(w, h, d), bev = o.bev ?? (mx > 14 || mn < 0.012 || mat.transparent || mat.isMeshBasicMaterial ? 0 : clampN(mn * 0.07, 0.003, 0.022)); B.add(bev > 0 ? rbox(w, h, d, bev, o.tile || 2) : boxUV(w, h, d, o.tile || 2), mat, x, y + h / 2, z, o.ry || 0, o.rx || 0, o.rz || 0); if (o.col) coll(w, h, d, x, y, z, o.ry || 0); if (o.floor) B.floors.push({ x0: x - w / 2, x1: x + w / 2, z0: z - d / 2, z1: z + d / 2, y: y + h }); return B; };
    B.cyl = (mat, r0, r1, h, x, y, z, o = {}) => { const cb = o.open || mat.isMeshBasicMaterial || Math.min(r0, r1) < 0.012 ? 0 : (o.bev ?? clampN(Math.min(r0, r1, h) * 0.14, 0.002, 0.02)); const sg = o.seg || (Math.max(r0, r1) > 0.12 ? 28 : 18); const g = cb > 0 ? lathe([[0, -h / 2], [r0 - cb, -h / 2], [r0, -h / 2 + cb], [r1, h / 2 - cb], [r1 - cb, h / 2], [0, h / 2]], sg) : new THREE.CylinderGeometry(r1, r0, h, sg, 1, !!o.open); B.add(g, mat, x, y + (o.rx || o.rz ? 0 : h / 2), z, o.ry || 0, o.rx || 0, o.rz || 0); if (o.col) coll(r0 * 2, h, r0 * 2, x, y, z, 0); return B; };
    B.sph = (mat, r, x, y, z, o = {}) => B.add(new THREE.SphereGeometry(r, o.seg || 24, o.seg2 || 16), mat, x, y, z, 0, 0, 0, o.s || 1);
    B.plane = (mat, w, d, x, y, z, o = {}) => { const g = new THREE.PlaneGeometry(w, d, o.seg || 1, o.seg || 1); g.rotateX(-Math.PI / 2); const uv = g.attributes.uv, t = o.tile || 2; for (let i = 0; i < uv.count; i++) uv.setXY(i, (uv.getX(i) * w) / t, (uv.getY(i) * d) / t); return B.add(g, mat, x, y, z, o.ry || 0); };
    B.quad = (mat, w, h, x, y, z, ry = 0, rx = 0) => B.add(new THREE.PlaneGeometry(w, h), mat, x, y, z, ry, rx);
    // merged statics are split into ~48 m cells per material so the frustum (and a distance check) can skip what is not in view
    B.finish = (group, o = {}) => { const CELL = o.cell || 64; for (const [mat, list] of parts) { let total = 0; for (const g of list) total += g.attributes.position.count; const buckets = new Map();
        if (total > 60000 && !o.whole) for (const g of list) { g.computeBoundingBox(); const c = g.boundingBox, k = Math.floor((c.min.x + c.max.x) / 2 / CELL) + "," + Math.floor((c.min.z + c.max.z) / 2 / CELL); if (!buckets.has(k)) buckets.set(k, []); buckets.get(k).push(g); } else buckets.set("all", list);
        for (const [k, gl] of buckets) { const g = mergeGeometries(gl, false); if (!g) continue; const m = new THREE.Mesh(g, mat); m.castShadow = o.cast ?? !(mat.isMeshBasicMaterial || mat.transparent); m.receiveShadow = o.recv ?? true; if (mat.userData.depth) m.customDepthMaterial = mat.userData.depth; group.add(m); if (k !== "all" && !o.far) { g.computeBoundingSphere(); K.cull.push({ m, c: g.boundingSphere.center, r: g.boundingSphere.radius, d: o.maxDist || 320 }); } }
        for (const l of list) l.dispose(); } parts.clear(); return B; };
    return B;
  };
  // text / drawings on a canvas -> texture (signs, paintings, screens)
  K.canvasTex = (w, h, draw) => { const c = document.createElement("canvas"); c.width = w; c.height = h; draw(c.getContext("2d"), w, h); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t; };
  return K;
}
