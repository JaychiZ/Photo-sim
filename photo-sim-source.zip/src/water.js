// Open water (lake, harbour) and the wet-street film, all reading the frame's shared planar mirror (gfx.mirror) so reflections are
// rendered every frame from the current camera: no lag, no stepping while the camera moves.
// Waves stretch reflected lights into vertical pillars (the look of a harbour at night); sun glints come from a sharp lobe on the wave normals.
import * as THREE from "three";

const MIRROR = `uniform sampler2D tMirror; uniform mat4 uMirrorMat; uniform float uMirrorY;
vec2 mirrorUV(vec3 w){ vec3 q = w; if (cameraPosition.y > uMirrorY + 0.01 && w.y < uMirrorY - 0.001) q = cameraPosition + (w - cameraPosition) * ((cameraPosition.y - uMirrorY) / (cameraPosition.y - w.y)); vec4 p = uMirrorMat * vec4(q, 1.0); return p.xy / p.w; }
vec3 mirrorStreak(vec2 uv, float L, float lod, float jit){ vec3 s = vec3(0.0); float ws = 0.0; for (int i = 0; i < 9; i++){ float t = (float(i) + jit) / 8.5 * 2.0 - 1.0, w = exp(-t * t * 2.2); s += textureLod(tMirror, clamp(uv + vec2(0.0, t * L), vec2(0.002), vec2(0.998)), lod).rgb * w; ws += w; } return s / ws; }`;
export const MIRROR_GLSL = MIRROR;
// open-sea swell: four Gerstner trains rolling in from the south; the same numbers drive the GPU surface and the boats that ride it (JS)
export const WAVES = [[0.1, -1, 38, 0.8], [-0.32, -0.95, 19, 0.38], [0.45, -0.89, 9.5, 0.16], [-0.15, -1, 4.6, 0.07]].map(([x, z, L, A]) => { const l = Math.hypot(x, z); return { dx: x / l, dz: z / l, L, A }; });
export const seaMask = (x, z) => { const ss = (a, b, v) => { const t = Math.min(1, Math.max(0, (v - a) / (b - a))); return t * t * (3 - 2 * t); }; return ss(84, 112, z) * (1 - ss(420, 590, z)) * (1 - ss(220, 295, Math.abs(x))); };
export function waveY(x, z, t, k = 1) { const m = seaMask(x, z) * k; let y = 0; for (const w of WAVES) { const kk = 6.2831 / w.L, om = Math.sqrt(9.8 * kk); y += w.A * m * Math.sin(kk * (w.dx * x + w.dz * z) - om * t); } return y; }
const WAVE_V = `uniform float uTime, uWave, uTerr; uniform sampler2D tH; varying vec3 vWN; varying float vDepth, vCrest, vMask;
float seaMask(vec2 p){ return smoothstep(84., 112., p.y) * (1. - smoothstep(420., 590., p.y)) * (1. - smoothstep(220., 295., abs(p.x))); }
float depthAt(vec2 p){ vec2 uv = p / uTerr + 0.5; if (uTerr < 1. || uv.x < 0. || uv.y < 0. || uv.x > 1. || uv.y > 1.) return 60.; return -textureLod(tH, uv, 0.).r; }
void gw(vec2 d, float L, float A, vec2 p, float t, inout vec3 dp, inout vec3 n){ float k = 6.2831 / L, w = sqrt(9.8 * k), ph = k * dot(d, p) - w * t, c = cos(ph), s = sin(ph), Q = 0.55; dp.x += Q * A * d.x * c; dp.z += Q * A * d.y * c; dp.y += A * s; n.x -= d.x * k * A * c; n.z -= d.y * k * A * c; n.y -= Q * k * A * s; }`;

export function createWater(G, o = {}) {
  const U = G.gfx.mirror.U, nmap = G.tex.get("water").normalMap;
  const mat = new THREE.ShaderMaterial({
    uniforms: { tMirror: U.tMirror, uMirrorMat: U.uMirrorMat, uMirrorY: U.uMirrorY, tN: { value: nmap }, uTime: { value: 0 }, uChop: { value: o.chop ?? 0.55 }, uStreak: { value: o.streak ?? 0.05 }, uRain: { value: 0 },
      uSunDir: { value: new THREE.Vector3(0, 1, 0) }, uSunCol: { value: new THREE.Vector3() }, uDeep: { value: new THREE.Vector3() }, uFoam: { value: new THREE.Vector3() }, uScale: { value: o.scale ?? 1 }, uRip: { value: o.ripple || 0 }, uWave: { value: o.waves ? 1 : 0 }, uTerr: { value: o.terr || 0 }, tH: { value: o.heightTex || null } },
    vertexShader: WAVE_V + `
      varying vec3 vW; void main(){ vec4 w = modelMatrix * vec4(position, 1.0); vec2 p = w.xz; float dep = depthAt(p), m = seaMask(p) * uWave, ms = m * clamp(dep / 5.0, 0.12, 1.0); vec3 dp = vec3(0.0), n = vec3(0.0, 1.0, 0.0);
        if (ms > 0.0) { gw(vec2(${WAVES.map((w) => `${w.dx.toFixed(4)}, ${w.dz.toFixed(4)}), ${w.L.toFixed(2)}, ${w.A.toFixed(3)} * ms, p, uTime, dp, n); gw(vec2(`).join("").slice(0, -9)} }
        w.xyz += dp; vW = w.xyz; vWN = normalize(n); vDepth = dep; vMask = m; vCrest = dp.y / (1.1 * ms + 1e-3); gl_Position = projectionMatrix * viewMatrix * w; }`,
    fragmentShader: `precision highp float; ${MIRROR}
      uniform sampler2D tN; uniform float uTime, uChop, uStreak, uRain, uScale, uRip; uniform vec3 uSunDir, uSunCol, uDeep, uFoam; varying vec3 vW; varying vec3 vWN; varying float vDepth, vCrest, vMask;
      float h21(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
      void main(){ vec3 V = cameraPosition - vW; float dist = length(V); V /= dist; vec2 p = vW.xz * uScale;
        vec2 n1 = texture2D(tN, p * 0.029 + vec2(uTime * 0.010, uTime * 0.006)).xy * 2.0 - 1.0, n2 = texture2D(tN, p * 0.077 - vec2(uTime * 0.016, -uTime * 0.012)).xy * 2.0 - 1.0, n3 = texture2D(tN, p * 0.0063 + vec2(uTime * 0.002, uTime * 0.0013)).xy * 2.0 - 1.0, n4 = texture2D(tN, p * 0.21 + vec2(-uTime * 0.03, uTime * 0.025)).xy * 2.0 - 1.0;
        float near = 1.0 / (1.0 + dist * 0.0035), fine = 1.0 / (1.0 + dist * 0.03);
        vec2 g = (n1 * 0.5 + n2 * 0.32 * mix(0.5, 1.0, near) + n3 * 0.55 + n4 * 0.25 * fine) * uChop;
        if (uRip > 0.0) { vec2 r1 = texture2D(tN, p * 0.36 + vec2(uTime * 0.11, -uTime * 0.07)).xy * 2.0 - 1.0, r2 = texture2D(tN, p * 0.61 - vec2(uTime * 0.09, uTime * 0.13)).xy * 2.0 - 1.0; g += (r1 + r2) * 0.32 * uRip * mix(0.35, 1.0, near); } /* fast cat's-paw ripples: crisp at 1/1000 s, smoothed to glass by a long exposure */
        if (uRain > 0.0) { vec2 rp = fract(p * 1.3) - 0.5, id = floor(p * 1.3); float ph = fract(uTime * (0.7 + h21(id)) + h21(id + 3.1) * 9.0), rr = length(rp) - ph * 0.42; g += normalize(rp + 1e-4) * smoothstep(0.05, 0.0, abs(rr)) * (1.0 - ph) * uRain * 0.8 * fine; }
        vec3 N = normalize(vWN + vec3(g.x, 0.0, g.y) * near);
        float cosT = clamp(dot(N, V), 0.0, 1.0), F = 0.02 + 0.98 * pow(1.0 - cosT, 5.0);
        vec2 uv = mirrorUV(vW) + vec2(g.x * 0.03, g.y * 0.05) * near;
        float jit = h21(gl_FragCoord.xy) - 0.5;
        vec3 refl = mirrorStreak(uv, uStreak * (0.35 + 0.65 * near), 1.2, jit);
        vec3 R = reflect(-V, N); float sd = max(dot(R, uSunDir), 0.0);
        vec3 spec = uSunCol * (pow(sd, 1400.0) * 40.0 + pow(sd, 160.0) * 1.2) * smoothstep(-0.02, 0.06, uSunDir.y);
        float shallow = 1.0 - smoothstep(0.4, 7.0, vDepth); vec3 deep = uDeep * mix(vec3(1.0), vec3(1.5, 2.0, 1.8), shallow * step(vMask, 2.0) * smoothstep(60.0, 50.0, vDepth));
        vec3 c = mix(deep, refl, F) + spec * F * 4.0;
        float fn = texture2D(tN, p * 0.11 + vec2(uTime * 0.02, -uTime * 0.05)).b * 0.6 + texture2D(tN, p * 0.37 - uTime * 0.03).g * 0.4;
        float surf = (1.0 - smoothstep(0.05, 0.7, vDepth)) * smoothstep(-0.05, 0.12, vDepth) * smoothstep(84.0, 96.0, vW.z), crest = smoothstep(0.82, 1.15, vCrest) * vMask * smoothstep(0.45, 0.75, texture2D(tN, p * 0.021 + uTime * 0.004).r);
        float foam = clamp((surf * smoothstep(0.2, 0.9, sin(vW.z * 0.7 - uTime * 1.3 + fn * 4.0)) + crest * 0.5) * smoothstep(0.42, 0.7, fn + 0.2 * crest), 0.0, 1.0);
        c = mix(c, uFoam, foam * 0.85);
        gl_FragColor = vec4(c, 1.0); }`,
    fog: false, toneMapped: false });
  let mesh; if (o.parts) { mesh = new THREE.Group(); for (const [x0, x1, z0, z1, nx, nz] of o.parts) { const g = new THREE.PlaneGeometry(x1 - x0, z1 - z0, nx, nz).rotateX(-Math.PI / 2).translate((x0 + x1) / 2, o.y || 0, (z0 + z1) / 2); const pm = new THREE.Mesh(g, mat); pm.layers.set(1); pm.frustumCulled = false; mesh.add(pm); } }
  else { mesh = new THREE.Mesh(new THREE.PlaneGeometry(o.w || 2000, o.d || 2000, 1, 1), mat); mesh.rotation.x = -Math.PI / 2; mesh.position.set(o.x || 0, o.y || 0, o.z || 0); mesh.layers.set(1); mesh.frustumCulled = false; }
  if (!o.heightTex) { const dt0 = new THREE.DataTexture(new Float32Array([100, 0, 0, 1]), 1, 1, THREE.RGBAFormat, THREE.FloatType); dt0.needsUpdate = true; mat.uniforms.tH.value = dt0; }
  mesh.material = mat;
  // deep: albedo of the water body under ambient light (linear, per channel)
  const deep = o.deep || [0.012, 0.03, 0.035];
  mesh.userData.update = (dt, t, G) => { const m = G.m, S = G.sky, E = S.sunE, a = S.ambient; mat.uniforms.uTime.value = t; mat.uniforms.uSunDir.value.copy(S.lightDir); mat.uniforms.uSunCol.value.set(E[0] * m, E[1] * m, E[2] * m); mat.uniforms.uRain.value = S.w.rain;
    { const sk = Math.max(S.lightDir.y, 0); mat.uniforms.uFoam.value.set((a[0] * 0.9 + E[0] * sk * 0.25) * m, (a[1] * 0.9 + E[1] * sk * 0.25) * m, (a[2] * 0.9 + E[2] * sk * 0.25) * m); }
    const k = Math.max(S.lightDir.y, 0) * 0.3; mat.uniforms.uDeep.value.set((a[0] + E[0] * k) * deep[0] * m, (a[1] + E[1] * k) * deep[1] * m, (a[2] + E[2] * k) * deep[2] * m); };
  return mesh;
}

// Wet street film over road and pavements: damp asphalt gives soft, vertically smeared reflections; low spots hold mirror-like puddles; rain adds rings.
export function createWetFilm(G, geo, o = {}) {
  const U = G.gfx.mirror.U, n = 256, d = new Uint8Array(n * n * 4); let sd = 777; for (let i = 0; i < d.length; i++) { sd = (sd * 1664525 + 1013904223) >>> 0; d[i] = sd >>> 24; }
  const nt = new THREE.DataTexture(d, n, n, THREE.RGBAFormat); nt.wrapS = nt.wrapT = THREE.RepeatWrapping; nt.magFilter = THREE.LinearFilter; nt.minFilter = THREE.LinearMipmapLinearFilter; nt.generateMipmaps = true; nt.needsUpdate = true;
  const mat = new THREE.ShaderMaterial({
    uniforms: { tMirror: U.tMirror, uMirrorMat: U.uMirrorMat, uMirrorY: U.uMirrorY, tN: { value: nt }, uWet: { value: 0 }, uRain: { value: 0 }, uTime: { value: 0 }, uPud: { value: o.puddles ?? 1 } },
    vertexShader: "varying vec3 vW; void main(){ vec4 w = modelMatrix * vec4(position, 1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }",
    fragmentShader: `precision highp float; ${MIRROR}
      uniform sampler2D tN; uniform float uWet, uRain, uTime, uPud; varying vec3 vW;
      void main(){ vec2 p = vW.xz; vec3 V = normalize(cameraPosition - vW);
        float n = texture2D(tN, p * 0.011).r * 0.5 + texture2D(tN, p * 0.043).g * 0.32 + texture2D(tN, p * 0.16).b * 0.18;
        float lane = 1.0 - smoothstep(0.6, 1.4, abs(abs(vW.z) - 3.2)) * 0.25; // wheel ruts hold water
        float puddle = smoothstep(0.6 - 0.12 * lane, 0.64 - 0.12 * lane, n) * smoothstep(0.72, 0.96, uWet) * uPud; /* damp (0.5): a wet sheen only; after rain (1): wide standing puddles */
        float damp = smoothstep(0.05, 0.5, uWet) * (0.75 + 0.25 * texture2D(tN, p * 0.6).a) * mix(0.75, 1.15, smoothstep(0.5, 1.0, uWet));
        vec2 rp = fract(p * 0.9) - 0.5; float cell = texture2D(tN, floor(p * 0.9) / 256.0).a, ph = fract(uTime * (0.6 + cell) + cell * 7.0), ring = smoothstep(0.03, 0.0, abs(length(rp) - ph * 0.45)) * (1.0 - ph) * step(0.45, cell) * uRain;
        vec2 mic = (texture2D(tN, p * 2.3).rg - 0.5) * mix(0.012, 0.0015, puddle) + normalize(rp + 1e-4) * ring * 0.012 * max(puddle, 0.3);
        vec2 uv = mirrorUV(vW) + mic;
        float jit = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715)))) - 0.5;
        vec3 sharp = textureLod(tMirror, clamp(uv, vec2(0.002), vec2(0.998)), 0.2).rgb, soft = mirrorStreak(uv, 0.055, 2.6, jit);
        vec3 c = mix(soft, sharp, puddle);
        float cosT = clamp(V.y, 0.0, 1.0), F = 0.02 + 0.98 * pow(1.0 - cosT, 5.0);
        float a = clamp(F * mix(damp * 0.7, 1.0, puddle) + puddle * 0.06, 0.0, 0.97);
        gl_FragColor = vec4(c, a); }`,
    transparent: true, depthWrite: false, fog: false, toneMapped: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
  const mesh = new THREE.Mesh(geo, mat); mesh.layers.set(1); mesh.frustumCulled = false; mesh.renderOrder = 1;
  mesh.userData.update = (dt, t, G) => { mat.uniforms.uWet.value = G.sky.wet; mat.uniforms.uRain.value = G.sky.w.rain; mat.uniforms.uTime.value = t; mesh.visible = G.sky.wet > 0.03; };
  return mesh;
}
