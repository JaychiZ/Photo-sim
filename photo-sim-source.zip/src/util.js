export const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const lerp = (a, b, k) => a + (b - a) * k;
export const sstep = (a, b, x) => { const k = clamp((x - a) / (b - a)); return k * k * (3 - 2 * k); };
export const damp = (a, b, rate, dt) => b + (a - b) * Math.exp(-rate * dt);
export function rng(seed = 1) { let e = seed >>> 0; const f = () => { e = (e + 0x6d2b79f5) | 0; let t = Math.imul(e ^ (e >>> 15), 1 | e); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  f.range = (a, b) => a + (b - a) * f(); f.int = (a, b) => Math.floor(a + (b - a + 1) * f()); f.pick = (arr) => arr[Math.floor(f() * arr.length)]; f.sign = () => (f() < 0.5 ? -1 : 1); return f; }
const h2 = (x, y) => { let n = Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263); n = Math.imul(n ^ (n >>> 13), 1274126177); return ((n ^ (n >>> 16)) >>> 0) / 4294967296; };
export function vnoise(x, y) { const xi = Math.floor(x), yi = Math.floor(y); let fx = x - xi, fy = y - yi; fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
  return lerp(lerp(h2(xi, yi), h2(xi + 1, yi), fx), lerp(h2(xi, yi + 1), h2(xi + 1, yi + 1), fx), fy); }
export function fbm(x, y, oct = 5) { let a = 0.5, s = 0, t = 0; for (let i = 0; i < oct; i++) { s += a * vnoise(x, y); t += a; a *= 0.5; const nx = x * 1.6 + y * 1.2 + 7.3; y = -x * 1.2 + y * 1.6 + 3.1; x = nx; } return s / t; }
export const fmtTime = (h) => { const hh = Math.floor(h) % 24, mm = Math.floor((h - Math.floor(h)) * 60); return String(hh).padStart(2, "0") + ":" + String(mm).padStart(2, "0"); };
