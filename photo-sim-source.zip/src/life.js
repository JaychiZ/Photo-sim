// Animals, birds, insects, fish and other moving subjects in the scenes.
import * as THREE from "three";
import { clamp, lerp, damp, rng, sstep } from "./util.js";
import { buildCar, buildBus } from "./vehicles.js";
import { createMammal } from "./wildlife_mammals.js";
import { createPlushCat } from "./plush_cats.js";
import { createFlyingBird, createWaterBird, flockSpecies } from "./wildlife_birds.js";
import { createButterfly, createFirefly, createFish } from "./wildlife_small.js";
const V = new THREE.Vector3();
export function createLife(G) {
  const A = { list: [], cars: [], group: new THREE.Group() }; G.scene.add(A.group); let r = rng(11), L = null;
  const K = () => G.kit, flat = (c, o) => K().flat(c, Object.assign({ rough: 0.85 }, o));
  const mesh = (geo, mat, x = 0, y = 0, z = 0, parent) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; parent && parent.add(m); return m; };
  const ell = (rx, ry, rz, mat, x, y, z, p) => { const m = mesh(new THREE.SphereGeometry(1, 14, 10), mat, x, y, z, p); m.scale.set(rx, ry, rz); return m; };
  const showFineDetail = (root, radius) => {
    if (!root.userData.setClose) return;
    const focal = G.cam.vf ? Math.max(35, G.cam.focal * G.cam.crop()) : 35;
    const distance = radius * focal / (root.userData.fine ? .96 : 1.16);
    const visible = G.camera.position.distanceToSquared(root.position) < distance*distance;
    if (root.userData.fine !== visible) {
      root.userData.setClose(visible);
      root.userData.fine = visible;
    }
  };
  // the plush cats sit where they are put: they breathe, turn to look at a person who comes near, and flick the tail
  const supportAt = (x, z) => { let g = L.groundAt(x, z); for (const f of L.floors || []) if (x > f.x0 && x < f.x1 && z > f.z0 && z < f.z1 && f.y <= g + 0.6 && f.y > g) g = f.y; return g; };
  function plushCat(kind, home) {
    const c = createPlushCat(K(), kind, 0.54 + r() * 0.12); if (!c) return null; const g = c.root, b = c.bones, e = { name: c.name, obj: g, r: 0.45, x: home.x, z: home.z, yaw: r() * 6.28, ph: r() * 10, pet: true, st: "sit", t: 2 + r() * 4, tx: home.x, tz: home.z, sp: 0, gait: 0 };
    const W = { lick: 0, lie: 0, move: 0, run: 0, wag: 0 }, rest = new Map(); for (const [n, bn] of Object.entries(b)) rest.set(bn, bn.position.clone());
    const pick = () => { const q = r(); if (q < 0.26) return ["sit", 3 + r() * 5]; if (q < 0.44) return ["lick", 3.5 + r() * 3]; if (q < 0.6) return ["wag", 3 + r() * 3]; if (q < 0.78) return ["lie", 6 + r() * 10]; if (q < 0.93) return ["walk", 10]; return ["run", 6]; };
    g.position.set(e.x, supportAt(e.x, e.z), e.z);
    e.update = (dt, t) => { const P = G.player, px = P.x - e.x, pz = P.z - e.z, pd = Math.hypot(px, pz); g.visible = pd < 120; if (!g.visible) return;
      e.t -= dt; const running = Math.hypot(P.vx, P.vz) > 3.5;
      if (pd < 2.2 && running && e.st !== "run") { e.st = "run"; e.t = 3; e.tx = e.x - (px / pd) * 7; e.tz = e.z - (pz / pd) * 7; }
      if (e.t < 0) { const [st, dur] = pick(); e.st = st; e.t = dur; if (st === "walk" || st === "run") { const a = r() * 6.28, dd = st === "run" ? 4 + r() * 4 : 1.5 + r() * 2.5; let tx = home.x + Math.cos(a) * dd, tz = home.z + Math.sin(a) * dd; if (L.randGround && !L.indoor && !L.inside?.(home.x, home.z)) { const q = L.randGround(r, 0.5, dd, false, home); tx = q.x; tz = q.z; } e.tx = tx; e.tz = tz; } }
      let speed = 0; if (e.st === "walk" || e.st === "run") { const dx = e.tx - e.x, dz = e.tz - e.z, dl = Math.hypot(dx, dz); if (dl < 0.3) { e.st = "sit"; e.t = 2 + r() * 3; } else { speed = e.st === "run" ? 2.6 : 0.55; let dy = Math.atan2(-dz, dx) - e.yaw; dy = Math.atan2(Math.sin(dy), Math.cos(dy)); e.yaw += clamp(dy, -dt * 4, dt * 4); } }
      else if (pd < 5 && e.st !== "lie") { let dy = Math.atan2(-pz, px) - e.yaw; dy = Math.atan2(Math.sin(dy), Math.cos(dy)); e.yaw += clamp(dy, -dt * 0.8, dt * 0.8) * 0.5; }
      e.sp = damp(e.sp, speed, 5, dt); const nx = e.x + Math.cos(e.yaw) * e.sp * dt, nz = e.z - Math.sin(e.yaw) * e.sp * dt; if (Math.abs(supportAt(nx, nz) - supportAt(e.x, e.z)) < 0.25) { e.x = nx; e.z = nz; } else { e.st = "sit"; e.t = 1; }
      // pose weights
      const tg = { lick: e.st === "lick" ? 1 : 0, lie: e.st === "lie" ? 1 : 0, move: e.sp > 0.05 || e.st === "walk" || e.st === "run" ? 1 : 0, run: clamp((e.sp - 0.6) / 1.6, 0, 1), wag: e.st === "wag" ? 1 : 0 }; for (const k in W) W[k] = damp(W[k], tg[k], k === "move" ? 6 : 3.5, dt);
      e.gait = (e.gait + dt * (1.8 + e.sp * 2.2)) % 6.2832; const m = W.move, ru = W.run, l = W.lie * (1 - m), lk = W.lick * (1 - m) * (1 - l), sw = Math.sin(e.gait), cw = Math.cos(e.gait);
      for (const bn of Object.values(b)) bn.rotation.set(0, 0, 0);
      b.root.position.copy(rest.get(b.root)).add({ x: 0, y: m * (0.42 + ru * 0.06 * Math.abs(sw)) - l * 0.04, z: 0 });
      b.hips.rotation.z = -1.0 * m - 1.15 * l + ru * 0.12 * sw; b.spine.rotation.z = -0.12 * m - 0.1 * l + 0.015 * Math.sin(t * 2.4 + e.ph); b.chest.rotation.z = 0.05 * m;
      b.neck.rotation.z = 0.35 * m + 0.55 * l - 0.12 * lk; b.head.rotation.z = 1.0 * m + 0.95 * l - (0.35 + 0.12 * Math.sin(t * 7)) * lk; b.head.rotation.x = 0.22 * lk;
      if (m < 0.5 && l < 0.5 && pd < 5) { const ang = Math.atan2(-pz, px) - e.yaw; b.head.rotation.y = clamp(Math.atan2(Math.sin(ang), Math.cos(ang)), -0.8, 0.8) * (1 - lk); }
      for (const [side, ph] of [["L", 0], ["R", Math.PI]]) { const s1 = Math.sin(e.gait + ph), s2 = Math.sin(e.gait + ph + Math.PI * 0.5);
        b["fu" + side].rotation.z = 1.05 * m + 1.35 * l + s1 * (0.35 + 0.45 * ru) * m; b["fd" + side].rotation.z = -0.25 * l + Math.max(0, -s1) * 0.6 * m;
        b["ru" + side].rotation.z = 0.15 * l - s2 * (0.35 + 0.4 * ru) * m; b["rd" + side].rotation.z = -Math.max(0, s2) * 0.5 * m; }
      b.fuL.rotation.z += 1.7 * lk; b.fdL.rotation.z += 1.5 * lk; b.fuL.rotation.x = -0.25 * lk;
      const amp = 0.18 + 0.45 * W.wag + 0.15 * m, f = 1.2 + 2.4 * W.wag + 1.5 * m; for (let i = 0; i < 6; i++) { const tb = b["tail" + i]; tb.rotation.y = amp * Math.sin(t * f + e.ph - i * 0.7) * (0.4 + i * 0.12) + (i === 0 ? 2.6 * m + 1.6 * l : 0); tb.rotation.z = (i === 0 ? 0.5 * m : i < 3 ? -0.25 * m : 0) + 0.04 * Math.sin(t * 0.9 + i); }
      g.position.set(e.x, supportAt(e.x, e.z), e.z); g.rotation.y = e.yaw; e.y = g.position.y + 0.3; };
    A.group.add(g); A.list.push(e); return e; }
  function animal(kind, home, range) {
    if (kind.startsWith("cat")) { const pc = plushCat(kind, home); if (pc) return pc; }
    const model = createMammal(kind), g = model.root;
    const e = { name: model.name, obj: g, r: model.length, x: home.x, z: home.z, yaw: r()*6.28,
      state: "idle", t: r()*4, tx: home.x, tz: home.z, ph: r(), sp: 0, graze: 0 };
    e.update = (dt,t) => {
      const px=G.player.x-e.x, pz=G.player.z-e.z, pd=Math.hypot(px,pz);
      const motion=Math.hypot(G.player.vx,G.player.vz);
      if (model.flee && pd>0.001 && !G.player.fly &&
          (pd<model.flee*.35 || (pd<model.flee && motion>(G.player.eyeT<1?2.5:.6)))) {
        e.state="flee";e.t=2.5;e.tx=e.x-25*px/pd;e.tz=e.z-25*pz/pd;
      }
      e.t-=dt;
      if (e.state==="idle" && e.t<0) {
        if (r()<.6) {
          const p=L.randGround ? L.randGround(r,0,range,false,home) : {x:home.x+(r()-.5)*range,z:home.z+(r()-.5)*range};
          e.state="walk";e.t=14;e.tx=p.x;e.tz=p.z;
        } else {
          e.t=3+r()*6;e.grazeT=r()<.62;
        }
      }
      let speed=0;
      if(e.state!=="idle"){
        const dx=e.tx-e.x,dz=e.tz-e.z;
        if(Math.hypot(dx,dz)<.45||e.t<0){
          e.state="idle";e.t=2+r()*5;e.grazeT=r()<.5;
        }else{
          speed=e.state==="flee"?model.run:model.walk;
          const delta=Math.atan2(-dz,dx)-e.yaw;
          e.yaw+=clamp(Math.atan2(Math.sin(delta),Math.cos(delta)),-dt*3.6,dt*3.6);
        }
      }
      e.sp=damp(e.sp,speed,4,dt);
      const nx=e.x+Math.cos(e.yaw)*e.sp*dt,nz=e.z-Math.sin(e.yaw)*e.sp*dt,ground=L.groundAt(nx,nz);
      if(ground>(L.water ?? -1e9)+.05||L.indoor){e.x=nx;e.z=nz;}else{e.state="idle";e.t=1;}
      const fast=clamp((e.sp-model.walk)/Math.max(.01,model.run-model.walk),0,1);
      const amount=clamp(e.sp/model.walk,0,1);
      e.ph=(e.ph+dt*e.sp/(model.length*lerp(.58,1.48,fast)))%1;
      e.graze=damp(e.graze,e.state==="idle"&&e.grazeT?1:0,3,dt);
      g.visible=pd<240;
      const hop=g.visible?model.pose(e.ph,amount,fast,e.graze,t+e.x*.17):0;
      g.position.set(e.x,L.groundAt(e.x,e.z)+hop,e.z);g.rotation.y=e.yaw;
      e.y=g.position.y+model.shoulder*.75;
    };
    A.group.add(g);A.list.push(e);return e;
  }

  function flock(kind,n,c,o={}){
    const [name,size,speed,rate]=flockSpecies[kind];
    const ctr={x:c.x,y:c.y,z:c.z,a:r()*6.28,R:o.R||30};
    for(let i=0;i<n;i++){
      const scale=size*(.85+r()*.3), bird=createFlyingBird(kind,scale), g=bird.root;
      const e={name,obj:g,r:scale*3,x:c.x+(r()-.5)*10,y:c.y+(r()-.5)*4,z:c.z+(r()-.5)*10,vx:speed,vy:0,vz:0,
        ph:r()*6.28,glide:0,bank:0,off:[(r()-.5)*(o.spread||8),(r()-.5)*3,(r()-.5)*(o.spread||8)],
        ground:o.ground?{x:c.x+(r()-.5)*6,z:c.z+(r()-.5)*6,on:true,t:r()*3,yaw:r()*6.28}:null};
      e.update=(dt,t)=>{
        if(i===0){
          ctr.a+=dt*(speed/ctr.R)*(o.dir||1);
          ctr.x=c.x+Math.cos(ctr.a)*ctr.R*(1+.3*Math.sin(t*.07));
          ctr.z=c.z+Math.sin(ctr.a)*ctr.R;ctr.y=c.y+Math.sin(t*.13+c.x)*(o.dy||4);
        }
        const night=G.sky.night+sstep(6,0,G.sky.el)*.42;
        g.visible=o.night?night>.57:G.sky.night<.63;
        if(!g.visible)return;
        const gr=e.ground;
        if(gr?.on){
          const pd=Math.hypot(G.player.x-gr.x,G.player.z-gr.z);
          gr.t-=dt;
          if(gr.t<0){gr.t=1+r()*3;gr.yaw=r()*6.28;gr.walk=r()<.64;}
          if(gr.walk){gr.x+=Math.cos(gr.yaw)*.25*dt;gr.z-=Math.sin(gr.yaw)*.25*dt;}
          e.x=gr.x;e.z=gr.z;e.y=L.groundAt(gr.x,gr.z)+scale*.55;
          g.position.set(e.x,e.y,e.z);g.rotation.set(0,gr.yaw,0);
          showFineDetail(g, e.r);
          bird.pose(t+i,t*(gr.walk?14:5)+i,true,0,0);
          if(pd<4.5&&!G.player.fly){gr.on=false;gr.back=14+r()*10;e.vy=3;}
          return;
        }
        if(gr){gr.back-=dt;if(gr.back<0&&Math.hypot(e.x-c.x,e.z-c.z)<14){gr.on=true;gr.x=e.x;gr.z=e.z;return;}}
        const dx=ctr.x+e.off[0]-e.x,dy=ctr.y+e.off[1]-e.y,dz=ctr.z+e.off[2]-e.z;
        const turn=(e.vx*dz-e.vz*dx)/speed;
        e.bank=damp(e.bank,clamp(turn*.064,-.55,.55),2.8,dt);
        const k=o.soar?.35:1.2;
        e.vx+=dx*k*dt;e.vy+=dy*k*dt;e.vz+=dz*k*dt;
        const len=Math.hypot(e.vx,e.vy,e.vz)||1, v=speed*(.93+.14*Math.sin(t*1.7+i));
        e.vx*=v/len;e.vy*=v/len;e.vz*=v/len;
        e.x+=e.vx*dt;e.y=Math.max(L.groundAt(e.x,e.z)+1.5,e.y+e.vy*dt);e.z+=e.vz*dt;
        const glide=o.soar?.90:kind==="gull"?(Math.sin(t*.99+i*1.9)>.05?.87:.05):kind==="swallow"?(Math.sin(t*1.75+i)>.59?.78:0):0;
        e.glide=damp(e.glide,glide,4,dt);e.ph+=dt*6.283*rate*(1-e.glide*.77);
        g.position.set(e.x,e.y,e.z);
        g.rotation.set(e.bank,Math.atan2(-e.vz,e.vx),Math.asin(clamp(e.vy/v,-.70,.70)),"YZX");
        showFineDetail(g, e.r);
        bird.pose(t+i,e.ph,false,e.glide,e.bank);
      };
      A.group.add(g);A.list.push(e);
    }
  }

  function swimmer(name,kind,size,area){
    const model=createWaterBird(kind), g=model.root, swan=kind==="swan";
    const e={name,obj:g,r:size*3,x:area.x+(r()-.5)*area.r,z:area.z+(r()-.5)*area.r*.7,yaw:r()*6.28,t:0};
    e.update=(dt,t)=>{
      e.t-=dt;
      if(e.t<0){e.t=4+r()*8;e.ty=r()*6.28;}
      const angle=(e.ty??e.yaw)-e.yaw, delta=Math.atan2(Math.sin(angle),Math.cos(angle));
      e.yaw+=clamp(delta,-dt*.6,dt*.6);
      const speed=swan?.34:.42;
      const nx=e.x+Math.cos(e.yaw)*speed*dt,nz=e.z-Math.sin(e.yaw)*speed*dt;
      if(L.groundAt(nx,nz)<-.5){e.x=nx;e.z=nz;}else e.ty=e.yaw+2.5;
      const bob=Math.sin(t*1.34+e.x);
      const waterline=(L.water??0)-.005+bob*.011;
      g.position.set(e.x,waterline,e.z);g.rotation.set(Math.sin(t*.86+e.z)*.021,e.yaw,bob*.021,"YXZ");
      e.y=waterline+size*.36;
      showFineDetail(g, e.r);
      model.pose(t+e.x*.36,bob,clamp(delta,-1,1));
    };
    A.group.add(g);A.list.push(e);
  }

  function heron(p){
    const model=createWaterBird("egret"), g=model.root;
    g.position.set(p.x,p.y,p.z);g.rotation.y=r()*6.28;
    const a={name:"白鹭",obj:g,r:.8,x:p.x,y:p.y+.84,z:p.z,update(dt,t){
      showFineDetail(g, .8);
      model.pose(t+p.x,0,0);
    }};
    A.group.add(g);A.list.push(a);
  }

  function butterflies(n,pal){
    for(let i=0;i<n;i++){
      const p=L.randGround(r,4,70), model=createButterfly(pal[i%pal.length],i%pal.length),g=model.root;
      const e={name:"蝴蝶",obj:g,r:.12,x:p.x,y:p.y+.6,z:p.z,hx:p.x,hz:p.z,ph:r()*6};
      const bias=r()*6.28;
      e.update=(dt,t)=>{
        g.visible=G.sky.night<.4&&G.sky.w.rain<.35;
        if(!g.visible)return;
        const f=t*.37+bias;
        e.ph=(e.ph+dt*(18+Math.sin(t*5+bias)*8))%(2*Math.PI);
        e.x=e.hx+Math.sin(f)*3+Math.sin(f*3.19)*.74;
        e.z=e.hz+Math.cos(f*1.21)*3+Math.sin(f*2.44)*.57;
        e.y=L.groundAt(e.x,e.z)+.55+Math.sin(t*1.3+i)*.22+Math.sin(e.ph*.48)*.08;
        g.position.set(e.x,e.y,e.z);
        g.rotation.set(.27*Math.sin(t*2+i),Math.atan2(Math.sin(f*1.21),Math.cos(f)),.14*Math.sin(f*2),"YXZ");
        model.pose(e.ph);
      };
      A.group.add(g);A.list.push(e);
    }
  }

  function fireflies(n,c,R){
    const mat=K().glow(0xcbea6b,.012,{night:true}), geo=new THREE.SphereGeometry(.017,9,7);
    geo.userData.wildlifeEffect=true;
    const pts=Array.from({length:n},()=>{
      const a=r()*6.28,d=Math.sqrt(r())*R, g=new THREE.Group(), lamp=new THREE.Mesh(geo,mat), beetle=createFirefly();
      lamp.position.x=-.018;g.add(lamp,beetle.root);A.group.add(g);
      return {m:g,lamp,beetle,x:c.x+Math.cos(a)*d,z:c.z+Math.sin(a)*d,p:r()*6};
    });
    A.list.push({name:"萤火虫",obj:pts[0].m,r:.3,x:c.x,y:1,z:c.z,many:pts,update(dt,t){
      const on=G.sky.night>.3&&G.sky.w.rain<.42;
      for(const q of pts){
        q.m.visible=on&&Math.sin(t*.49+q.p*4)>-.18;
        if(!q.m.visible)continue;
        const x=q.x+Math.sin(t*.31+q.p)*1.7,z=q.z+Math.cos(t*.27+q.p)*1.3;
        q.m.position.set(x,L.groundAt(x,z)+.6+.68*Math.sin(t*.71+q.p*1.21)+.48,z);
        q.m.rotation.y=t*.3+q.p;
        q.lamp.scale.setScalar(.36+.63*Math.pow(Math.max(0,Math.sin(t*3.6+q.p*7)),2));
        q.beetle.root.visible=G.camera.position.distanceToSquared(q.m.position)<13*13;
        if (q.beetle.root.visible) q.beetle.pose(t+q.p);
      }
      const sample=pts.find(q=>q.m.visible);
      if (sample) { const {x,y,z}=sample.m.position;this.x=x;this.y=y;this.z=z; }
      this.obj=sample?.m??pts[0].m;
    }});
  }

  function fish(area){
    const model=createFish(),g=model.root;
    A.group.add(g);
    const e={name:"跃出水面的鱼",obj:g,r:.4,x:0,y:-5,z:0,t:3+r()*8,j:-1};
    e.update=(dt,t)=>{
      e.t-=dt;
      if(e.j<0&&e.t<0){
        for(let i=0;i<20;i++){
          e.x=area.x+(r()-.5)*area.r*1.3;e.z=area.z+(r()-.5)*area.r;
          if(L.groundAt(e.x,e.z)<-1.2)break;
        }
        e.j=0;e.a=r()*6.28;
      }
      if(e.j>=0){
        e.j+=dt*1.3;const k=e.j;
        e.y=Math.sin(k*Math.PI)*.7-.05;
        g.position.set(e.x+Math.cos(e.a)*k*.9,e.y,e.z+Math.sin(e.a)*k*.9);
        g.rotation.set(0,-e.a,Math.atan2(Math.cos(k*Math.PI)*.7*Math.PI,.9),"YZX");
        model.pose(k*.91);g.visible=k<=1;
        if(k>1){e.j=-1;e.t=4+r()*10;e.y=-5;}
      }else g.visible=false;
    };
    A.list.push(e);
  }
  // ---------- sky traffic
  function airliner() {
    const g = new THREE.Group(), model = G.sceneAssets.create("airliner", { length: 42.8, anchorY: 0.30 });
    if (model) g.add(model);
    else {
      const w = flat(0xf0f2f4, { rough: 0.4 }); mesh(new THREE.CylinderGeometry(1.9, 1.9, 36, 12).rotateZ(Math.PI / 2), w, 0, 0, 0, g); ell(3.4, 1.9, 1.9, w, 18, 0, 0, g); mesh(new THREE.ConeGeometry(1.9, 8, 12).rotateZ(Math.PI / 2), w, -22, 0.3, 0, g);
      for (const z of [-1, 1]) { const wg = mesh(new THREE.BoxGeometry(7, 0.35, 17), w, -1, -0.6, z * 9.5, g); wg.rotation.y = z * 0.45; mesh(new THREE.CylinderGeometry(1.0, 1.0, 4, 10).rotateZ(Math.PI / 2), flat(0x9aa0a8, { rough: 0.3, metal: 0.6 }), 1.5, -1.7, z * 6.5, g); const st = mesh(new THREE.BoxGeometry(3.5, 0.25, 6), w, -21, 0.6, z * 3.2, g); st.rotation.y = z * 0.45; }
      mesh(new THREE.BoxGeometry(5, 6.5, 0.3), flat(0x2a5bb0), -21.5, 3.6, 0, g).rotation.z = 0.5;
    }
    const tipX = model ? -6.4 : -1, tipY = model ? 1.15 : -0.6, tipZ = model ? 18.4 : 18;
    mesh(new THREE.SphereGeometry(0.5, 6, 4), K().glow(0xff2a1a, 30), tipX, tipY, -tipZ, g);
    mesh(new THREE.SphereGeometry(0.5, 6, 4), K().glow(0x2aff4a, 30), tipX, tipY, tipZ, g);
    const strobe = mesh(new THREE.SphereGeometry(0.6, 6, 4), K().glow(0xfff0c0, 200), -2, -2.2, 0, g);
    const tm = new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.5, roughness: 1, depthWrite: false });
    const engineSpacing = model ? 6.8 : 6.5;
    for (const z of [-engineSpacing, engineSpacing]) {
      const t = new THREE.Mesh(new THREE.CylinderGeometry(4.5, 1.0, 900, 8, 1, true).rotateZ(-Math.PI / 2), tm);
      t.position.set(-475, -1.5, z); g.add(t);
    }
    A.group.add(g); const e = { name: "客机", obj: g, r: 30, x: 0, y: 0, z: 0, t: 5 + r() * 20, on: false };
    e.update = (dt, t) => { if (!e.on) { e.t -= dt; g.visible = false; if (e.t < 0) { e.on = true; e.a = r() * 6.28; e.d = -1500; e.h = 520 + r() * 420; e.off = (r() - 0.5) * 700; e.s = 0.55 + r() * 0.5; } return; } g.visible = true; e.d += 105 * dt; const ca = Math.cos(e.a), sa = Math.sin(e.a); e.x = ca * e.d - sa * e.off; e.z = sa * e.d + ca * e.off; e.y = e.h; g.position.set(e.x, e.y, e.z); g.rotation.y = -e.a; g.scale.setScalar(e.s);
      strobe.visible = (t * 1.1) % 1 < 0.08; tm.opacity = 0.42 * (1 - G.sky.night * 0.9) * (e.h > 700 ? 1 : 0.4); if (e.d > 1500) { e.on = false; e.t = 15 + r() * 50; } }; A.list.push(e); }
  function balloon(i) { const g = new THREE.Group(), cols = [[0xd9432e, 0xf2c230], [0x2e7fd9, 0xf2f2f2], [0x7a3fd0, 0xf28a30], [0x2fae6a, 0xf2e24a]][i % 4]; const sg = new THREE.SphereGeometry(4.2, 20, 14); const p = sg.attributes.position, c = new Float32Array(p.count * 3), c0 = new THREE.Color(cols[0]), c1 = new THREE.Color(cols[1]);
    for (let k = 0; k < p.count; k++) { const y = p.getY(k), x = p.getX(k), z = p.getZ(k), s = y < 0 ? 1 + y / 9 : 1; p.setXYZ(k, x * s, y < 0 ? y * 1.35 : y, z * s); const st = Math.floor(((Math.atan2(z, x) + Math.PI) / 6.283) * 12 + (y > 1 ? 0.5 : 0)) % 2 ? c0 : c1; c.set([st.r, st.g, st.b], k * 3); } sg.setAttribute("color", new THREE.BufferAttribute(c, 3)); sg.computeVertexNormals();
    const env = new THREE.Mesh(sg, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.7 })); env.castShadow = true; g.add(env); mesh(new THREE.BoxGeometry(1.0, 0.9, 1.0), flat(0x8a6a40), 0, -7.6, 0, g); const fl = mesh(new THREE.ConeGeometry(0.3, 1.2, 6), K().glow(0xff9a3a, 40, { flicker: 0.8 }), 0, -6.4, 0, g);
    const h0 = 28 + r() * 60, a0 = r() * 6.28, R = 60 + r() * 60, e = { name: "热气球", obj: g, r: 6, x: 0, y: 0, z: 0 }; e.update = (dt, t) => { const a = a0 + t * 0.012 * (i % 2 ? 1 : -1); e.x = Math.cos(a) * R; e.z = Math.sin(a) * R; e.y = h0 + Math.sin(t * 0.05 + i * 2) * 10 + Math.max(0, L.groundAt(e.x, e.z)); g.position.set(e.x, e.y, e.z); g.rotation.y = t * 0.03; fl.visible = Math.sin(t * 0.5 + i) > 0.2; g.visible = G.sky.w.rain < 0.4; }; A.group.add(g); A.list.push(e); }
  function meteors() { const m = new THREE.Mesh(new THREE.CylinderGeometry(0.0, 1.6, 160, 5).rotateZ(Math.PI / 2), K().glow(0xdfeaff, 0.0005, { night: true, add: true, transparent: true, fog: false })); m.visible = false; A.group.add(m);
    const e = { name: "流星", obj: m, r: 80, x: 0, y: 0, z: 0, t: 6 + r() * 14, j: -1 }; e.update = (dt) => { if (G.sky.night < 0.6) { m.visible = false; return; } e.t -= dt; if (e.j < 0 && e.t < 0) { e.j = 0; const a = r() * 6.28; e.p0 = [Math.cos(a) * 2200 * (0.3 + r()), 1500 + r() * 800, Math.sin(a) * 2200 * (0.3 + r())]; const b = r() * 6.28; e.v = [Math.cos(b) * 2600, -900 - r() * 700, Math.sin(b) * 2600]; }
      if (e.j >= 0) { e.j += dt; const c = G.camera.position; e.x = c.x + e.p0[0] + e.v[0] * e.j; e.y = e.p0[1] + e.v[1] * e.j; e.z = c.z + e.p0[2] + e.v[2] * e.j; m.position.set(e.x, e.y, e.z); m.visible = true; V.set(e.v[0], e.v[1], e.v[2]).normalize(); m.quaternion.setFromUnitVectors(new THREE.Vector3(-1, 0, 0), V); if (e.j > 0.7) { e.j = -1; e.t = 8 + r() * 30; m.visible = false; } } }; A.list.push(e); }
  function satellite() { const m = new THREE.Mesh(new THREE.SphereGeometry(1.6, 6, 4), K().glow(0xffffff, 0.00012, { night: true, fog: false })); A.group.add(m); const a = r() * 6.28; A.list.push({ name: "卫星", obj: m, r: 10, x: 0, y: 0, z: 0, d: -3000, update(dt) { this.d += 60 * dt; if (this.d > 3000) this.d = -3000; const c = G.camera.position; this.x = c.x + Math.cos(a) * this.d; this.z = c.z + Math.sin(a) * this.d + 400; this.y = 2600; m.position.set(this.x, this.y, this.z); m.visible = G.sky.night > 0.7; } }); }
  function drone(home) { const g = new THREE.Group(), d = flat(0x2a2c30, { rough: 0.4 }); mesh(new THREE.BoxGeometry(0.3, 0.08, 0.2), d, 0, 0, 0, g); const rot = []; for (const [x, z] of [[1, 1], [1, -1], [-1, 1], [-1, -1]]) { mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.3, 4).rotateZ(Math.PI / 2).rotateY(Math.atan2(z, x)), d, x * 0.13, 0, z * 0.13, g); const p = mesh(new THREE.BoxGeometry(0.24, 0.005, 0.025), flat(0x777777), x * 0.22, 0.04, z * 0.22, g); rot.push(p); }
    const led = mesh(new THREE.SphereGeometry(0.02, 6, 4), K().glow(0x30ff50, 60), 0.15, 0, 0, g), led2 = mesh(new THREE.SphereGeometry(0.02, 6, 4), K().glow(0xff3020, 60), -0.15, 0, 0, g); A.group.add(g);
    const e = { name: "无人机", obj: g, r: 0.5, x: home.x, y: home.y, z: home.z }; e.update = (dt, t) => { e.x = home.x + Math.sin(t * 0.21) * 14; e.z = home.z + Math.cos(t * 0.17) * 12; e.y = home.y + Math.sin(t * 0.4) * 3; g.position.set(e.x, e.y, e.z); g.rotation.set(Math.cos(t * 0.17) * 0.15, t * 0.2, Math.cos(t * 0.21) * 0.15); for (const p of rot) p.rotation.y = t * 60; led2.visible = (t * 2) % 1 < 0.5; }; A.list.push(e); }
  // ---------- road traffic (city supplies lanes: [[x,z],...] closed loops)
  function car(lane, off, kind) { const g = new THREE.Group(), cols = [0x151618, 0xd4d5d7, 0x7c8188, 0x22324f, 0x511414, 0xaaa594, 0x2c3a33], big = kind === "bus" || kind === "tram"; let Lc, Wc;
    const glass = K().flat(0x0c1218, { rough: 0.06, metal: 0.8, detail: 'glass' }), hl = K().glow(0xfff4d8, 40, { night: true }), tl = K().glow(0xff1a10, 2.5);
    if (!big) { const taxi = kind === "taxi", van = kind === "van", paint = K().flat(taxi ? 0x9c1a15 : van ? 0xd9d4bc : cols[Math.floor(r() * cols.length)], { rough: 0.34, metal: 0.3, wet: 1, coat: 1 }); const c = buildCar(K(), taxi ? "taxi" : van ? "van" : "sedan", paint, { glass, head: hl, tail: tl, roof: taxi ? K().flat(0xc9c9c4, { rough: 0.3, metal: 0.5 }) : van ? K().flat(0x1c5a3c, { rough: 0.4, metal: 0.3 }) : null }, r); g.add(c); Lc = taxi ? 4.7 : van ? 5.4 : 4.6; Wc = 1.8; }
    else { const tram = kind === "tram", b = buildBus(K(), tram, tram ? [0x1f4a34, 0x5a1a1a, 0x1c3050, 0x2a2a2c][Math.floor(r() * 4)] : [0xa81c1c, 0xc8a020, 0x1c4a8a, 0xb0b4b8][Math.floor(r() * 4)], r); g.add(b.g); Lc = b.L; Wc = b.W; }
    if (!A._beamTex) A._beamTex = K().canvasTex(128, 64, (c) => { const g = c.createRadialGradient(4, 32, 2, 4, 32, 124); g.addColorStop(0, "rgba(255,255,255,1)"); g.addColorStop(0.35, "rgba(255,255,255,0.35)"); g.addColorStop(1, "rgba(255,255,255,0)"); c.fillStyle = g; c.fillRect(0, 0, 128, 64); });
    const beam = new THREE.Mesh(new THREE.PlaneGeometry(10, Wc * 2.2).rotateX(-Math.PI / 2).translate(Lc / 2 + 5, 0.03, 0), K().glow(0xfff0c8, 0.0012, { night: true, add: true, transparent: true, map: A._beamTex })); /* soft pool of headlight on the road */ g.add(beam);
    A.group.add(g); const len = lane.len, e0 = null, e = { name: { bus: "双层巴士", tram: "有轨电车", taxi: "出租车", van: "小巴", car: "汽车" }[kind], obj: g, r: Lc / 2, x: 0, y: 1, z: 0, d: off, v: lane.v || 8 };
    e.L = Lc; lane.cars?.push(e); e.update = (dt) => { let v = e.v; if (lane.stop && lane.stop(e.d)) v = 0;
      // a person on the road ahead (seen from ~25 m): brake to a halt a few metres short and wait until they have gone
      { const P = G.player; if (lane.project && P.y < 2.5) { const q = lane.project(P.x, P.z), ahead = (q.d - e.d + len) % len - Lc / 2; if (Math.abs(q.lat) < 2.1 && ahead > -0.5 && ahead < 26) v = Math.min(v, Math.max(0, (ahead - 3.5) * 0.7)); } }
      // keep a gap to the car in front, so the ones behind queue up too
      for (const o of lane.cars || []) { if (o === e) continue; const gap = (o.d - e.d + len) % len - (o.L + Lc) / 2; if (gap > 0 && gap < 18) v = Math.min(v, Math.max(0, (gap - 2.2) * 0.8)); }
      { const P = G.player, dd = Math.hypot(P.x - e.x, P.z - e.z); g.visible = dd < 125; g.userData.far = dd > 45; } e.cur = damp(e.cur || 0, v, 1.5, dt); e.d = (e.d + e.cur * dt) % len; const p = lane.at(e.d); e.x = p.x; e.z = p.z; e.yaw = p.yaw; g.position.set(p.x, 0, p.z); g.rotation.y = p.yaw; }; A.list.push(e); A.cars.push({ e, hl: Lc / 2 + 0.1, hw: Wc / 2 + 0.1, h: big ? 4.4 : 1.7 }); }
  A.car = car;
  // ---------- per-level cast
  A.clear = () => { A.cars.length = 0;
    const skeletons=new Set(), effects=new Set();
    A.group.traverse((o)=>{
      if(o.isSkinnedMesh && o.parent?.userData.wildlife) skeletons.add(o.skeleton);
      if(o.geometry?.userData.wildlifeEffect) effects.add(o.geometry);
    });
    for(const skeleton of skeletons) skeleton.dispose();
    for(const effect of effects) effect.dispose();
    A.group.clear();
    A.list.length=0;
  };
  A.populate = (lv) => { L = lv; r = rng(31);
    if (lv.id === "nature") { for (const [k, x, z] of lv.pets || []) { const e = animal(k, { x, z }, 4); e.pet = true; } const pt = (r0, r1) => lv.randGround(r, r0, r1); for (let i = 0; i < 5; i++) animal("deer", pt(25, 85), 40); animal("stag", pt(30, 80), 50); animal("stag", pt(40, 90), 50); for (let i = 0; i < 2; i++) animal("fox", pt(20, 80), 60); for (let i = 0; i < 7; i++) animal("rabbit", pt(6, 60), 18);
      for (let i = 0; i < 3; i++) animal("horse", { x: 52 + i * 4, z: -12 - i * 5 }, 16); for (let i = 0; i < 3; i++) animal("cow", { x: 58 + i * 3, z: 30 + i * 6 }, 16); for (let i = 0; i < 5; i++) animal("sheep", { x: 20 + i * 2, z: -52 - i * 2 }, 14);
      flock("sparrow", 30, { x: 30, y: 9, z: 0 }, { R: 26, spread: 7 }); flock("sparrow", 16, { x: -40, y: 8, z: -30 }, { R: 20, spread: 6 }); flock("gull", 16, { x: 0, y: 12, z: 130 }, { R: 50, spread: 16 }); flock("crow", 6, { x: 60, y: 20, z: -40 }, { R: 30, spread: 10 }); flock("gull", 10, { x: lv.lake.x, y: 9, z: lv.lake.z }, { R: 30, spread: 14, dir: -1 }); flock("crow", 4, { x: -10, y: 16, z: -50 }, { R: 34, spread: 10 }); flock("eagle", 1, { x: 0, y: 70, z: -20 }, { R: 70, soar: true, dy: 12 }); flock("eagle", 1, { x: 40, y: 95, z: 40 }, { R: 90, soar: true, dy: 15, dir: -1 });
      flock("swallow", 16, { x: 12, y: 5, z: 18 }, { R: 16, spread: 8, dy: 2 }); flock("swallow", 10, { x: -30, y: 6, z: 40 }, { R: 20, spread: 8, dy: 3 }); flock("bat", 9, { x: 36, y: 7, z: 16 }, { R: 12, spread: 8, dy: 2, night: true });
      for (let i = 0; i < 4; i++) swimmer("野鸭", "duck", .2, lv.lake); for (let i = 0; i < 2; i++) swimmer("天鹅", "swan", .4, lv.lake);
      for (let i = 0; i < 3; i++) { const a = i * 2.1 + 0.4, x = lv.lake.x + Math.cos(a) * (lv.lake.r - 9), z = lv.lake.z + Math.sin(a) * (lv.lake.r - 9) / 1.25; heron({ x, y: Math.max(lv.groundAt(x, z), -0.25), z }); }
      butterflies(26, [0xf2a020, 0xf4f4f0, 0x4a8fe0, 0xe8d23a, 0xd9482e]); fireflies(70, { x: 28, z: 22 }, 26); fireflies(50, { x: -8, z: -40 }, 20); for (let i = 0; i < 3; i++) fish(lv.lake); for (let i = 0; i < 4; i++) balloon(i); airliner(); airliner(); meteors(); meteors(); satellite(); }
    if (lv.id === "city") { for (const [k, x, z] of lv.pets || []) animal(k, { x, z }, 9); flock("pigeon", 18, { x: lv.plaza.x, y: 7, z: lv.plaza.z }, { R: 10, spread: 5, ground: true, dy: 2 }); for (const [x, z] of [[30, 16], [-60, -16], [64, 16], [-18, 66]]) flock("pigeon", 12, { x, y: 6, z }, { R: 9, spread: 4, ground: true, dy: 2 }); flock("gull", 14, { x: 0, y: 14, z: 110 }, { R: 50, spread: 16 }); flock("gull", 8, { x: -60, y: 10, z: 90 }, { R: 30, spread: 10, dir: -1 }); flock("crow", 7, { x: 0, y: 28, z: 0 }, { R: 34 }); flock("sparrow", 14, { x: -14, y: 6, z: 12 }, { R: 12, spread: 5 }); flock("sparrow", 12, { x: 50, y: 5, z: -16 }, { R: 10, spread: 5 }); flock("swallow", 12, { x: 20, y: 18, z: 0 }, { R: 30, spread: 10, dy: 4 }); flock("bat", 6, { x: 6, y: 10, z: -8 }, { R: 12, night: true });
      let n = 0; for (const lane of lv.lanes || []) for (let d = 6; d < lane.len - 12; d += 44 + r() * 30) { n++; car(lane, d, lane.tram ? (n % 3 === 0 ? "tram" : n % 3 === 1 ? "bus" : "taxi") : n % 5 === 0 ? "van" : n % 2 ? "taxi" : "car"); if (lane.tram) d += 8; } airliner(); airliner(); drone({ x: 8, y: 14, z: 6 }); meteors(); satellite(); }
    if (lv.id === "indoor") { for (const [k, x, z] of lv.pets || []) animal(k, { x, z }, 4); lv.spawnLife?.(A, { flock, butterflies, mesh, flat, ell, r }); flock("sparrow", 5, { x: 0, y: 9, z: -14 }, { R: 9, spread: 4 }); airliner(); }
  };
  A.update = (dt, t) => { for (const e of A.list) e.update(dt, t); };
  // which named things sit inside the photo frame (and are big enough to count)
  A.inFrame = (cam, rect) => { const out = new Set(), fl = 1 / Math.tan((cam.fov * Math.PI) / 360); for (const e of A.list) { if (!e.obj.visible) continue; V.set(e.x, e.y ?? e.obj.position.y, e.z); const d = V.distanceTo(cam.position); V.project(cam); if (V.z > 1 || V.z < -1) continue; const u = V.x * 0.5 + 0.5, v = V.y * 0.5 + 0.5;
      if (u > rect[0] && u < rect[0] + rect[2] && v > rect[1] && v < rect[1] + rect[3] && ((e.r / d) * fl) / rect[3] > 0.012) out.add(e.name); } return [...out]; };
  return A;
}
