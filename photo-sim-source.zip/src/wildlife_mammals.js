import { ball, buildAnimal, ease, grain, mix, tones, transition } from "./wildlife_mesh.js";

// Body length, shoulder height and coat markings follow each animal rather than a scaled copy.
export const mammals = {
  deer: ["鹿",1.26,.94,.45,.43,.43,.31,.19,.037, .95,6.4,13, 0x995e3d,0xe8c7a2,0x502e22],
  stag: ["雄鹿",1.49,1.12,.53,.52,.52,.35,.18,.045, 1,7,15, 0x875638,0xc6a688,0x3c271e],
  fox: ["狐狸",.68,.335,.235,.219,.117,.18,.108,.023, 1.08,5.7,10, 0xaf4e24,0xe7d8c5,0x35241e],
  rabbit: ["兔子",.36,.17,.182,.18,.073,.12,.159,.019, .75,4.3,6, 0xa4896d,0xe3d6bf,0x6f5746],
  horse: ["马",1.92,1.34,.68,.72,.60,.52,.14,.061, 1.2,7.4,0, 0x754731,0xb08863,0x2b201c],
  cow: ["奶牛",1.82,1.09,.76,.76,.28,.40,.17,.058, .65,2,0, 0xe9e3d8,0xf6eee6,0x262329],
  sheep: ["绵羊",.91,.57,.51,.55,.21,.23,.10,.029, .62,2.8,5, 0xd9cbb4,0xf6efe1,0x493c36],
  cat: ["猫",.43,.255,.188,.168,.046,.126,.058,.019, .69,3.5,0, 0xb97848,0xe5cdb0,0x79452c],
  cat2: ["黑猫",.43,.255,.188,.168,.046,.126,.058,.019, .69,3.5,3, 0x2d2a30,0x40393e,0x15151a],
  // more cats: same build, different coats (and a stockier British shorthair)
  catW: ["白猫",.43,.255,.188,.168,.046,.126,.058,.019, .69,3.5,2, 0xe7e2d8,0xf6f2ea,0xc9c0b2],
  catG: ["英短蓝猫",.44,.25,.215,.18,.046,.135,.052,.021, .62,3.2,1, 0x777d86,0x8d939b,0x575c64],
  catC: ["三花猫",.42,.25,.185,.166,.046,.124,.058,.019, .7,3.6,3, 0xc9783a,0xf2ece2,0x231f22],
  catS: ["暹罗猫",.44,.26,.18,.165,.046,.122,.062,.018, .72,3.7,2, 0xe6d9bf,0xf3ecdc,0x46332a],
  catT: ["奶牛猫",.43,.255,.188,.168,.046,.126,.058,.019, .69,3.5,3, 0x1e1c20,0xf2efe8,0x111014],
  catL: ["狸花猫",.43,.25,.186,.166,.046,.125,.058,.019, .7,3.6,3, 0x8a7a60,0xd9cdb6,0x2c241e],
  dog: ["柴犬",.59,.36,.283,.278,.096,.20,.09,.029, 1.02,4.8,0, 0xb67c49,0xead3af,0x724c31],
};
const templates = new Map();
const tau = Math.PI*2;
const colourBySpecies = {
  deer: "dapple", stag: "dark neck", cat: "tabby", catL: "tabby", catW: "solid", catG: "solid", catC: "calico", catS: "point", catT: "tuxedo", cow: "patches", fox: "stockings", sheep: "fleece",
};

function prepare(kind) {
  const [name,L,H,W,D,N,F,E,R,walk,run,flee,base,pale,dark] = mammals[kind];
  const deer=kind==="deer"||kind==="stag", horse=kind==="horse", sheep=kind==="sheep", cow=kind==="cow";
  const rabbit=kind==="rabbit", fox=kind==="fox", dog=kind==="dog", cat=kind.startsWith("cat");
  const A=buildAnimal(), body=A.joint("Body"), chest=L*.30, hip=-L*.35;
  const neckAt=[chest,H-D*.07,0], headAt=[L*(rabbit?.53:dog?.42:cat?.42:.455)+N*(horse?.43:.21),H+N,0];
  const neck=A.joint("Neck",neckAt,body), head=A.joint("Head",headAt,neck);
  const tailAt=[-L*.48,H-D*.025,0], tail=A.joint("Tail",tailAt,body);
  const y=H-D*.27, hx=headAt[0], hy=headAt[1], jaw=-F*(horse?.53:.14);
  const cheek=F*(cat?.43:rabbit?.42:cow?.44:dog?.44:.32);
  const fore=F*(cat?.54:rabbit?.62:sheep?.74:dog?.70:1.0);
  const muzzleX=hx+fore*.75, muzzleY=hy+jaw, noseX=hx+fore*.99;
  const bodyTone=tones(base,pale,dark,0xf5ebdc,0x272222,0x69534b,0xcd8f89);
  const underTone=tones(pale);
  const marking=colourBySpecies[kind];
  const noseTone=tones(0x241819,0x111115,0x98685e,0xb57872);
  const legPairs = [[1,1],[1,-1],[-1,1],[-1,-1]];
  const legs = legPairs.map(([front, side], i) => {
    const rear=front<0;
    const x=rear?hip:chest, z=W*side*(rear?.32:.31);
    const p=[x,H-D*(rear?.22:.27),z];
    const q=[x+L*(rear?-.075:.018),H*(rear?.43:.48),z+side*R*.06];
    const f=[x+L*(rear?(rabbit?.13:.015):.043),R*.57,z+side*R*.10];
    const upper=A.joint("Leg_"+i,p,body), lower=A.joint("Leg_"+i+"_shin",q,upper);
    return {p,q,f,upper,lower,rear,side};
  });

  function bodyPaint(x,y,z,ny) {
    const v = 1+grain(x,y,z)*.048+Math.sin(x*19-y*29+z*11)*.027;
    const under=ease(.03,.81,-ny)*.72;
    if (marking==="patches") {
      const spots=Math.sin(x*8+y*10+z*6)+.57*Math.cos(x*19-z*9)+.49*Math.sin(z*18+y*5);
      return bodyTone(0,2,ease(.45,.67,spots),v);
    }
    if (marking==="tabby"&&x<hx-F*.12) {
      const stripes=Math.sin(x*85+3*Math.sin(y*29)+Math.abs(z)*12);
      return bodyTone(0,2,ease(.33,.86,stripes)*(1-under)*.76,v).lerp(underTone(),under*.67);
    }
    if (marking==="solid") return bodyTone(0,1,under*.3,v);
    if (marking==="calico") { // white base with orange and black islands
      const n1=Math.sin(x*23+Math.sin(z*17)*2.1+y*9)+.6*Math.sin(z*31-x*12), n2=Math.sin(x*19-y*27+Math.cos(z*14)*1.7)+.5*Math.cos(x*41+z*9);
      const white=Math.max(under*1.3, ease(hx+F*.05,muzzleX,x)*.9); const c=bodyTone(1,0,ease(.35,.6,n1)*(1-white),v).clone(); return c.lerp(bodyTone(2,2,0,v),ease(.55,.8,n2)*(1-white)*(1-ease(.35,.6,n1)*.5));
    }
    if (marking==="point") { // Siamese: cream body, dark mask, ears, legs and tail
      const pt=Math.max(ease(hx-F*.05,muzzleX,x)*(1-ease(hy-F*.02,hy+F*.2,y)*.6), 1-ease(H*.25,H*.58,y), ease(-L*.40,-L*.52,x));
      return bodyTone(0,2,pt*.92,v);
    }
    if (marking==="tuxedo") { // black coat, white bib, belly, muzzle and socks
      const wht=Math.max(ease(.18,.42,under), ease(muzzleX-F*.35,muzzleX,x)*(1-ease(hy,hy+F*.15,y)), 1-ease(H*.12,H*.24,y));
      return bodyTone(0,1,wht,v);
    }
    if (marking==="dapple" && x<chest*.95 && Math.abs(z)>W*.29 && y>H-D*.30) {
      const dx=x*12+Math.sin(y*17+z*21)*.15, dy=y*16+x*1.3;
      const spots=Math.hypot(dx-Math.round(dx),dy-Math.round(dy));
      return bodyTone(0,3,(1-ease(.12,.26,spots))*ease(W*.29,W*.41,Math.abs(z))*.75,v);
    }
    if (marking==="dark neck") return bodyTone(0,2,ease(chest,hx,x)*.54-under*.19,v);
    if (sheep) return bodyTone(0,2,ease(hx-F*.20,hx+F*.35,x)*.96,v);
    const cheekMark=ease(hx-F*.13,muzzleX,x)*(1-ease(hy-F*.13,hy+F*.10,y));
    const mask=(cat||dog||fox||rabbit) ? Math.max(under,cheekMark*.92) : under;
    return bodyTone(0,1,mask,v);
  }
  const trunk = [
    ball(-L*.28,y+D*.045,0,L*(rabbit?.30:.27),D*(rabbit?.57:.47),W*.49, rabbit?-.21:-.04),
    ball(-L*.02,y-D*.012,0,L*.37,D*.46,W*(cat?.39:.45),-.04),
    ball(L*.26,y+D*.015,0,L*.28,D*.48,W*.46,.17),
    ball(neckAt[0]+(hx-neckAt[0])*.25,neckAt[1]+(hy-neckAt[1])*.22,0,
      Math.hypot(hx-neckAt[0],hy-neckAt[1])*.52,D*(horse?.37:dog?.36:deer?.31:.28),W*.36,
      Math.atan2(hy-neckAt[1],hx-neckAt[0])),
    ball(neckAt[0]+(hx-neckAt[0])*.68,neckAt[1]+(hy-neckAt[1])*.67,0,
      Math.hypot(hx-neckAt[0],hy-neckAt[1])*.42,D*(horse?.23:dog?.28:.22),W*.27,
      Math.atan2(hy-neckAt[1],hx-neckAt[0])),
    ball(hx-F*.12,hy-N*.10,0,F*(cat?.39:.38),F*(cat?.36:.38),cheek,.06),
    ball(hx+F*.12,hy,0,F*(cat?.33:.42),F*(cat?.36:.31),cheek*.92,jaw*.75/F),
    ball(muzzleX,muzzleY,0,fore*(horse?.31:.40),F*(horse?.21:cow?.23:cat?.18:.15),cheek*(cow?1.00:cat?.84:fox?.50:.65),jaw/F),
  ];
  if (horse) trunk.push(ball(hx+F*.385,hy-F*.226,0,F*.432,F*.181,cheek*.72,-.69));
  const shoulderW = W*(horse?.28:sheep?.23:.24);
  for (const {p,rear,side} of legs) {
    const xx=p[0] + L*(rear?-.018:.012);
    trunk.push(ball(xx,H-D*.27,side*W*.29,L*(rear?.150:.117),D*(rear?.44:.45),shoulderW,rear?-.42:.36));
  }
  const woolRipple = (x,y,z) => {
    const clusters=Math.sin(x*62+Math.sin(z*39)*1.3)*Math.cos(y*61+Math.sin(x*44))*Math.sin(z*58+y*22);
    return (.012*clusters + grain(x,y,z,.61)*.006)*(1-ease(hx-F*.38,hx+F*.1,x));
  };
  A.volume(trunk,bodyPaint,(x,y,z)=>{
    const n=ease(H-D*.17,hy-F*.28,y)*ease(L*.04,hx-F*.21,x);
    const h=ease(hy-F*.48,hy-F*.03,y)*ease(hx-F*.51,hx+F*.14,x);
    return [[body,1-Math.max(n,h)],[neck,Math.max(0,n-h)],[head,h]];
  },{blend:Math.min(.049,L*(cat?.052:.066)),material:sheep?"wool":"coat",noise:sheep?woolRipple:undefined,resolution:sheep?61:48});

  const hoofPaint=tones(0x463a31,0x29252a,0x5d5046);
  for(const {p,q,f,upper,lower,rear} of legs){
    const upperRadius=R*(rabbit&&rear?3.0:horse?1.95:sheep?1.66:rear?2.03:1.69);
    const footX=f[0]+R*(rabbit&&rear?1.65:.46);
    const at=(a,b,t)=>a.map((x,i)=>mix(x,b[i],t));
    const a=at(p,q,.29), b=at(p,q,.73), c=at(q,f,.58);
    const hingeY=q[1];
    const legWeights=(_x,y)=> {
      const knee=1-ease(hingeY-R*1.5,hingeY+R*1.25,y);
      const shoulder=ease(p[1]-R*2,p[1]+R*1.4,y);
      return [[body,shoulder],[upper,(1-knee)*(1-shoulder)],[lower,knee*(1-shoulder)]];
    };
    const legsPaint=(x,y,z,ny)=>{
      if(fox||sheep) return bodyTone(0,2,(1-ease(H*.35,H*.60,y))*(fox?.98:1),1+grain(x,y,z)*.08);
      if(horse&&p[2]>0&&!rear) return bodyTone(0,3,(1-ease(H*.10,H*.24,y))*.89);
      return bodyPaint(x,y,z,ny);
    };
    A.tube([[p[0],p[1]+R*1.26,p[2],upperRadius,upperRadius*.94],
      [...a,upperRadius*.77,upperRadius*(rear?.92:.73)],[...b,R*.94,R*(rear?1.12:.93)],
      [...q,R*.84,R*.93],[...c,R*.58,R*.66],[f[0],f[1]+R*.48,f[2],R*.64,R*.65]],
      legsPaint,legWeights,"coat",{seg:14,up:[1,0,0]});
    if(deer||horse||cow||sheep) {
      const split=horse?1:2;
      for(let i=0;i<split;i++){
        const z=f[2]+(i-(split-1)/2)*R*.69;
        A.oval([footX,R*.52,z],[R*(horse?1.22:1.03),R*.50,R*(horse?.84:.37)],
          (_x,y)=>hoofPaint(0,1,1-ease(R*.2,R*.85,y)),lower,"eye",-.13);
      }
    } else {
      A.oval([footX,R*.45,f[2]],[R*(rabbit?1.64:1.18),R*.44,R*.78],legsPaint,lower,"coat",.12);
      if(!rabbit) for(let i=-1;i<=1;i++) A.oval([footX+R*.65,R*.26,f[2]+i*R*.38],[R*.44,R*.25,R*.25],legsPaint,lower);
    }
  }

  const earPaint=tones(base,dark,0xb4847c,0xd2ad9f,0x936c62);
  const irisPaint=tones(kind==="catS"||kind==="catW"?0x5a8fd0:kind==="catG"?0xc8862e:cat?0xb39b49:rabbit?0x50352c:0x77523a,0x24191a,0x100e10);
  for(const side of [-1,1]){
    const ez=cheek*.61, height=E*(rabbit?1.08:1);
    const earRoot=[hx-F*(cat?.15:.26),hy+F*.19,side*ez];
    const earTip=[earRoot[0]-height*(horse?.13:rabbit?.43:.17),earRoot[1]+height*(sheep?.18:cow?.34:rabbit?.94:.88),side*(ez+height*(deer?.79:sheep?1.06:cow?.98:rabbit?.36:.46))];
    const ear=A.joint(side>0?"Ear_L":"Ear_R",earRoot,head);
    const mid=earRoot.map((p,i)=>mix(p,earTip[i],.48));
    const leaf=height*(deer?.27:rabbit?.22:sheep?.31:cat||dog?.40:.25);
    A.tube([[...earRoot,leaf*.63,leaf*.58],[...mid,leaf,leaf*.41],[...earTip,leaf*.14,leaf*.095]],
      (x,y)=>earPaint(0,1,ease(mid[1],earTip[1]+.003,y)*(fox||sheep?.95:.38),1+grain(x,y,0)*.08),
      ear,"coat",{seg:14,up:[1,0,0]});
    const inner=mid.map((p,i)=>p+(i===0?leaf*.35:0));
    A.oval(inner,[leaf*.27,Math.max(height*.24,.009),leaf*.77],earPaint(2,3,.45),ear,"coat",.22);
    const eyeX=hx+F*(cat?.34:dog?.29:.25), eyeY=hy+F*.097;
    const eyeZ=side*cheek*(cat?.80:dog?.85:.82), eyeSize=F*(cat?.105:rabbit?.105:deer?.071:.078);
    A.oval([eyeX,eyeY,eyeZ],[eyeSize*1.30,eyeSize*.78,eyeSize*.55],irisPaint(1),head,"eye",-.14);
    A.oval([eyeX+eyeSize*.16,eyeY,eyeZ+side*eyeSize*.39],[eyeSize*.73,eyeSize*.63,eyeSize*.25],irisPaint(0),head,"eye");
    A.oval([eyeX+eyeSize*.25,eyeY,eyeZ+side*eyeSize*.60],[eyeSize*(cat?.32:.49),eyeSize*.54,eyeSize*.15],irisPaint(2),head,"eye");
    if(cat||rabbit||fox) for(let j=0;j<3;j++){
      const x=muzzleX+F*.085, z=side*cheek*.87, y=muzzleY+F*(j-.9)*.036;
      A.tube([[x,y,z,F*.0046],[x-F*.16,y-F*.011,side*(Math.abs(z)+F*.19),F*.0031],
        [x-F*.37,y-F*(j-.2)*.054,side*(Math.abs(z)+F*.35),F*.0012]],0xa49785,head,"eye",{seg:5,sub:2,cap:1});
    }
  }
  A.oval([noseX+F*(cat?.025:.003),muzzleY+F*.055,0],[F*(cow?.132:cat?.077:.092),F*(cow?.155:.093),cheek*(cow?.96:horse?.70:.54)],
    cow?noseTone(2,3,.76):noseTone(0,1,.69),head,"eye",-.13);
  for(const side of [-1,1]){
    A.oval([noseX+F*.067,muzzleY+F*.061,side*cheek*(cow?.53:.29)],[F*.026,F*.031,F*.064],0x211718,head,"eye",-.26);
    const z=cheek*(cat?.58:cow?.76:.51)*side;
    A.tube([[noseX-F*.02,muzzleY-F*.062,z*.67,F*.008],[muzzleX-F*.03,muzzleY-F*.096,z,F*.007],
      [muzzleX-F*.21,muzzleY-F*.058,z*.98,F*.002]],0x48352d,head,"eye",{seg:5,sub:3,cap:1});
  }

  if(kind==="stag") for(const side of [-1,1]){
    const x=hx-F*.30, y=hy+F*.24, z=side*cheek*.70, antler=0xa6937a;
    const beam=[[x,y,z,.023],[x-.10,y+.19,z+side*.112,.022],[x-.14,y+.36,z+side*.20,.018],
      [x-.10,y+.50,z+side*.258,.013],[x-.026,y+.57,z+side*.273,.003]];
    A.tube(beam,antler,head,"coat",{seg:10});
    for(const [p,d,spread] of [[beam[1],.25,.09],[beam[2],.24,.08],[beam[3],.16,.045]]){
      A.tube([[...p.slice(0,3),.016],[p[0]+d*.50,p[1]+d*.41,p[2]+side*spread*.75,.012],
        [p[0]+d,p[1]+d*.83,p[2]+side*spread,.0024]],antler,head,"coat",{seg:8});
    }
  }
  if(cow) {
    for(const s of [-1,1]) A.tube([[hx-F*.20,hy+F*.19,s*cheek*.74,.038],
      [hx-F*.32,hy+F*.34,s*cheek*1.2,.027],[hx-F*.38,hy+F*.52,s*cheek*1.5,.006]],0xc7b596,head);
    A.oval([-L*.21,H-D*.85,0],[L*.10,D*.12,W*.22],0xca9a88,body);
    for(const s of [-1,1]) for(const i of [-1,1]) A.oval([-L*.21+i*L*.054,H-D*.95,s*W*.101],[.022,.052,.023],0xc99a8e,body);
  }
  if(horse) {
    const mane=tones(0x201a18,0x5c3926);
    A.tube([[hx-F*.41,hy+F*.29,0,.045,.089],[hx-F*.52,hy-N*.03,0,.069,.10],
      [hx-N*.57,hy-N*.43,0,.066,.115],[chest-L*.20,H+D*.17,0,.045,.070]],(x,y,z)=>mane(0,1,.23+.22*grain(x,y,z)),
      (x,y)=>transition(neck,head,ease(hy-N*.22,hy+F*.23,y)),"coat",{seg:16});
    for(const side of [-1,1]) for(let i=0;i<6;i++){
      const t=i/5,x=mix(hx-F*.47,chest-L*.16,t),y=mix(hy+F*.24,H+D*.19,t);
      A.vane([x,y,side*.043],[x-.14,y-.12,side*(.09+t*.022)],.090,.024,
        (u,v,w)=>mane(0,1,.21+.13*grain(u,v,w)),(x,y)=>transition(neck,head,ease(hy-N*.22,hy+F*.23,y)),"plumage");
    }
  }

  let tailPoints;
  if(dog) tailPoints=[[0,0,.051],[-.08,.065,.059],[-.11,.157,.063],[-.045,.214,.056],[.028,.175,.035],[.007,.126,.010]];
  else if(cat) tailPoints=[[0,0,R*1.37],[-.093,.041,R*1.23],[-.18,.125,R*1.0],[-.23,.247,R*.89],[-.19,.304,R*.42]];
  else if(fox) tailPoints=[[0,0,.041],[-.115,-.033,.058],[-.247,-.076,.068],[-.369,-.099,.052],[-.461,-.088,.017]];
  else if(horse||cow) tailPoints=[[0,0,R*.52],[-.12,-.105,R*.71],[-.19,-H*.37,R*(horse?1.20:.39)],[-.24,-H*.66,R*(horse?1.06:.53)],[-.19,-H*.76,R*(horse?.48:.86)]];
  else tailPoints=[[0,0,R*1.1],[-R*1.50,rabbit?R*1.4:-R*.6,R*(rabbit?2.0:1.5)],[-R*3.1,rabbit?R*.91:-R*2,R*.43]];
  A.tube(tailPoints.map(([x,y,r])=>[tailAt[0]+x,tailAt[1]+y,0,r]),
    (x,y,z)=> {
      if(fox) return bodyTone(0,3,1-ease(tailAt[0]-.42,tailAt[0]-.34,x));
      if(horse||cow) return bodyTone(2,0,horse?0:ease(-H*.62,-H*.38,y-H));
      if(rabbit||deer) return bodyTone(0,3,.81);
      return bodyPaint(x,y,z,-.2);
    },tail,"coat",{seg:15,sub:6});
  return {create:A.finish(kind),legs,walk,run,flee,name,length:L,shoulder:H,rabbit};
}

function stepAngles(leg,dx,dy) {
  const {p,q,f,rear} = leg;
  const a0=Math.atan2(q[1]-p[1],q[0]-p[0]);
  const b0=Math.atan2(f[1]-q[1],f[0]-q[0]);
  const a=Math.hypot(q[0]-p[0],q[1]-p[1]), b=Math.hypot(f[0]-q[0],f[1]-q[1]);
  const x=f[0]-p[0]+dx,y=f[1]-p[1]+dy;
  const d=Math.min(a+b-.00001,Math.max(Math.abs(a-b)+.00001,Math.hypot(x,y)));
  const bend=(rear?1:-1)*Math.acos(Math.max(-1,Math.min(1,(d*d-a*a-b*b)/(2*a*b))));
  const angle=Math.atan2(y,x)-Math.atan2(b*Math.sin(bend),a+b*Math.cos(bend));
  return [angle-a0,bend-(b0-a0)];
}
export function createMammal(kind) {
  if(!templates.has(kind)) templates.set(kind,prepare(kind));
  const data=templates.get(kind), root=data.create();
  const get=name=>root.getObjectByName(name);
  const neck=get("Neck"),head=get("Head"),tail=get("Tail"),ears=[get("Ear_L"),get("Ear_R")];
  const legs=data.legs.map((leg,i)=>[leg,get("Leg_"+i),get("Leg_"+i+"_shin")]);
  const isGrazer=["deer","stag","horse","cow","sheep"].includes(kind);
  return {root,...data,pose(phase,amount,fast,graze,t){
    const stride=data.length*mix(.19,.34,fast)*amount;
    const lift=data.shoulder*mix(.10,.23,fast)*amount;
    const stance=mix(.64,.43,fast);
    const offsets=data.rabbit?[.05,.09,.56,.59]:[0,mix(.50,.15,fast),mix(.72,.54,fast),mix(.22,.70,fast)];
    legs.forEach(([leg,upper,lower],i)=>{
      const cycle=(phase+offsets[i])%1;
      const swing=(cycle-stance)/(1-stance);
      const x=cycle<stance?mix(.5,-.5,cycle/stance):mix(-.5,.5,ease(0,1,swing));
      const y=cycle<stance?0:Math.sin(swing*Math.PI);
      const [hip,knee]=stepAngles(leg,x*stride,y*lift);
      upper.rotation.z=hip;
      lower.rotation.z=knee;
    });
    neck.rotation.z=-graze*(isGrazer?.83:.37)+Math.sin(phase*tau)*amount*.042+Math.sin(t*1.8)*.017;
    head.rotation.z=-graze*(isGrazer?.38:.24)+Math.sin(t*1.4)*.041;
    head.rotation.y=Math.sin(t*.89)*(.09+.034*(1-amount));
    tail.rotation.y=Math.sin(t*(kind==="dog"?6.3:3.6))*(kind==="dog"?.26:.15);
    tail.rotation.z=Math.sin(t*2.9)*.08;
    for(let i=0;i<2;i++) ears[i].rotation.x=Math.sin(t*2.2+i*2)*.08+Math.pow(Math.max(0,Math.sin(t*.79+i*1.6)),32)*.18;
    return data.rabbit?amount*lift*.63*Math.pow(Math.max(0,Math.sin((phase-.06)*tau)),1.5):0;
  }};
}
