// Render pipeline: [planar mirror] -> scene (pre-exposed linear HDR) -> AO + aerial perspective (fog lit by the real sky) -> depth of field
// -> [long-exposure accumulation] -> bloom (thresholdless, energy conserving) -> lens / AgX film curve / colour -> [FXAA] -> screen.
import * as THREE from "three";

const VERT = "varying vec2 vUv; void main(){ vUv = position.xy * 0.5 + 0.5; gl_Position = vec4(position.xy, 0.0, 1.0); }";
const tri = new THREE.BufferGeometry();
tri.setAttribute("position", new THREE.Float32BufferAttribute([-1, -1, 0, 3, -1, 0, -1, 3, 0], 3));
const quadCam = new THREE.Camera();
function pass(frag, uniforms, extra = {}) {
  const m = new THREE.ShaderMaterial({ vertexShader: VERT, fragmentShader: "precision highp float; varying vec2 vUv;\n" + frag, uniforms, depthTest: false, depthWrite: false, toneMapped: false, ...extra });
  const mesh = new THREE.Mesh(tri, m); mesh.frustumCulled = false;
  return { m, u: uniforms, mesh };
}
const rt = (w, h, o = {}) => new THREE.WebGLRenderTarget(Math.max(1, w | 0), Math.max(1, h | 0), { type: THREE.HalfFloatType, format: THREE.RGBAFormat, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: false, ...o });

const DEPTH = `uniform sampler2D tDepth; uniform float uNear, uFar;
float dist(vec2 uv){ float d = texture2D(tDepth, uv).x; return (uNear * uFar) / (uFar - d * (uFar - uNear)); }`;
// AgX (Troy Sobotka) with a mild "punchy" look: highlights roll off and desaturate towards white like film and real sensors, instead of clipping to flat neon colour
const AGX = `vec3 agxCurve(vec3 x){ vec3 x2 = x * x, x4 = x2 * x2; return 15.5 * x4 * x2 - 40.14 * x4 * x + 31.96 * x4 - 6.868 * x2 * x + 0.4298 * x2 + 0.1191 * x - 0.00232; }
vec3 agx(vec3 v){ const mat3 M = mat3(0.842479062253094, 0.0423282422610123, 0.0423756549057051, 0.0784335999999992, 0.878468636469772, 0.0784336, 0.0792237451477643, 0.0791661274605434, 0.879142973793104);
  const mat3 Mi = mat3(1.19687900512017, -0.0528968517574562, -0.0529716355144438, -0.0980208811401368, 1.15190312990417, -0.0980434501171241, -0.0990297440797205, -0.0989611768448433, 1.15107367264116);
  v = M * max(v, vec3(1e-10)); v = clamp(log2(v), -12.47393, 4.026069); v = (v + 12.47393) / 16.49999; v = clamp(agxCurve(v), 0.0, 1.0);
  float l = dot(v, vec3(0.2126, 0.7152, 0.0722)); v = pow(v, vec3(1.24)); float l2 = dot(v, vec3(0.2126, 0.7152, 0.0722)); v = l2 + 1.2 * (v - l2);
  v = Mi * max(v, 0.0); return clamp(v, 0.0, 1.0); }`;

export function createGfx(canvas, quality) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: "high-performance", alpha: false, stencil: false });
  renderer.toneMapping = THREE.NoToneMapping; renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap; renderer.autoClear = true;
  renderer.setClearColor(0x000000, 1);
  const G = { renderer, quality, w: 4, h: 4 };
  let scene = null, dofA, dofB, post, acc, capRT, ldrRT, bloomRT = [];
  const meter = new THREE.WebGLRenderTarget(64, 36, { type: THREE.FloatType, depthBuffer: false, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter });
  const afRT = new THREE.WebGLRenderTarget(1, 1, { type: THREE.FloatType, depthBuffer: false, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter });
  const meterBuf = new Float32Array(64 * 36 * 4), afBuf = new Float32Array(4), meterStage = new Float32Array(64 * 36 * 4), afStage = new Float32Array(4);
  // GPU -> CPU reads never stall the frame: pixels go into a pixel-pack buffer behind a fence and are copied out only once the GPU says
  // it is done (polled without blocking, no flush, no timers). A blocking read cost ~28 ms every third frame; three's async read still bunched frames.
  const gl = renderer.getContext();
  const reader = (target, w, h, dst) => { const pbo = gl.createBuffer(); gl.bindBuffer(gl.PIXEL_PACK_BUFFER, pbo); gl.bufferData(gl.PIXEL_PACK_BUFFER, dst.byteLength, gl.STREAM_READ); gl.bindBuffer(gl.PIXEL_PACK_BUFFER, null); let sync = null;
    return { issue() { if (sync) return; renderer.setRenderTarget(target); gl.bindBuffer(gl.PIXEL_PACK_BUFFER, pbo); gl.readPixels(0, 0, w, h, gl.RGBA, gl.FLOAT, 0); gl.bindBuffer(gl.PIXEL_PACK_BUFFER, null); sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0); },
      poll() { if (!sync || gl.getSyncParameter(sync, gl.SYNC_STATUS) !== gl.SIGNALED) return; gl.deleteSync(sync); sync = null; gl.bindBuffer(gl.PIXEL_PACK_BUFFER, pbo); gl.getBufferSubData(gl.PIXEL_PACK_BUFFER, 0, dst); gl.bindBuffer(gl.PIXEL_PACK_BUFFER, null); } }; };
  const rMeter = reader(meter, 64, 36, meterBuf), rAF = reader(afRT, 1, 1, afBuf);
  const readMeter = () => window.__noRead || rMeter.issue(), readAF = () => window.__noRead || rAF.issue();

  // half-res colour + signed circle of confusion (pixels, half-res units)
  const pCoc = pass(DEPTH + `uniform sampler2D tColor; uniform float uFocus, uF, uN, uPxPerMm, uMaxCoc;
    void main(){ float d = dist(vUv) * 1000.0, s = uFocus * 1000.0; float c = uF * uF * (d - s) / (uN * d * max(s - uF, 1.0)) * uPxPerMm * 0.5;
      gl_FragColor = vec4(texture2D(tColor, vUv).rgb, clamp(c, -uMaxCoc, uMaxCoc)); }`,
    { tColor: { value: null }, tDepth: { value: null }, uNear: { value: 0.1 }, uFar: { value: 1000 }, uFocus: { value: 5 }, uF: { value: 50 }, uN: { value: 2 }, uPxPerMm: { value: 30 }, uMaxCoc: { value: 18 } });
  // scatter-as-gather bokeh on a golden-angle spiral
  const pBlur = pass(`uniform sampler2D tCoc; uniform vec2 uPx; uniform float uMaxCoc, uStep, uBlades;
    void main(){ vec4 c0 = texture2D(tCoc, vUv); float cs = abs(c0.a); vec3 col = c0.rgb; float tot = 1.0, r = uStep;
      for (float a = 0.0; r < uMaxCoc; a += 2.39996323){ vec2 o = vec2(cos(a), sin(a));
        float poly = uBlades > 2.5 ? cos(3.14159 / uBlades) / cos(mod(a, 6.28318 / uBlades) - 3.14159 / uBlades) : 1.0;
        vec4 s = texture2D(tCoc, vUv + o * uPx * r * mix(1.0, poly, 0.6)); float ss = abs(s.a);
        if (s.a > c0.a) ss = clamp(ss, 0.0, cs * 2.0);
        float m = smoothstep(r - 0.5, r + 0.5, ss); col += mix(col / tot, s.rgb, m); tot += 1.0; r += uStep / r; }
      gl_FragColor = vec4(col / tot, c0.a); }`,
    { tCoc: { value: null }, uPx: { value: new THREE.Vector2() }, uMaxCoc: { value: 18 }, uStep: { value: 1.1 }, uBlades: { value: 0 } });
  const pDofMix = pass(`uniform sampler2D tColor, tBlur; void main(){ vec4 b = texture2D(tBlur, vUv); vec3 c = texture2D(tColor, vUv).rgb; gl_FragColor = vec4(mix(c, b.rgb, smoothstep(0.4, 1.6, abs(b.a))), 1.0); }`,
    { tColor: { value: null }, tBlur: { value: null } });
  const pCopy = pass(`uniform sampler2D tA; uniform float uK; void main(){ gl_FragColor = vec4(texture2D(tA, vUv).rgb * uK, 1.0); }`, { tA: { value: null }, uK: { value: 1 } });
  const pAdd = pass(`uniform sampler2D tA; uniform float uK; void main(){ gl_FragColor = vec4(texture2D(tA, vUv).rgb * uK, 1.0); }`, { tA: { value: null }, uK: { value: 1 } }, { blending: THREE.AdditiveBlending, transparent: true });
  // bloom chain: 13-tap downsample (Karis-weighted on the first level so single hot pixels cannot flicker), tent upsample
  const pDown = pass(`uniform sampler2D tA; uniform vec2 uPx; uniform float uKaris;
    vec3 S(vec2 o){ return min(texture2D(tA, vUv + o * uPx).rgb, vec3(6.0e4)); }
    float w(vec3 c){ return uKaris > 0.5 ? 1.0 / (1.0 + dot(c, vec3(0.2126, 0.7152, 0.0722))) : 1.0; }
    void main(){ vec3 a = S(vec2(-2, 2)), b = S(vec2(0, 2)), c = S(vec2(2, 2)), d = S(vec2(-2, 0)), e = S(vec2(0)), f = S(vec2(2, 0)), g = S(vec2(-2, -2)), h = S(vec2(0, -2)), i = S(vec2(2, -2)), j = S(vec2(-1, 1)), k = S(vec2(1, 1)), l = S(vec2(-1, -1)), m = S(vec2(1, -1));
      vec3 g0 = (j + k + l + m) * 0.25, g1 = (a + b + d + e) * 0.25, g2 = (b + c + e + f) * 0.25, g3 = (d + e + g + h) * 0.25, g4 = (e + f + h + i) * 0.25;
      float w0 = w(g0) * 0.5, w1 = w(g1) * 0.125, w2 = w(g2) * 0.125, w3 = w(g3) * 0.125, w4 = w(g4) * 0.125;
      gl_FragColor = vec4((g0 * w0 + g1 * w1 + g2 * w2 + g3 * w3 + g4 * w4) / (w0 + w1 + w2 + w3 + w4), 1.0); }`, { tA: { value: null }, uPx: { value: new THREE.Vector2() }, uKaris: { value: 0 } });
  const pUp = pass(`uniform sampler2D tA; uniform vec2 uPx; uniform float uK;
    void main(){ vec3 c = texture2D(tA, vUv).rgb * 4.0; c += (texture2D(tA, vUv + uPx * vec2(1, 0)).rgb + texture2D(tA, vUv - uPx * vec2(1, 0)).rgb + texture2D(tA, vUv + uPx * vec2(0, 1)).rgb + texture2D(tA, vUv - uPx * vec2(0, 1)).rgb) * 2.0;
      c += texture2D(tA, vUv + uPx).rgb + texture2D(tA, vUv - uPx).rgb + texture2D(tA, vUv + uPx * vec2(1, -1)).rgb + texture2D(tA, vUv + uPx * vec2(-1, 1)).rgb; gl_FragColor = vec4(c / 16.0 * uK, 1.0); }`,
    { tA: { value: null }, uPx: { value: new THREE.Vector2() }, uK: { value: 1 } }, { blending: THREE.AdditiveBlending, transparent: true });
  // lens + development: bloom/veiling glare, white balance, vignette, chromatic aberration, AgX film curve, picture style, grain
  const pFinal = pass(AGX + `uniform sampler2D tColor, tBloom; uniform vec3 uWB, uTint; uniform float uBloom, uVig, uCA, uGrain, uTime, uContrast, uSat, uMono, uFade, uAspect, uSplit; uniform vec4 uRect; uniform float uOutside, uGain;
    float hash(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
    void main(){ vec2 q = (vUv - uRect.xy) / uRect.zw; vec2 cc = q - 0.5; cc.x *= uAspect; float r2 = dot(cc, cc) / (0.25 * (uAspect * uAspect + 1.0));
      vec2 dir = (vUv - (uRect.xy + uRect.zw * 0.5)) * uCA * r2;
      vec3 c = vec3(texture2D(tColor, vUv + dir).r, texture2D(tColor, vUv).g, texture2D(tColor, vUv - dir).b);
      vec3 bl = texture2D(tBloom, vUv).rgb; bl *= vec3(1.06, 0.99, 0.93);
      c = mix(c, bl, uBloom); c *= uGain;
      float v = 1.0 / pow(1.0 + r2 * uVig, 2.0); c *= v; c *= uWB;
      c = agx(c * 1.3); // AgX output is already display-encoded
      float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
      c += uSplit * (vec3(-0.012, 0.004, 0.018) * (1.0 - l) * (1.0 - l) + vec3(0.016, 0.004, -0.014) * l * l);
      c = mix(vec3(l), c, uSat); c = (c - 0.5) * uContrast + 0.5; c = mix(c, c * 0.86 + 0.07, uFade); c *= uTint; c = mix(c, vec3(dot(c, vec3(0.3, 0.59, 0.11))), uMono);
      float g = (hash(gl_FragCoord.xy + fract(uTime) * 517.0) + hash(gl_FragCoord.yx * 1.3 + fract(uTime * 1.7) * 311.0) - 1.0);
      c += g * uGrain * (1.15 - l * 0.6);
      if (q.x < 0.0 || q.x > 1.0 || q.y < 0.0 || q.y > 1.0) c *= uOutside;
      gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0); }`,
    { tColor: { value: null }, tBloom: { value: null }, uWB: { value: new THREE.Vector3(1, 1, 1) }, uTint: { value: new THREE.Vector3(1, 1, 1) }, uBloom: { value: 0.05 }, uVig: { value: 0.3 }, uCA: { value: 0.002 }, uGrain: { value: 0.01 }, uTime: { value: 0 }, uContrast: { value: 1.0 }, uSat: { value: 1.0 }, uMono: { value: 0 }, uFade: { value: 0 }, uAspect: { value: 1.5 }, uSplit: { value: 1 }, uRect: { value: new THREE.Vector4(0, 0, 1, 1) }, uOutside: { value: 0.0 }, uGain: { value: 1 } });
  // FXAA 3.11-style edge smoothing on the developed image when no MSAA is used (the low preset)
  const pFXAA = pass(`uniform sampler2D tA; uniform vec2 uPx;
    float lu(vec3 c){ return dot(c, vec3(0.299, 0.587, 0.114)); }
    void main(){ vec3 cM = texture2D(tA, vUv).rgb; float lM = lu(cM), lN = lu(texture2D(tA, vUv + vec2(0, uPx.y)).rgb), lS = lu(texture2D(tA, vUv - vec2(0, uPx.y)).rgb), lE = lu(texture2D(tA, vUv + vec2(uPx.x, 0)).rgb), lW = lu(texture2D(tA, vUv - vec2(uPx.x, 0)).rgb);
      float mn = min(lM, min(min(lN, lS), min(lE, lW))), mx = max(lM, max(max(lN, lS), max(lE, lW))), rg = mx - mn; if (rg < max(0.04, mx * 0.12)) { gl_FragColor = vec4(cM, 1.0); return; }
      float lNW = lu(texture2D(tA, vUv + vec2(-uPx.x, uPx.y)).rgb), lNE = lu(texture2D(tA, vUv + uPx).rgb), lSW = lu(texture2D(tA, vUv - uPx).rgb), lSE = lu(texture2D(tA, vUv + vec2(uPx.x, -uPx.y)).rgb);
      vec2 d = vec2(-((lNW + lNE) - (lSW + lSE)), (lNW + lSW) - (lNE + lSE)); float red = max((lNW + lNE + lSW + lSE) * 0.03125, 0.0078125), rc = 1.0 / (min(abs(d.x), abs(d.y)) + red); d = clamp(d * rc, -8.0, 8.0) * uPx;
      vec3 a = 0.5 * (texture2D(tA, vUv - d * (1.0 / 6.0)).rgb + texture2D(tA, vUv + d * (1.0 / 6.0)).rgb), b = a * 0.5 + 0.25 * (texture2D(tA, vUv - d * 0.5).rgb + texture2D(tA, vUv + d * 0.5).rgb); float lb = lu(b);
      gl_FragColor = vec4((lb < mn || lb > mx) ? a : b, 1.0); }`, { tA: { value: null }, uPx: { value: new THREE.Vector2() } });
  const pMeter = pass(`uniform sampler2D tColor; uniform vec4 uRect; void main(){ gl_FragColor = vec4(texture2D(tColor, uRect.xy + vUv * uRect.zw).rgb, 1.0); }`, { tColor: { value: null }, uRect: { value: new THREE.Vector4(0, 0, 1, 1) } });
  const pAF = pass(DEPTH + `uniform vec2 uAt; void main(){ float m = 1e9; for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) m = min(m, dist(uAt + vec2(float(x), float(y)) * 0.006)); gl_FragColor = vec4(m, 0.0, 0.0, 1.0); }`,
    { tDepth: { value: null }, uNear: { value: 0.1 }, uFar: { value: 1000 }, uAt: { value: new THREE.Vector2(0.5, 0.5) } });

  // screen-space ambient occlusion from the depth buffer (half res), applied to the HDR colour before depth of field
  const pAO = pass(DEPTH + `uniform vec2 uTan, uPx; uniform float uR;
    vec3 vp(vec2 uv){ float z = dist(uv); return vec3((uv * 2.0 - 1.0) * uTan * z, -z); }
    void main(){ vec3 p = vp(vUv); float z = -p.z; if (z > uFar * 0.6) { gl_FragColor = vec4(1.0); return; }
      vec3 px = vp(vUv + vec2(uPx.x, 0.0)) - p, px2 = p - vp(vUv - vec2(uPx.x, 0.0)), py = vp(vUv + vec2(0.0, uPx.y)) - p, py2 = p - vp(vUv - vec2(0.0, uPx.y));
      vec3 n = normalize(cross(abs(px.z) < abs(px2.z) ? px : px2, abs(py.z) < abs(py2.z) ? py : py2));
      float R = uR * clamp(z * 0.35, 0.12, 1.0), sr = clamp(R / (z * 2.0 * uTan.y), 3.0 * uPx.y, 0.14), ang = 6.2832 * fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715)))), o = 0.0;
      for (int i = 0; i < 12; i++) { float fi = (float(i) + 0.5) / 12.0, a = ang + float(i) * 2.39996; vec2 d = vec2(cos(a), sin(a)) * sr * sqrt(fi) * vec2(uTan.y / uTan.x, 1.0); vec3 v = vp(vUv + d) - p; float l = length(v); o += max(0.0, dot(n, v) / (l + 1e-4) - 0.12) / (1.0 + 6.0 * l * l / (R * R)); }
      gl_FragColor = vec4(clamp(1.0 - o / 12.0 * 2.6, 0.0, 1.0)); }`, { tDepth: { value: null }, uNear: { value: 0.1 }, uFar: { value: 1000 }, uTan: { value: new THREE.Vector2(1, 1) }, uPx: { value: new THREE.Vector2() }, uR: { value: 0.7 } });
  // AO + aerial perspective. Extinction follows an exponential height profile; the in-scattered colour is the real sky in that direction
  // (a small cube of the sky shader), so distant hills and towers melt into the very sky behind them, plus forward-scattered sun / moon light.
  const pAtmo = pass(DEPTH + `uniform sampler2D tColor, tAO; uniform samplerCube tSky; uniform vec2 uPx, uTan; uniform float uK, uCamY, uDens, uHf, uGround, uSkyK, uOn, uIn, uBoxY; uniform vec4 uBox; uniform vec3 uCamP; uniform mat3 uRot; uniform vec3 uSunD, uSunC;
    void main(){ vec3 c = texture2D(tColor, vUv).rgb;
      if (uK > 0.0) { float a = 0.0; for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) a += texture2D(tAO, vUv + (vec2(float(x), float(y)) - 1.5) * uPx).x; a /= 16.0;
        float l = dot(c, vec3(0.2126, 0.7152, 0.0722)); a = mix(a, 1.0, smoothstep(1.2, 5.0, l)); c *= mix(1.0, a * (0.35 + 0.65 * a), uK); }
      float z = dist(vUv);
      if (uOn > 0.5 && z < uFar * 0.92) { vec3 vd = normalize(vec3((vUv * 2.0 - 1.0) * uTan, -1.0)), wd = normalize(uRot * vd); float d = min(z / max(-vd.z, 1e-3), 4000.0);
        if (uIn > 0.5) { /* inside a house: the room's own air is not lit by the sky, only the path after the ray leaves the walls counts */ float tx = wd.x > 0.0 ? (uBox.z - uCamP.x) / wd.x : (uBox.x - uCamP.x) / min(wd.x, -1e-5), tz = wd.z > 0.0 ? (uBox.w - uCamP.z) / wd.z : (uBox.y - uCamP.z) / min(wd.z, -1e-5), ty = wd.y > 0.0 ? (uBoxY - uCamP.y) / wd.y : 1e5; d = max(0.0, d - min(min(tx, tz), ty)); }
        float h0 = max(uCamY - uGround, 0.0) / uHf, dy = wd.y * d / uHf, k = abs(dy) > 1e-3 ? (1.0 - exp(-dy)) / dy : 1.0 - dy * 0.5;
        float od = uDens * exp(-h0) * d * k, T = exp(-od);
        vec3 fd = normalize(vec3(wd.x, max(wd.y, 0.015), wd.z)), fc = textureCube(tSky, fd).rgb * uSkyK;
        float mu = dot(wd, uSunD), ph = 0.12 / (12.566 * pow(max(1.36 - 1.2 * mu, 1e-3), 1.5)) + 0.0796;
        c = c * T + (fc + uSunC * ph) * (1.0 - T); }
      gl_FragColor = vec4(c, 1.0); }`, { tColor: { value: null }, tAO: { value: null }, tDepth: { value: null }, tSky: { value: null }, uNear: { value: 0.1 }, uFar: { value: 1000 }, uPx: { value: new THREE.Vector2() }, uTan: { value: new THREE.Vector2(1, 1) }, uK: { value: 1 }, uCamY: { value: 2 }, uDens: { value: 0.0004 }, uHf: { value: 150 }, uGround: { value: 0 }, uSkyK: { value: 1 }, uOn: { value: 0 }, uIn: { value: 0 }, uBoxY: { value: 0 }, uBox: { value: new THREE.Vector4() }, uCamP: { value: new THREE.Vector3() }, uRot: { value: new THREE.Matrix3() }, uSunD: { value: new THREE.Vector3(0, 1, 0) }, uSunC: { value: new THREE.Vector3() } });
  let aoRT = null, litRT = null;
  const draw = (p, target) => { renderer.setRenderTarget(target); renderer.render(p.mesh, quadCam); };

  // ---- planar mirror shared by every wet / water surface of a level (plane y = mirror.y). Rendered every frame at reduced resolution,
  // from the camera that is about to draw, so reflections never lag or jump; consumers sample it in world space through uMirrorMat.
  const mirror = { enabled: false, y: 0, rt: null, hide: [], cam: new THREE.PerspectiveCamera(), U: { tMirror: { value: null }, uMirrorMat: { value: new THREE.Matrix4() }, uMirrorY: { value: 0 } } };
  const mV = { n: new THREE.Vector3(0, 1, 0), p: new THREE.Vector3(), cp: new THREE.Vector3(), view: new THREE.Vector3(), target: new THREE.Vector3(), look: new THREE.Vector3(), rot: new THREE.Matrix4(), plane: new THREE.Plane(), clip: new THREE.Vector4(), q: new THREE.Vector4(), bias: new THREE.Matrix4().set(0.5, 0, 0, 0.5, 0, 0.5, 0, 0.5, 0, 0, 0.5, 0.5, 0, 0, 0, 1) };
  G.mirror = mirror;
  function renderMirror(sc, cam) {
    const V = mV, vc = mirror.cam; V.p.set(0, mirror.y, 0); V.cp.setFromMatrixPosition(cam.matrixWorld); if (V.cp.y < mirror.y + 0.02) return;
    V.view.subVectors(V.p, V.cp); V.view.y = V.p.y - V.cp.y; V.view.x = 0; V.view.z = 0; // reflect the camera position about the plane
    vc.position.set(V.cp.x, 2 * mirror.y - V.cp.y, V.cp.z);
    V.rot.extractRotation(cam.matrixWorld); V.look.set(0, 0, -1).applyMatrix4(V.rot).add(V.cp); V.target.copy(V.look); V.target.y = 2 * mirror.y - V.look.y;
    vc.up.set(0, 1, 0).applyMatrix4(V.rot); vc.up.y = -vc.up.y; vc.lookAt(V.target); vc.far = cam.far; vc.near = cam.near; vc.updateMatrixWorld(); vc.projectionMatrix.copy(cam.projectionMatrix); vc.matrixWorldInverse.copy(vc.matrixWorld).invert();
    mirror.U.uMirrorMat.value.copy(V.bias).multiply(vc.projectionMatrix).multiply(vc.matrixWorldInverse); mirror.U.uMirrorY.value = mirror.y;
    // oblique near plane = the mirror plane, so nothing under the water / street is drawn into the reflection
    V.plane.setFromNormalAndCoplanarPoint(V.n, V.p).applyMatrix4(vc.matrixWorldInverse); V.clip.set(V.plane.normal.x, V.plane.normal.y, V.plane.normal.z, V.plane.constant);
    const P = vc.projectionMatrix.elements; V.q.set((Math.sign(V.clip.x) + P[8]) / P[0], (Math.sign(V.clip.y) + P[9]) / P[5], -1, (1 + P[10]) / P[14]); V.clip.multiplyScalar(2 / V.clip.dot(V.q));
    P[2] = V.clip.x; P[6] = V.clip.y; P[10] = V.clip.z + 1 - 0.003; P[14] = V.clip.w;
    const hide = mirror.dyn ? mirror.hide.concat(mirror.dyn()) : mirror.hide; for (let i = 0; i < hide.length; i++) { const o = hide[i]; o.userData._mv = o.visible; o.visible = false; } /* far traffic and the like stay out of the reflection */
    renderer.setRenderTarget(mirror.rt); renderer.clear(); G._inMirror = true; try { renderer.render(sc, vc); } finally { G._inMirror = false; for (let i = 0; i < hide.length; i++) hide[i].visible = hide[i].userData._mv; }
  }

  G.resize = (w, h) => {
    const s = quality.scale; w = Math.round(w * s); h = Math.round(h * s); G.w = w; G.h = h;
    for (const t of [scene, dofA, dofB, post, acc, capRT, aoRT, litRT, ldrRT, mirror.rt, ...bloomRT]) t && t.dispose(); aoRT = rt(w / 2, h / 2); litRT = rt(w, h);
    scene = new THREE.WebGLRenderTarget(w, h, { type: THREE.HalfFloatType, samples: quality.msaa, depthBuffer: true, depthTexture: new THREE.DepthTexture(w, h, THREE.UnsignedIntType) });
    dofA = rt(w / 2, h / 2); dofB = rt(w / 2, h / 2); post = rt(w, h); acc = rt(w, h, { type: THREE.FloatType }); capRT = new THREE.WebGLRenderTarget(w, h, { depthBuffer: false }); ldrRT = new THREE.WebGLRenderTarget(w, h, { depthBuffer: false, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter });
    const ms = quality.mirror ?? 0.5; mirror.rt = new THREE.WebGLRenderTarget(Math.max(64, Math.round(w * ms)), Math.max(36, Math.round(h * ms)), { type: THREE.HalfFloatType, depthBuffer: true, generateMipmaps: true, minFilter: THREE.LinearMipmapLinearFilter, magFilter: THREE.LinearFilter }); mirror.U.tMirror.value = mirror.rt.texture;
    bloomRT = []; let bw = w / 2, bh = h / 2; for (let i = 0; i < 6; i++) { bloomRT.push(rt(bw, bh)); bw /= 2; bh /= 2; }
  };
  // L: lens state { dof, focus (m), f (mm), N, sensorH (mm), rect:[x,y,w,h] in 0..1, blades, ... } ; look: development params
  function sceneToPost(sc, cam, L) {
    const fog = sc.fog, fd = fog ? fog.density : 0;
    if (mirror.enabled && mirror.rt) renderMirror(sc, cam);
    if (fog && G.atmo && quality.haze !== 0) fog.density = 0; // aerial perspective is done in pAtmo for the main view
    renderer.setRenderTarget(scene); renderer.clear(); renderer.render(sc, cam); if (fog) fog.density = fd;
    const dt = scene.depthTexture;
    let colorTex = scene.texture;
    { const u = pAO.u, th = Math.tan((cam.fov * Math.PI) / 360); if (G.ao !== 0) { u.tDepth.value = dt; u.uNear.value = cam.near; u.uFar.value = cam.far; u.uTan.value.set(th * cam.aspect, th); u.uPx.value.set(2 / G.w, 2 / G.h); draw(pAO, aoRT); }
      const q = pAtmo.u, A = G.atmo; q.tColor.value = scene.texture; q.tAO.value = aoRT.texture; q.uPx.value.set(2 / G.w, 2 / G.h); q.uK.value = G.ao === 0 ? 0 : 1; q.tDepth.value = dt; q.uNear.value = cam.near; q.uFar.value = cam.far; q.uTan.value.set(th * cam.aspect, th); q.uRot.value.setFromMatrix4(cam.matrixWorld); q.uCamY.value = cam.position.y;
      if (A && A.sky && quality.haze !== 0) { q.uOn.value = 1; q.tSky.value = A.sky; q.uSkyK.value = A.skyK; q.uSunD.value.copy(A.dir); q.uSunC.value.fromArray(A.col); q.uDens.value = A.dens; q.uHf.value = A.hf; q.uGround.value = A.ground || 0; q.uCamP.value.copy(cam.position); const bx = A.box; q.uIn.value = bx ? 1 : 0; if (bx) { q.uBox.value.set(bx.x0, bx.z0, bx.x1, bx.z1); q.uBoxY.value = bx.y; } } else q.uOn.value = 0;
      if (q.uOn.value || q.uK.value) { draw(pAtmo, litRT); colorTex = litRT.texture; } }
    pAF.u.tDepth.value = dt; pAF.u.uNear.value = cam.near; pAF.u.uFar.value = cam.far; pAF.u.uAt.value.set(L.afx, L.afy);
    if (L.dof) {
      const u = pCoc.u; u.tColor.value = colorTex; u.tDepth.value = dt; u.uNear.value = cam.near; u.uFar.value = cam.far; u.uFocus.value = L.focus; u.uF.value = L.f; u.uN.value = L.N;
      u.uPxPerMm.value = (G.h * L.rect[3]) / L.sensorH; const mc = quality.maxCoc; u.uMaxCoc.value = mc;
      draw(pCoc, dofA);
      pBlur.u.tCoc.value = dofA.texture; pBlur.u.uPx.value.set(2 / G.w, 2 / G.h); pBlur.u.uMaxCoc.value = mc; pBlur.u.uStep.value = quality.dofStep; pBlur.u.uBlades.value = L.blades || 0;
      draw(pBlur, dofB);
      pDofMix.u.tColor.value = colorTex; pDofMix.u.tBlur.value = dofB.texture; draw(pDofMix, post);
    } else { pCopy.u.tA.value = colorTex; pCopy.u.uK.value = 1; draw(pCopy, post); }
    return post;
  }
  function develop(src, L, look, target) {
    pDown.u.tA.value = src.texture; pDown.u.uPx.value.set(1 / G.w, 1 / G.h); pDown.u.uKaris.value = 1; draw(pDown, bloomRT[0]);
    for (let i = 1; i < bloomRT.length; i++) { pDown.u.tA.value = bloomRT[i - 1].texture; pDown.u.uPx.value.set(1 / bloomRT[i - 1].width, 1 / bloomRT[i - 1].height); pDown.u.uKaris.value = 0; draw(pDown, bloomRT[i]); }
    renderer.autoClear = false;
    for (let i = bloomRT.length - 1; i > 0; i--) { pUp.u.tA.value = bloomRT[i].texture; pUp.u.uPx.value.set(1 / bloomRT[i].width, 1 / bloomRT[i].height); pUp.u.uK.value = 1; draw(pUp, bloomRT[i - 1]); }
    renderer.autoClear = true;
    const u = pFinal.u; u.tColor.value = src.texture; u.tBloom.value = bloomRT[0].texture; u.uWB.value.fromArray(look.wb); u.uTint.value.fromArray(look.tint); u.uBloom.value = Math.min(0.5, look.bloom); u.uVig.value = look.vig; u.uCA.value = look.ca;
    u.uGrain.value = look.grain; u.uTime.value = performance.now() / 1000; u.uContrast.value = look.contrast; u.uSat.value = look.sat; u.uMono.value = look.mono; u.uFade.value = look.fade; u.uSplit.value = look.split ?? 1;
    u.uGain.value = look.gain || 1; u.uRect.value.fromArray(L.rect); u.uAspect.value = (L.rect[2] * G.w) / (L.rect[3] * G.h); u.uOutside.value = L.outside;
    if (target === null && !quality.msaa) { draw(pFinal, ldrRT); pFXAA.u.tA.value = ldrRT.texture; pFXAA.u.uPx.value.set(1 / G.w, 1 / G.h); draw(pFXAA, null); }
    else draw(pFinal, target);
  }
  // bloom levels add up to ~6x the image; normalise so look.bloom is the fraction of light spread by the lens / wet air
  const _bl = { ...{} };
  let frame = 0;
  G.render = (sc, cam, L, look) => {
    rMeter.poll(); rAF.poll();
    const p = sceneToPost(sc, cam, L);
    if (frame++ % 2 === 0) {
      pMeter.u.tColor.value = p.texture; pMeter.u.uRect.value.fromArray(L.rect); draw(pMeter, meter); readMeter();
      if (afLock <= 0) { draw(pAF, afRT); readAF(); }
    }
    afLock--;
    develop(p, L, Object.assign(_bl, look, { bloom: look.bloom / 6 }), null);
  };
  G.meterBuf = meterBuf; G.afDist = () => afBuf[0];
  // long exposure: average N sub-frames in linear light
  G.accBegin = () => { renderer.setRenderTarget(acc); renderer.setClearColor(0x000000, 1); renderer.clear(); };
  G.accAdd = (sc, cam, L, k) => { const p = sceneToPost(sc, cam, L); pAdd.u.tA.value = p.texture; pAdd.u.uK.value = k; renderer.autoClear = false; draw(pAdd, acc); renderer.autoClear = true; };
  // develop to an 8-bit target and read the pixels back (photo capture). src: null = last post buffer, or the accumulation buffer
  G.capture = (L, look, fromAcc) => {
    const LL = Object.assign({}, L, { outside: 1 }); develop(fromAcc ? acc : post, LL, Object.assign({}, look, { bloom: look.bloom / 6 }), capRT);
    const x = Math.round(L.rect[0] * G.w), y = Math.round(L.rect[1] * G.h), w = Math.round(L.rect[2] * G.w), h = Math.round(L.rect[3] * G.h), buf = new Uint8Array(w * h * 4);
    renderer.readRenderTargetPixels(capRT, x, y, w, h, buf); renderer.setRenderTarget(null);
    return { w, h, buf };
  };
  G.showAcc = (L, look) => develop(acc, L, Object.assign({}, look, { bloom: look.bloom / 6 }), null);
  // small extra view through the lens for the camera's rear screen
  const lcdRT = new THREE.WebGLRenderTarget(640, 427, { type: THREE.HalfFloatType, depthBuffer: true }); G.lcdTex = lcdRT.texture;
  lcdRT.depthTexture = new THREE.DepthTexture(640, 427); let afLock = 0;
  G.lcd = (sc, cam, afx = 0.5, afy = 0.5) => { renderer.setRenderTarget(lcdRT); renderer.clear(); renderer.render(sc, cam); pAF.u.tDepth.value = lcdRT.depthTexture; pAF.u.uNear.value = cam.near; pAF.u.uFar.value = cam.far; pAF.u.uAt.value.set(afx, afy); draw(pAF, afRT); readAF(); afLock = 2; renderer.setRenderTarget(null); };
  return G;
}
