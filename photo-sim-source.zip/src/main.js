// Boot + main loop. Dev hooks: ?scene= ?time= ?weather= ?pos=x,y,z,yaw,pitch ?view=vf|lcd ?f= ?N= ?t= ?iso= ?mode= ?q= ?dt= , window.__ready / __errors / __G.
import * as THREE from "three";
import { createGfx } from "./gfx.js";
import { createSky, WEATHERS } from "./sky.js";
import { createTex } from "./tex.js";
import { createKit } from "./kit.js";
import { GEAR_COUNT, createCam, wbGain, STYLES, lensesFor } from "./camera.js";
import { createPlayer } from "./player.js";
import { createLife } from "./life.js";
import { createUI } from "./ui.js";
import { createAlbum } from "./album.js";
import { createHands } from "./hands.js";
import { createAudio } from "./audio.js";
import { createSceneAssets } from "./scene_assets.js";
import { clamp, damp, lerp, rng } from "./util.js";
import * as nature from "./scene_nature.js";
import * as city from "./scene_city.js";
import * as indoor from "./scene_indoor.js";
const agx1 = (v) => { let x = (Math.min(Math.max(Math.log2(Math.max(v * 1.3, 1e-10)), -12.47393), 4.026069) + 12.47393) / 16.5; const x2 = x * x, x4 = x2 * x2; x = 15.5 * x4 * x2 - 40.14 * x4 * x + 31.96 * x4 - 6.868 * x2 * x + 0.4298 * x2 + 0.1191 * x - 0.00232; return Math.min(1, Math.max(0, Math.pow(Math.max(x, 0), 1.24))); };

window.__ready = false; window.__errors = []; window.addEventListener("error", (e) => window.__errors.push(String(e.message)));
const _ce = console.error.bind(console); console.error = (...a) => { window.__errors.push(a.map((x) => (x && x.stack) || String(x)).join(" ").slice(0, 400)); _ce(...a); };
const Q = new URLSearchParams(location.search), qp = (k, d) => (Q.has(k) ? Q.get(k) : d);
// res = fraction of the device's own pixels; everything here can be changed live from the 画质 panel. Photos always render at the top settings.
// mirror = resolution of the shared planar reflection relative to the render (wet streets, harbour, lake)
const QUAL = { low: { res: 0.5, msaa: 0, maxCoc: 12, dofStep: 1.6, grass: 9000, trees: 200, refl: 256, mirror: 0.4, shadow: 1024, ao: 1, haze: 1, bloomK: 1, shadows: 1 }, medium: { res: 0.62, msaa: 2, maxCoc: 16, dofStep: 1.35, grass: 18000, trees: 300, refl: 512, mirror: 0.5, shadow: 2048, ao: 1, haze: 1, bloomK: 1, shadows: 1 },
  high: { res: 0.8, msaa: 2, maxCoc: 20, dofStep: 1.2, grass: 30000, trees: 400, refl: 512, mirror: 0.6, shadow: 2048, ao: 1, haze: 1, bloomK: 1, shadows: 1 }, ultra: { res: 1, msaa: 4, maxCoc: 30, dofStep: 1.0, grass: 60000, trees: 560, refl: 1024, mirror: 0.75, shadow: 4096, ao: 1, haze: 1, bloomK: 1, shadows: 1 } };
const SCENES = { nature, city, indoor }, SCENE_NAME = { nature: "自然风光", city: "城市", indoor: "室内" };

async function boot() {
  const canvas = document.getElementById("c"), bootEl = document.getElementById("boot"), bootMsg = document.getElementById("boot-msg"), say = async (s) => { bootMsg.textContent = s; await new Promise((r) => setTimeout(r, 0)); };
  const mobile = /Android|iPhone|iPad/i.test(navigator.userAgent); const dpr = Math.min(window.devicePixelRatio || 1, 2); let saved = {}; try { saved = JSON.parse(localStorage.getItem("psq4") || "{}"); } catch (e) {} const preset = qp("q", saved.preset || "low"); const quality = { ...(QUAL[preset] || QUAL.medium), ...(qp("q", null) ? {} : saved), preset, dpr }; if (qp("q", null) && !location.search.includes("dpr")) quality.dpr = 1; quality.scale = Math.max(0.6, quality.res * quality.dpr);
  const gfx = createGfx(canvas, quality), renderer = gfx.renderer; renderer.setPixelRatio(1); renderer.shadowMap.autoUpdate = false;
  const scene = new THREE.Scene(), camera = new THREE.PerspectiveCamera(60, 16 / 9, 0.05, 2400), lensCam = new THREE.PerspectiveCamera(30, 1.5, 0.08, 2400); camera.layers.enable(1); camera.layers.enable(2); lensCam.layers.enable(1); scene.add(camera);
  const G = { renderer, gfx, scene, camera, quality, params: Q, rnd: rng(+qp("seed", 2026)), m: 1, t: 0, recording: false, busy: false, eyeL: 0.5, raise: 0, timeFlow: 1, expo: null, SCENE_NAME };
  G.sceneAssets = createSceneAssets(renderer);
  window.__G = G;
  await say("正在冲洗贴图配方"); G.tex = createTex(renderer); G.kit = createKit(G.tex);
  await say("正在升起太阳和星空"); G.sky = createSky(scene, renderer); G.sky.sun.shadow.mapSize.set(quality.shadow, quality.shadow);
  G.cam = createCam(); const C = G.cam; C.want = "walk"; C.pref = "vf"; C.afx = 0.5; C.afy = 0.5; G.player = createPlayer(G); G.album = createAlbum(G); G.life = createLife(G); G.audio = createAudio(G); G.hands = createHands(G);
  const size = () => { const w = window.innerWidth, h = window.innerHeight, k = quality.scale; document.documentElement.style.setProperty("--u", Math.min(1.3, Math.max(0.72, Math.min(w, h) / 393)).toFixed(3)); renderer.setSize(Math.round(w * k), Math.round(h * k), false); gfx.resize(w, h); G.W = w; G.H = h; }; window.addEventListener("resize", size); window.addEventListener("orientationchange", () => { setTimeout(size, 250); setTimeout(size, 700); }); size();

  G.loadLevel = async (name) => {
    const wantVilla = name === "indoor"; if (wantVilla || !SCENES[name]) name = "nature"; bootEl.style.display = "flex"; bootEl.classList.remove("done"); await say("正在搭建场景：" + SCENE_NAME[name]); await new Promise((r) => setTimeout(r, 30));
    await G.sceneAssets.load(name === "city" ? ["airliner", "bicycle", "ferry", "junk", "barge"] : ["airliner", "lighthouse"]);
    if (G.level) { scene.remove(G.level.group); G.level.dispose?.(); G.level.group.traverse((o) => { if (o.geometry && !o.geometry.userData.sceneAsset) o.geometry.dispose(); }); }
    G.life.clear(); G.kit.reset(); G.kit.noPointShadows = quality.preset === "low"; /* point-light shadows are 6 renders each + 9 cube taps per pixel */ G.hands.rebuild(); const L = SCENES[name].build(G); L.id = name; G.level = L; scene.add(L.group); G.kit.poolInit(L.group, 8, 3); G.kit.poolUpdate(G.camera.position);
    for (const [g, , on] of L.groups || []) G.kit.setGroup(g, on);
    G.sky.rainBox = L.rainBox || null; G.sky.starBoost = L.starBoost || 1; gfx.mirror.enabled = !!L.mirror; gfx.mirror.y = L.mirror?.y ?? 0; gfx.mirror.hide = []; gfx.mirror.dyn = () => G.life.cars.filter((c) => c.e.obj.userData.far).map((c) => c.e.obj);
    // the reflection only needs what reads in a blurred mirror: lights, signs, façades, big shapes. Small unlit props stay out of it (half the draw calls).
    // small static meshes that are far away cost a draw call per pass for a few pixels: distance-cull them (big things and lights stay)
    { const sp = new THREE.Sphere(), seen = new Set(G.kit.cull.map((e) => e.m)); L.group.updateMatrixWorld(true); L.group.traverse((o) => { if (!o.isMesh || seen.has(o) || !o.geometry || o.userData.noCull) return; if (!o.geometry.boundingSphere) o.geometry.computeBoundingSphere(); sp.copy(o.geometry.boundingSphere).applyMatrix4(o.matrixWorld); if (sp.radius < 3 && !o.isInstancedMesh) G.kit.cull.push({ m: o, c: sp.center.clone(), r: sp.radius, d: 45 + sp.radius * 45 }); }); }
    const lowMirror = (quality.preset === "low");
    if (L.mirror) { const sp = new THREE.Sphere(); L.group.traverse((o) => { if (!(o.isMesh || o.isInstancedMesh) || o.layers.mask === 2 || !o.geometry) return; const m = Array.isArray(o.material) ? o.material[0] : o.material; if (m && (m.isMeshBasicMaterial || m.emissiveIntensity > 0 || (m.emissive && (m.emissive.r + m.emissive.g + m.emissive.b) > 0))) return; if (L.mirrorKeep?.(o)) return;
        if (o.isInstancedMesh) { if (L.mirrorHideInst ? L.mirrorHideInst(o) : lowMirror) gfx.mirror.hide.push(o); return; } if (!o.geometry.boundingSphere) o.geometry.computeBoundingSphere(); sp.copy(o.geometry.boundingSphere).applyMatrix4(o.matrixWorld); if (sp.radius < (lowMirror ? 6 : L.mirrorMinR ?? 2.5)) gfx.mirror.hide.push(o); }); } G.inside = null; G.sky.indoor = !!L.indoor; G.sky.pollution = L.pollution || 0; G.sky.shadowSize = L.shadowSize || 70; G.sky.reprobe();
    G.player.place(wantVilla && L.villaSpawn ? L.villaSpawn : L.spawn); if (L.startTime != null && qp("time", null) == null && !(G._started = G._started || {})[name]) { G._started[name] = 1; G.sky.time = L.startTime; } G.life.populate(L); G.ui?.onLevel?.(L); G.audio.setScene(name);
    bootEl.classList.add("done"); setTimeout(() => (bootEl.style.display = "none"), 600);
  };
  const lens = { dof: false, focus: 5, f: 35, N: 2.8, sensorH: 24, rect: [0, 0, 1, 1], afx: 0.5, afy: 0.5, blades: 9, outside: 0 }, look = { wb: [1, 1, 1], tint: [1, 1, 1], bloom: 0.02, vig: 0.3, ca: 0.0016, grain: 0.01, contrast: 1.16, sat: 1.12, mono: 0, fade: 0, gain: 1 };
  G.lens = lens; let meterL = 0.5, focusT = 5;
  function measure() { const b = gfx.meterBuf; let s = 0, w = 0; for (let y = 0; y < 36; y++) for (let x = 0; x < 64; x++) { const i = (y * 64 + x) * 4, l = 0.2126 * b[i] + 0.7152 * b[i + 1] + 0.0722 * b[i + 2], dx = (x - 31.5) / 32, dy = (y - 17.5) / 18, ww = 1 / (1 + 2.5 * (dx * dx + dy * dy)); if (l === l) { s += Math.min(l, 1.6) * ww; w += ww; } } return s / Math.max(w, 1e-6); }
  G.histogram = (bins) => { const b = gfx.meterBuf; bins.fill(0); const n = bins.length; for (let i = 0; i < b.length; i += 4) { let l = (0.2126 * b[i] + 0.7152 * b[i + 1] + 0.0722 * b[i + 2]) * 0.8; l = agx1(l * 1.0); bins[Math.min(n - 1, Math.max(0, Math.floor(l * n)))]++; } };
  function awbK() { const s = G.sky, L = G.level; let k = s.el > 12 ? 5500 : s.el > 0 ? lerp(4000, 5500, s.el / 12) : s.el > -8 ? lerp(8200, 4000, (s.el + 8) / 8) : L.nightK || 4300; if (s.w.clouds > 0.7 && s.el > 5) k = 6500; if (L.indoor) k = L.lampsOn?.() ? 3300 : k; else if (G.inside) k = lerp(k, 2900, 0.85); return lerp(k, 5500, 0.3); }
  const lensFov = (fr, hfrac) => (2 * Math.atan(fr.h / (2 * C.focal) / hfrac) * 180) / Math.PI;
  function setup(dt, forceVf) {
    const fr = C.frame(), W = G.W, H = G.H, sa = W / H;
    // raising the camera to the eye: the body comes up, the view darkens into the eyecup, then the finder image appears
    const target = C.want === "vf" ? 1 : 0; G.raise = clamp(G.raise + (Math.sign(target - G.raise) * dt) / 0.42, 0, 1); const was = C.vf; C.vf = G.raise >= 0.999 || !!forceVf; if (C.vf && !was) G.vfIn = 0.22; G.vfIn = Math.max(0, (G.vfIn || 0) - dt);
    if (C.vf) { const a = fr.a; let rw, rh; if (a > sa) { rw = 1; rh = sa / a; } else { rh = 1; rw = a / sa; } lens.rect = [(1 - rw) / 2, (1 - rh) / 2, rw, rh]; camera.fov = lensFov(fr, lens.rect[3]); lens.dof = C.dofPreview; lens.outside = 0; }
    else { lens.rect = [0, 0, 1, 1]; camera.fov = 62; lens.dof = false; lens.outside = 1; }
    camera.aspect = sa; camera.near = C.vf && C.focal > 150 ? 0.3 : 0.05; camera.updateProjectionMatrix();
    if (C.af) { const d = gfx.afDist(); if (d > 0 && d < 1e8 && (C.vf || C.want === "lcd")) focusT = clamp(d, C.lens.close, 5000); C.focus = Math.exp(damp(Math.log(C.focus), Math.log(focusT), 9, dt)); } C.focus = Math.max(C.focus, C.lens.close);
    lens.focus = C.focus; lens.f = C.focal; lens.N = C.N; lens.sensorH = fr.h; lens.blades = C.N > C.maxN() * 1.2 ? C.lens.blades : 0; lens.afx = lens.rect[0] + (C.vf ? C.afx : 0.5) * lens.rect[2]; lens.afy = lens.rect[1] + (C.vf ? C.afy : 0.5) * lens.rect[3];
    // exposure. The eye adapts on its own but has a floor: a moonless night stays dark. The camera only sees what its settings let in.
    if (!G.expo) { const a = measure(); if (a > 0) { const Ls = a / G.m; meterL = Math.exp(damp(Math.log(Math.max(meterL, 1e-12)), Math.log(Math.max(Ls, 1e-12)), 4, dt)); } }
    if (!G.expo && (C.vf || C.want === "lcd") && G.frame % 6 === 0) C.auto(meterL); else C.meterL = meterL;
    G.eyeL = Math.exp(damp(Math.log(G.eyeL), Math.log(Math.max(meterL, 1e-12)), 3, dt)); { const cd = Math.max(G.eyeL * 1000, 1e-4), key = clamp(0.52 + 0.16 * Math.log10(cd), 0.3, 1); G.eyeM = clamp((0.14 * key) / G.eyeL, 0.09, 2500); } /* the eye keeps a dark scene looking dark (lower key at night) */ G.camM = C.expFactor();
    G.m = C.vf ? G.camM : G.eyeM; if (!(G.m > 0) || !isFinite(G.m)) G.m = 1; if (!(G.eyeL > 0) || !isFinite(G.eyeL)) G.eyeL = 0.5; /* never let one bad frame poison the exposure for good */
    const K = C.wb === "auto" ? (C.awbK = awbK()) : C.wbK, st = STYLES[C.vf ? C.style : "std"]; look.wb = wbGain(K); look.tint = st.tint; look.contrast = st.contrast; look.sat = st.sat; look.mono = st.mono; look.fade = st.fade; look.gain = 1;
    look.grain = C.vf ? clamp(0.011 * Math.sqrt(C.iso / 100) * Math.sqrt(864 / (C.body.sw * C.body.sh)), 0.004, 0.2) : 0.005; look.vig = C.vf ? 0.12 + 0.55 * Math.pow(C.maxN() / C.N, 2) : 0.1; 
  }
  function world(dt) { G.t += dt; const L = G.level, S = G.sky; if (G.timeFlow) S.time = (S.time + (dt * G.timeFlow) / 3600) % 24; S.lightsKey = JSON.stringify(G.kit.groups); S.noProbe = !!G.expo;
    if ((G.frame | 0) % 6 === 0) G.kit.cullUpdate(camera.position); if ((G.frame | 0) % 4 === 0) G.kit.shadowTick(camera.position); if ((G.frame | 0) % 3 === 0) G.kit.poolUpdate(camera.position); renderer.shadowMap.needsUpdate = ((G._shf = (G._shf || 0) + 1) & 1) === 0 && (S.sun.intensity > 0.003 || G.kit.lights.some((e) => e.shadow && e.l.shadow.needsUpdate)); /* a moonlit night sun casts nothing worth a shadow pass */ { const E = S.sunE, k = 0.035 * G.m * clamp((S.el + 1) / 6, 0, 1) * (1 - S.w.clouds * 0.9); /* same air inside and out: the short distances indoors make the haze vanish by themselves */ const A = gfx.atmo = gfx.atmo || { dir: new THREE.Vector3(), col: [0, 0, 0], dens: 0.0004, hf: 160, ground: 0, sky: null, skyK: 1 }; A.dir.copy(S.lightDir); A.col = [E[0] * k, E[1] * k, E[2] * k]; A.dens = S.fogDens; A.hf = S.fogH; A.ground = L.fogGround || 0; A.box = G.inside && L.rainBox ? L.rainBox : null; A.sky = S.skyCube; A.skyK = G.m / Math.max(S.skyM, 1e-30);
      look.bloom = (0.045 + S.night * 0.025 + S.w.fog * 0.1 + S.w.rain * 0.05 + S.wet * 0.01) * (quality.bloomK ?? 1); } { const ins = L.inside ? L.inside(G.player.x, G.player.z) && G.player.y < 8 : !!L.indoor; if (ins !== G.inside) { G.inside = ins; S.indoor = ins; S.shadowSize = ins ? 24 : L.shadowSize || 70; S.reprobe(); } } G.kit.expose(G.m, S.night, G.t); G.kit.setWet(L.indoor ? 0 : S.wet); S.update(dt, camera.position, G.m, L.envScale || 1); if (!S.preProbe) { S.preProbe = () => { if (G.level.probeSkyOnly && !G.inside) G.kit.expose(G.m * 0.04, S.night, G.t); }; S.postProbe = () => { if (G.level.probeSkyOnly && !G.inside) G.kit.expose(G.m, S.night, G.t); }; } L.update?.(dt, G.t, G); G.life.update(dt, G.t); G.hands.update(dt); G.audio.update(dt); }
  const meta = (extra) => Object.assign({ body: C.body.brand + " " + C.body.name, lens: C.lens.name, focal: Math.round(C.focal), eq: Math.round(C.focal * C.crop()), N: C.N, t: C.shutterLabel(), iso: C.iso, ev: C.ev, mode: C.mode, wb: C.wb === "auto" ? "自动 " + Math.round(C.awbK) + "K" : C.wbK + "K", style: STYLES[C.style].name, scene: G.level.name, time: G.sky.time, weather: WEATHERS[G.sky.weather].name, focus: C.focus, tripod: C.tripod }, extra);
  const shake = new THREE.Euler(), sq = new THREE.Quaternion(); let shx = 0, shy = 0, svx = 0, svy = 0;
  const steady = () => (C.tripod ? 0 : 0.011 / Math.pow(2, Math.min(C.body.ibis, 6) * 0.75));
  // live graphics settings + the "always develop at full quality" switch used around every capture
  G.applyQ = (save = true) => { quality.scale = Math.max(0.5, quality.res * quality.dpr); gfx.ao = quality.ao ? 1 : 0; const sun = G.sky.sun; sun.castShadow = !!quality.shadows; if (sun.shadow.mapSize.x !== quality.shadow) { sun.shadow.mapSize.set(quality.shadow, quality.shadow); sun.shadow.map?.dispose(); sun.shadow.map = null; } size(); if (save) try { localStorage.setItem("psq4", JSON.stringify({ preset: quality.preset, res: quality.res, msaa: quality.msaa, mirror: quality.mirror, shadow: quality.shadow, shadows: quality.shadows, ao: quality.ao, haze: quality.haze, bloomK: quality.bloomK, grass: quality.grass, trees: quality.trees, refl: quality.refl })); } catch (e) {} };
  G.setPreset = (k) => { Object.assign(quality, QUAL[k], { preset: k }); G.applyQ(); }; G.QUAL = QUAL;
  let hqSave = null; const hqOn = () => { if (hqSave) return; hqSave = { res: quality.res, msaa: quality.msaa, ao: quality.ao, shadow: quality.shadow, shadows: quality.shadows, haze: quality.haze, maxCoc: quality.maxCoc, dofStep: quality.dofStep, mirror: quality.mirror }; Object.assign(quality, { res: Math.max(quality.res, Math.min(2.2, 2560 / (window.innerWidth * quality.dpr))), msaa: 4, ao: 1, shadow: 4096, shadows: 1, haze: 1, maxCoc: 30, dofStep: 1.0, mirror: 0.75 }); G.applyQ(false); renderer.shadowMap.needsUpdate = true; };
  const hqOff = () => { if (!hqSave) return; Object.assign(quality, hqSave); hqSave = null; G.applyQ(false); };
  // a camera turned on its side makes a portrait photo: rotate the developed pixels upright (and swap width / height)
  const uprightShot = (shot) => { const r = G.player.roll; if (Math.abs(r) < 0.78) return shot; const { w, h, buf } = shot, out = new Uint8Array(buf.length), cw = r > 0; /* rows are bottom-up (GL readback) */ for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const si = (y * w + x) * 4, nx = cw ? h - 1 - y : y, ny = cw ? x : w - 1 - x, di = (ny * h + nx) * 4; out[di] = buf[si]; out[di + 1] = buf[si + 1]; out[di + 2] = buf[si + 2]; out[di + 3] = buf[si + 3]; } return { w: h, h: w, buf: out }; };
  G.shoot = () => {
    if (G.busy || G.expo || !(C.vf || C.want === "lcd")) return; if (C.video) return G.toggleRec();
    const t = C.t, viaLcd = !C.vf; G.audio.shutter(t); G.ui?.shutter?.(t);
    if (viaLcd) { setup(0, true); world(0); }
    const tags = G.life.inFrame(camera, lens.rect);
    if (t >= 0.25) { hqOn(); G.expo = { t, el: 0, tags, viaLcd }; gfx.accBegin(); shx = shy = 0; svx = (Math.random() - 0.5) * steady(); svy = (Math.random() - 0.5) * steady(); return; }
    hqOn();
    let shot;
    if (t > 1 / 50) { const n = clamp(Math.ceil(t * 240), 3, 48), sub = t / n, s = steady(), bq = camera.quaternion.clone(); let rx = 0, ry = 0, vx = (Math.random() - 0.5) * s, vy = (Math.random() - 0.5) * s; gfx.accBegin();
      for (let i = 0; i < n; i++) { world(sub); vx += (Math.random() - 0.5) * s * 0.6; vy += (Math.random() - 0.5) * s * 0.6; rx += vx * sub; ry += vy * sub; camera.quaternion.copy(bq).multiply(sq.setFromEuler(shake.set(rx, ry, 0))); gfx.accAdd(scene, camera, lens, 1 / n); }
      camera.quaternion.copy(bq); shot = gfx.capture(lens, look, true);
    } else { gfx.render(scene, camera, lens, look); shot = gfx.capture(lens, look, false); }
    hqOff(); G.album.addPhoto(uprightShot(shot), meta({ tags }));
  };
  let rec = null;
  G.toggleRec = () => { if (rec) { rec.stop(); return; } const st = canvas.captureStream(60), mime = ["video/mp4;codecs=avc1", "video/webm;codecs=vp9", "video/webm"].find((m) => window.MediaRecorder && MediaRecorder.isTypeSupported(m)); if (!mime) return G.ui?.toast?.("这个浏览器不支持录像");
    const chunks = [], t0 = performance.now(); rec = new MediaRecorder(st, { mimeType: mime, videoBitsPerSecond: 16e6 }); rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
    rec.onstop = () => { G.album.addVideo(new Blob(chunks, { type: mime }), meta({ dur: (performance.now() - t0) / 1000 })); rec = null; G.recording = false; G.recT0 = 0; G.ui?.toast?.("视频已存入相册"); };
    rec.start(); G.recording = true; G.recT0 = performance.now(); if (C.want !== "vf") C.want = "vf"; };
  G.ui = createUI(G);
  G.sky.time = +qp("time", 14); G.sky.setWeather(qp("weather", "partly")); G.sky.ground = qp("ground", "puddle"); G.sky.wet = G.sky.ground === "dry" ? 0 : G.sky.ground === "damp" ? 0.5 : 1; if (!WEATHERS[G.sky.weather]) G.sky.setWeather("clear"); Object.assign(G.sky.w, WEATHERS[G.sky.weather]);
  await G.loadLevel(qp("scene", "nature"));
  G.applyQ(false);
  { const menu = document.getElementById("menu"), go = document.getElementById("go"); document.getElementById("gear").textContent = `${GEAR_COUNT.bodies} 款机身 · ${GEAR_COUNT.lenses} 支镜头`; if (!location.search) { menu.style.display = "flex"; G.player.enabled = false; G.menu = true; go.onclick = () => { if (document.body.classList.contains("touch")) try { document.documentElement.requestFullscreen?.().catch(() => {}); } catch (e) {} menu.classList.add("done"); setTimeout(() => (menu.style.display = "none"), 500); G.player.enabled = true; G.menu = false; if (!G.player.touch) canvas.requestPointerLock?.(); }; } }
  if (Q.has("pos")) { const p = Q.get("pos").split(",").map(Number); G.player.place({ x: p[0], y: p[1], z: p[2], yaw: p[3] || 0, pitch: p[4] || 0, fly: true }); }
  if (Q.has("body")) C.setBody(Q.get("body")); if (Q.has("lens")) { const l = lensesFor(C.body)[+Q.get("lens")]; if (l) C.setLens(l); } if (Q.has("f")) C.focal = clamp(+Q.get("f"), C.lens.f0, C.lens.f1);
  if (Q.has("mode")) C.mode = Q.get("mode"); if (Q.has("N")) C.N = +Q.get("N"); if (Q.has("t")) C.t = +Q.get("t"); if (Q.has("iso")) { C.iso = +Q.get("iso"); C.autoISO = false; } if (Q.has("vf")) C.want = "vf"; if (Q.has("view")) C.want = Q.get("view"); if (C.want === "vf") G.raise = 1; if (Q.has("tripod")) C.tripod = true; if (Q.has("style")) C.style = Q.get("style"); if (Q.has("focus")) { C.af = false; C.focus = +Q.get("focus"); } if (Q.has("flow")) G.timeFlow = +Q.get("flow");
  G.frame = 0; let last = performance.now(); const fixed = Q.has("dt") ? +Q.get("dt") : 0;
  function frame(dt) {
    G.frame++; G.player.update(dt);
    const E = G.expo; setup(dt, E && E.viaLcd); world(dt);
    if (E) { // accumulate this frame's light in proportion to the time it lasted; hands shake unless on a tripod
      const use = Math.min(dt, E.t - E.el), s = steady(); svx += (Math.random() - 0.5) * s * 0.6; svy += (Math.random() - 0.5) * s * 0.6; shx += svx * dt; shy += svy * dt; if (s) camera.quaternion.multiply(sq.setFromEuler(shake.set(shx, shy, 0)));
      gfx.accAdd(scene, camera, lens, use / E.t); E.el += use; look.gain = 1; gfx.showAcc(lens, look); look.gain = 1; G.ui.exposing(E.el / E.t, E.t);
      if (E.el >= E.t - 1e-6) { const shot = gfx.capture(lens, look, true); hqOff(); G.album.addPhoto(uprightShot(shot), meta({ tags: E.tags })); G.expo = null; G.audio.shutterClose(); G.ui.exposing(1, E.t); }
    } else {
      if (C.want === "lcd" && !C.vf) { const fr = C.frame(); lensCam.position.copy(camera.position); lensCam.quaternion.copy(camera.quaternion); lensCam.fov = lensFov(fr, 1); lensCam.aspect = fr.a; lensCam.updateProjectionMatrix(); gfx.lcd(scene, lensCam, C.afx ?? 0.5, C.afy ?? 0.5); G.hands.lcdGain(G.camM / G.m); }
      gfx.render(scene, camera, lens, look);
    }
    G.ui.update(dt, lens);
  }
  function loop() { requestAnimationFrame(loop); const now = performance.now(), dt = fixed || Math.min(0.05, (now - last) / 1000); last = now; if (G.busy) return;
    try { frame(dt); } catch (e) { if (!G._err) { G._err = 1; console.error("[loop] " + ((e && e.stack) || e)); } } if (G.frame === 14) window.__ready = true; }
  loop();
}
boot().catch((e) => { console.error("[fatal] " + ((e && e.stack) || e)); document.getElementById("boot-msg").textContent = "启动失败：" + e; window.__fatal = String(e); });
