// First-person movement (walk / crouch / run / drone flight), mouse look scaled by focal length, simple collisions, and scripted camera moves for video.
import { clamp, damp } from "./util.js";
export const MOVES = { push: "推进", pull: "拉远", left: "左移", right: "右移", up: "上升", down: "下降", orbit: "环绕", pan: "摇镜" };
export function createPlayer(G) {
  const canvas = G.renderer.domElement, keys = new Set();
  const P = { x: 0, y: 0, z: 0, yaw: 0, pitch: 0, roll: 0, eye: 1.62, eyeT: 1.62, vx: 0, vy: 0, vz: 0, fly: false, locked: false, onGround: true, move: null, moveSpeed: 0.6, smooth: 0, bob: 0, keys, dx: 0, dy: 0, wheel: 0, enabled: true, sens: 1, joy: { x: 0, y: 0 }, touch: false };
  { let id = null, lx = 0, ly = 0; canvas.addEventListener("touchstart", (e) => { e.preventDefault(); if (!P.touch) { P.touch = true; P.locked = true; G.ui?.onLock?.(true); } if (id === null) { const t = e.changedTouches[0]; id = t.identifier; lx = t.clientX; ly = t.clientY; } }, { passive: false });
    canvas.addEventListener("touchmove", (e) => { e.preventDefault(); for (const t of e.changedTouches) if (t.identifier === id) { P.dx += (t.clientX - lx) * 2.2; P.dy += (t.clientY - ly) * 2.2; lx = t.clientX; ly = t.clientY; } }, { passive: false }); const end = (e) => { for (const t of e.changedTouches) if (t.identifier === id) id = null; }; canvas.addEventListener("touchend", end); canvas.addEventListener("touchcancel", end); }
  canvas.addEventListener("click", () => { if (!P.locked && P.enabled && !G.ui?.modal) canvas.requestPointerLock?.(); });
  document.addEventListener("pointerlockchange", () => { P.locked = document.pointerLockElement === canvas; if (!P.locked) keys.clear(); G.ui?.onLock?.(P.locked); });
  document.addEventListener("mousemove", (e) => { if (P.locked) { P.dx += e.movementX; P.dy += e.movementY; } });
  document.addEventListener("keydown", (e) => { if (e.target.tagName === "INPUT" || e.target.tagName === "SELECT") return; keys.add(e.code); if (["Tab", "Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault(); G.onKey?.(e.code, e); });
  document.addEventListener("keyup", (e) => keys.delete(e.code));
  window.addEventListener("blur", () => keys.clear());
  canvas.addEventListener("wheel", (e) => { e.preventDefault(); P.wheel += Math.sign(e.deltaY); G.onWheel?.(Math.sign(e.deltaY), e); }, { passive: false });
  canvas.addEventListener("mousedown", (e) => { if (P.locked) G.onMouse?.(e.button, true); });
  document.addEventListener("mouseup", (e) => G.onMouse?.(e.button, false));
  canvas.addEventListener("contextmenu", (e) => e.preventDefault());
  P.place = (s) => { P.x = s.x; P.z = s.z; P.yaw = s.yaw || 0; P.pitch = s.pitch || 0; P.roll = 0; P.y = s.y != null ? s.y : ground(P.x, P.z, 1e9); P.vx = P.vy = P.vz = 0; P.fly = !!s.fly; P.move = null; };
  function ground(x, z, feet) { const L = G.level; let g = L.groundAt(x, z); if (L.water != null) g = Math.max(g, L.water - 0.75); for (const f of L.floors) if (x > f.x0 && x < f.x1 && z > f.z0 && z < f.z1 && f.y <= feet + 0.55 && f.y > g) g = f.y; for (const r of L.ramps || []) if (x > r.x0 && x < r.x1 && z > r.z0 && z < r.z1) { const u = Math.min(1, Math.max(0, ((r.axis === "x" ? x : z) - r.a0) / (r.a1 - r.a0))), y = r.y0 + (r.y1 - r.y0) * u; if (y <= feet + 0.55 && y > g) g = y; } return g; } // stairs are walked as ramps
  function collide(nx, nz, y) { const L = G.level, R = 0.32;
    for (const c of L.colliders) { if (y + 1.6 < c.y0 || y + 0.35 > c.y1) continue; const qx = clamp(nx, c.x0, c.x1), qz = clamp(nz, c.z0, c.z1), dx = nx - qx, dz = nz - qz, d = Math.hypot(dx, dz);
      if (d < R) { if (d > 1e-5) { nx = qx + (dx / d) * R; nz = qz + (dz / d) * R; } else { const l = nx - c.x0, r = c.x1 - nx, t = nz - c.z0, b = c.z1 - nz, m = Math.min(l, r, t, b); if (m === l) nx = c.x0 - R; else if (m === r) nx = c.x1 + R; else if (m === t) nz = c.z0 - R; else nz = c.z1 + R; } } }
    for (const c of L.circles) { if (c.y1 != null && y > c.y1) continue; const dx = nx - c.x, dz = nz - c.z, d = Math.hypot(dx, dz), rr = c.r + R; if (d < rr && d > 1e-5) { nx = c.x + (dx / d) * rr; nz = c.z + (dz / d) * rr; } }
    for (const v of G.life?.cars || []) { if (y > v.h) continue; const dx = nx - v.e.x, dz = nz - v.e.z, c = Math.cos(v.e.yaw), sn = Math.sin(v.e.yaw), lx = dx * c - dz * sn, lz = dx * sn + dz * c, ex = v.hl + R, ez = v.hw + R;
      if (Math.abs(lx) < ex && Math.abs(lz) < ez) { const px = ex - Math.abs(lx), pz = ez - Math.abs(lz); let qx = lx, qz = lz; if (px < pz) qx = Math.sign(lx || 1) * ex; else qz = Math.sign(lz || 1) * ez; nx = v.e.x + qx * c + qz * sn; nz = v.e.z - qx * sn + qz * c; } }
    const b = L.bounds; if (b) { if (typeof b === "number") { const d = Math.hypot(nx, nz); if (d > b) { nx *= b / d; nz *= b / d; } } else { nx = clamp(nx, b.x0, b.x1); nz = clamp(nz, b.z0, b.z1); } }
    return [nx, nz]; }
  P.update = (dt) => { if (!P.enabled) { P.dx = P.dy = 0; keys.clear(); }
    const fovK = G.camera.fov / 62; P.yaw -= P.dx * 0.0022 * fovK * P.sens; P.pitch = clamp(P.pitch - P.dy * 0.0022 * fovK * P.sens, -1.5, 1.5); P.dx = P.dy = 0;
    const k = (c) => (keys.has(c) ? 1 : 0); let f = k("KeyW") - k("KeyS") - P.joy.y, s = k("KeyD") - k("KeyA") + P.joy.x, up = k("Space") - (k("ControlLeft") || k("KeyC") && P.fly ? 1 : 0);
    if (P.rollT != null) { P.roll = damp(P.roll, P.rollT, 9, dt); if (Math.abs(P.roll - P.rollT) < 0.002) { P.roll = P.rollT; P.rollT = null; } } if (k("KeyE") && k("KeyQ")) P.rollT = 0; else if (k("KeyE") || k("KeyQ")) P.rollT = null; if (P.rollT == null) P.roll = clamp(P.roll + (k("KeyE") - k("KeyQ")) * dt * 0.8, -1.6, 1.6); /* Q/E tilt freely up to a full vertical frame */
    const run = keys.has("ShiftLeft"), slow = keys.has("AltLeft") || G.recording || !!G.expo, sy = Math.sin(P.yaw), cy = Math.cos(P.yaw);
    let sp = P.fly ? (run ? 14 : slow ? 1.2 : 5) : run ? 5.2 : slow ? 0.9 : P.eyeT < 1 ? 1.2 : 2.4;
    let tx = (-sy * f + cy * s) * sp, tz = (-cy * f - sy * s) * sp, ty = up * sp * 0.8;
    if (P.move) { const v = P.moveSpeed, m = P.move.type; if (f || s) P.move = null; else { tx = tz = ty = 0; const fx = -sy * Math.cos(P.pitch), fz = -cy * Math.cos(P.pitch), fy = Math.sin(P.pitch);
        if (m === "push") { tx = fx * v; ty = fy * v; tz = fz * v; } if (m === "pull") { tx = -fx * v; ty = -fy * v; tz = -fz * v; } if (m === "left") { tx = -cy * v; tz = sy * v; } if (m === "right") { tx = cy * v; tz = -sy * v; } if (m === "up") ty = v; if (m === "down") ty = -v;
        if (m === "pan") P.yaw += v * 0.12 * dt; if (m === "orbit") { const d = clamp(G.cam.focus, 1.5, 60), w = v / d; tx = cy * v; tz = -sy * v; P.yaw -= w * dt; } } }
    const acc = P.move ? 2.5 : G.recording ? 2.2 : P.fly ? 5 : 12; P.vx = damp(P.vx, tx, acc, dt); P.vz = damp(P.vz, tz, acc, dt);
    let nx = P.x + P.vx * dt, nz = P.z + P.vz * dt; [nx, nz] = collide(nx, nz, P.y); P.x = nx; P.z = nz;
    const g = ground(P.x, P.z, P.y);
    if (P.fly || P.move) { P.vy = damp(P.vy, ty, acc, dt); P.y = clamp(P.y + P.vy * dt, g, g + 120); P.onGround = false; if (!P.fly && !P.move) P.vy = 0; }
    else { if (P.y > g + 0.02) { P.vy -= 16 * dt; P.y = Math.max(g, P.y + P.vy * dt); if (P.y === g) P.vy = 0; } else { P.y = damp(P.y, g, 18, dt); P.vy = 0; if (keys.has("Space")) P.vy = 6.5, (P.y += 0.03); } }
    P.eye = damp(P.eye, P.fly || P.move ? 0.2 : P.eyeT, 10, dt);
    const spd = Math.hypot(P.vx, P.vz); P.speed = spd; P.bob += spd * dt * 2.1; const bobAmt = P.fly || P.move || G.cam.tripod ? 0 : Math.min(spd, 3) * (G.cam.vf ? 0.004 : 0.012);
    const c = G.camera; c.position.set(P.x, P.y + P.eye + Math.sin(P.bob * 2) * bobAmt, P.z); c.rotation.order = "YXZ"; c.rotation.set(P.pitch, P.yaw, P.roll);
  };
  P.crouch = () => { P.eyeT = P.eyeT > 1.5 ? 0.85 : P.eyeT > 0.5 ? 0.28 : 1.62; };
  P.prone = () => { P.eyeT = P.eyeT < 0.5 ? 1.62 : 0.34; }; // lie on your belly: lens at the height of a sitting cat's eyes
  P.portrait = () => { P.rollT = Math.abs(P.roll) > 0.78 ? 0 : -Math.PI / 2; };
  return P;
}
