import { ball, buildAnimal, ease, grain, mix, tones, transition } from "./wildlife_mesh.js";

export const flockSpecies = {
  // Label, unit in metres, speed, wingbeat frequency.
  sparrow: ["麻雀",.071,9,12],
  gull: ["海鸥",.205,8,3.7],
  crow: ["乌鸦",.162,8,4.4],
  eagle: ["老鹰",.43,11,1.8],
  pigeon: ["鸽子",.116,8,6.2],
  bat: ["蝙蝠",.105,9,9.3],
  swallow: ["燕子",.086,8,7.5],
};
const shapes = {
  // Chest depth, head radius, half-span, breadth, wrist sweep, tail length, beak length.
  sparrow: [.43,.355,1.84,.70,.18,.79,.20],
  gull: [.35,.27,2.74,.65,.28,.61,.34],
  crow: [.38,.34,2.58,.88,.25,.84,.40],
  eagle: [.38,.30,2.92,1.07,.12,.73,.31],
  pigeon: [.51,.315,2.29,.87,.24,.75,.22],
  bat: [.32,.28,2.49,.91,.08,.64,.08],
  swallow: [.34,.29,2.48,.51,.39,1.24,.13],
};
const colors = {
  // Back, breast, face, bill, coverts, flight feathers, tail, feet.
  sparrow: [0x78513b,0xc8b397,0x795444,0x3a302b,0x88654b,0x4e3e34,0x5e493a,0x956b5c],
  gull: [0xe6e2d9,0xf2efe8,0xf5f0e7,0xd7a22d,0x9da7ad,0x39414a,0xe5e4df,0xbd947e],
  crow: [0x282831,0x24232b,0x21242c,0x262329,0x35343f,0x24252f,0x22242b,0x3d3540],
  eagle: [0x5d4230,0x483425,0x9b7448,0xc39b44,0x624b34,0x302923,0x47382d,0xb4975a],
  pigeon: [0x777d87,0xa3a1a3,0x686f7a,0x39363c,0x8e97a3,0x535461,0x54515c,0xa45f65],
  bat: [0x503b35,0x776253,0x4b3732,0x38292a,0x66504d,0x3c2c32,0x4b3538,0x35282a],
  swallow: [0x34495f,0xe4d9c6,0x354158,0x29252d,0x35475a,0x2b3548,0x293248,0x5e545c],
};
const flying = new Map(), waterfowl = new Map();

function flightTemplate(kind) {
  const A=buildAnimal(), body=A.joint("Body"), head=A.joint("Head",[.55,.19,0],body);
  const tail=A.joint("Tail",[-.72,.04,0],body);
  const [depth,H,span,chord,sweep,tailLen,bill]=shapes[kind];
  const bat=kind==="bat", pigeon=kind==="pigeon", eagle=kind==="eagle", gull=kind==="gull", swallow=kind==="swallow";
  const paint=tones(...colors[kind],0xf1e6d0,0x241c1c,0xa36249,0x345b53,0x655071);
  const tiny=(x,y,z)=>grain(x,y,z,.12)*.06;
  A.volume([
    ball(-.28,-.015,0,.70,depth*.72,depth*.81,-.11),
    ball(.33,-.025,0,.49,depth*.79,depth*.82,.25),
    ball(.62,.20,0,.33,H*.87,H*.85,.61),
    ball(.83,.33,0,H*.99,H*.89,H*.83),
  ],(x,y,z,ny)=>{
    const breast=ease(-.13,.68,-ny);
    if(pigeon && x>.43 && x<.73 && y>-.23) return paint(11,12,ease(.01,.26,y),.75+tiny(x,y,z));
    if(swallow && x>.72 && y<.32) return paint(10,2,ease(.11,.32,y),1+tiny(x,y,z));
    if(kind==="sparrow" && x>.68 && y<.37 && Math.abs(z)>.10) return paint(8,9,(1-ease(.56,.70,x))*.2+(1-ease(.21,.34,y))*.73,1+tiny(x,y,z));
    return x>.75?paint(2,1,breast*.39,1+tiny(x,y,z)):paint(0,1,breast,1+tiny(x,y,z));
  },(x)=>transition(body,head,ease(.43,.84,x)),{blend:.15,material:"plumage",resolution:39});
  const hx=.88+H*.77,hy=.285;
  const beakColor=paint(3);
  if(bat) {
    A.oval([hx-.09,hy-.08,0],[.16,.11,.15],beakColor,head,"eye");
    for(const s of [-1,1]){
      A.tube([[.69,.45,s*.15,.119,.058],[.65,.65,s*.24,.124,.048],[.68,.82,s*.30,.012,.016]],paint(2),head,"plumage",{up:[1,0,0]});
      A.oval([.737,.65,s*.24],[.039,.12,.083],paint(10,2,.64),head,"plumage",.16);
    }
  } else {
    const q=eagle?.156:kind==="crow"?.12:gull?.096:.074;
    A.tube([[hx-.13,hy,0,q*1.06,q*.75],[hx+bill*.42,hy-.017,0,q*.73,q*.47],
      [hx+bill*(eagle?.76:.83),hy-(eagle?.18:.043),0,.017,.022]],paint(3),head,"scale",{seg:14,capK:.66});
    A.tube([[hx-.11,hy-q*.53,0,q*.86,q*.32],[hx+bill*.55,hy-q*.55,0,q*.54,q*.20],
      [hx+bill*.81,hy-(eagle?.11:.06),0,.014,.01]],paint(3,9,.21),head,"scale",{seg:10});
    if(gull) A.oval([hx+bill*.51,hy-.064,0],[.037,.035,.053],0xa45b3d,head,"scale");
    if(pigeon) A.oval([hx-.098,hy+.026,0],[.087,.047,.075],0xbfb8af,head,"scale");
  }
  for(const s of [-1,1]){
    const size=H*(bat?.22:eagle?.24:pigeon?.245:.192), x=.88+H*.29, y=.355+H*.09, z=s*H*.724;
    A.oval([x,y,z],[size*1.14,size*.91,size*.59],eagle?0xac8045:pigeon?0xa45c3c:0x584c40,head,"eye");
    A.oval([x+size*.13,y,z+s*size*.41],[size*.68,size*.68,size*.25],0x171619,head,"eye");
  }
  if (!bat) for(let i=-4;i<=4;i++){
    const t=i/4, edge=Math.abs(t), L=swallow?tailLen*mix(.36,1,edge**2):tailLen*mix(1,.72,edge);
    A.vane([-.65,.037,t*.13],[-.79-L,.005,t*(swallow?.28:.38)],swallow?.14:.205,.018,
      (x,y,z)=>paint(6,8,swallow&&x< -1.1&&x> -1.33&&edge<.80?.42:0,1+tiny(x,y,z)),tail);
  }

  const wingBones=[];
  for(const s of [-1,1]){
    const shoulderAt=[.28,.075,s*.22];
    const wristAt=[.14-sweep,.12,s*span*.54];
    const wing=A.joint(s>0?"Wing_L":"Wing_R",shoulderAt,body);
    const wrist=A.joint(s>0?"Wrist_L":"Wrist_R",wristAt,wing);
    wingBones.push([wing,wrist]);
    const wingWeights=(x,y,z)=>transition(wing,wrist,ease(span*.39,span*.69,Math.abs(z)));
    if(bat) {
      const outer=[[.32,.08,.24],[.26,.11,span*.42],[.14,.14,span*.56],[-.24,.055,span],
        [-.80,-.01,span*.83],[-1.03,-.027,span*.58],[-.88,-.04,span*.26],[-1.14,-.03,.035]];
      const anchor=[.11,.08,s*.51];
      for(let i=0;i<outer.length-1;i++){
        const a=outer[i],b=outer[i+1];
        const mid=a.map((x,k)=>mix(x,b[k],.5));
        if(i>=3) mid[0]+=.18;
        const rail=[a,mid,b].map(([x,y,z])=>[x,y,s*z]);
        const rows=[.04,.36,.68,1].map(t=>rail.map(p=>p.map((x,k)=>mix(anchor[k],x,t)+(k===1?Math.sin(t*Math.PI)*.12:0))));
        A.sheet(rows,(x,y,z)=>paint(4,5,ease(.17,-.86,x)*.76,1+tiny(x,y,z)),wingWeights);
      }
      for(let i=3;i<outer.length;i++){
        const [x,y,z]=outer[i];
        A.tube([[...wristAt,.027],[mix(wristAt[0],x,.53),.109,s*mix(span*.54,z,.53),.022],
          [x,y,s*z,.008]],paint(4,5,.52),wingWeights,"plumage",{seg:6,sub:3});
      }
      continue;
    }
    const wingPaint=(x,y,z)=>{
      const u=Math.abs(z)/span;
      if(gull) return paint(4,5,ease(.66,.91,u),.94+tiny(x,y,z));
      if(pigeon) {
        const bar=Math.max(1-ease(.04,.13,Math.abs(x+chord*.12)),1-ease(.045,.112,Math.abs(x+chord*.63)));
        return paint(4,9,bar*ease(.18,.36,u)*.72,.99+tiny(x,y,z));
      }
      return paint(4,5,ease(.18,.94,u)*.55,1+tiny(x,y,z));
    };
    const stations=[[.26,.08,.20,chord*.88],[.32,.14,span*.27,chord],[.17-sweep,.14,span*.50,chord*.70],
      [.10-sweep*1.59,.09,span*.69,chord*.49],[-.15-sweep*1.69,.035,span*.83,chord*.23]];
    A.sheet(stations.map(([x,y,z,d])=>[0,.22,.52,.82,1].map(f=>[x-d*f,y+Math.sin(f*Math.PI)*.125,s*z])),wingPaint,wingWeights);
    for(let j=0;j<9;j++){
      const t=j/8, z=mix(.22,span*.55,t), f=-chord*mix(.98,.75,t);
      A.vane([.24-sweep*t,.147,s*z],[f-sweep*t,.032,s*(z+.21+t*.16)],span*.095,.026,
        (x,y,z)=>paint(4,5,ease(.0,-.80,x)*.71,1+tiny(x,y,z)),wingWeights);
      A.vane([.27-sweep*t,.176,s*z],[-chord*.46-sweep*t,.167,s*(z+.145)],span*.077,.047,wingPaint,wingWeights,"plumage",true);
    }
    for(let j=0;j<8;j++){
      const t=j/7, tipSpan=span*(.99-.43*t), tipX=mix(-.16-sweep*1.88,-chord*.96-sweep*.48,t);
      const finger=(eagle||kind==="crow")?1:.42;
      const width=span*(.087-t*.019);
      A.vane([.126-sweep-.50*t,.117,s*span*(.525-.15*t)],[tipX-finger*.09*(j%2),.018-finger*.03*(j%2),s*tipSpan],
        width,.047,(x,y,z)=> {
          const u=Math.abs(z)/span;
          if(gull) return paint(5,8,(j<5&&u>.70+j*.017&&u<.75+j*.017)?.94:0,1+tiny(x,y,z));
          if(eagle) return paint(4,5,ease(.45,.84,u),1+tiny(x,y,z));
          return paint(5,4,(1-ease(.51,.89,u))*.36,1+tiny(x,y,z));
        },wingWeights);
    }
  }
  let perch;
  if(!bat){
    perch=A.joint("Feet",[-.13,-depth*.59,0],body);
    for(const s of [-1,1]){
      const z=s*depth*.41, foot=-depth*.99;
      A.tube([[-.12,-depth*.57,z,.032],[-.19,-depth*.79,z,.025],[-.15,foot,z,.021]],paint(7),perch,"scale",{seg:8,up:[1,0,0]});
      for(let i=-1;i<=1;i++) A.tube([[-.15,foot,z,.024],[.024,foot-.012,z+i*.068,.016],
        [.105,foot-.024,z+i*.103,.008]],paint(7),perch,"scale",{seg:6,cap:1});
      A.tube([[-.14,foot,z,.024],[-.31,foot-.018,z+s*.05,.009]],paint(7),perch,"scale",{seg:6});
    }
  }
  return A.finish(kind);
}

export function createFlyingBird(kind,size) {
  if(!flying.has(kind)) flying.set(kind,flightTemplate(kind));
  const root=flying.get(kind)(), find=name=>root.getObjectByName(name);
  const wings=["L","R"].map(s=>[find("Wing_"+s),find("Wrist_"+s)]);
  const tail=find("Tail"), head=find("Head"), feet=find("Feet");
  root.scale.setScalar(size);
  return {root, pose(t,phase,ground,glide,bank){
    const wave=Math.sin(phase);
    const amp=kind==="bat"?.82:kind==="gull"?.57:kind==="eagle"?.52:.77;
    const shoulder=mix(-.11-wave*amp,-.075-Math.sin(t*1.8)*.055,glide);
    const wrist=mix(Math.cos(phase-.53)*.42+wave*.14,.10,glide);
    wings.forEach(([wing,tip],i)=>{
      const s=i===0?1:-1;
      wing.rotation.set(s*(ground?1.05:shoulder)+bank*.10, s*(ground?-.77:-.19+wave*.095),0);
      tip.rotation.set(s*(ground?-.32:wrist),s*(ground?-1.25:-.04-wave*.15),0);
    });
    tail.rotation.z=.10*wave*(1-glide)+bank*.26;
    head.rotation.z=ground?Math.sin(phase)*.135:-.06*wave*(1-glide);
    head.rotation.y=ground?Math.sin(t*2.1)*.22:bank*.16;
    if(feet) feet.rotation.z=ground?0:-1.65;
  }};
}

function waterTemplate(kind) {
  const egret=kind==="egret", swan=kind==="swan", duck=kind==="duck";
  const A=buildAnimal(), body=A.joint("Body");
  const neckProfile = egret ? [[.152,.699,0,.082,.089],[.19,.810,0,.070,.073],[.111,.903,0,.046,.048],
    [.075,1.024,0,.038,.037],[.111,1.118,0,.035,.038],[.195,1.161,0,.036,.042],[.272,1.163,0,.039,.041]]
    : swan ? [[.23,.15,0,.122,.132],[.37,.26,0,.092,.101],[.47,.43,0,.070,.076],
      [.40,.62,0,.059,.069],[.365,.80,0,.062,.064],[.437,.914,0,.063,.067],[.53,.942,0,.073,.067]]
    : [[.14,.097,0,.078,.092],[.183,.151,0,.069,.082],[.191,.222,0,.053,.055],
      [.214,.272,0,.053,.058],[.258,.287,0,.065,.058]];
  const base=neckProfile[1].slice(0,3), top=neckProfile.at(-1).slice(0,3);
  const middle=neckProfile[egret||swan?3:2].slice(0,3);
  const neck=A.joint("Neck",base,body), upper=A.joint("UpperNeck",middle,neck), head=A.joint("Head",top,upper);
  const length=egret?.44:swan?.60:.34, height=egret?.714:swan?.144:.094;
  const depth=egret?.159:swan?.213:.116, width=egret?.142:swan?.234:.126;
  const paint=tones(0xeee9dd,0xbfc4c3,0xf7f4e9,0x304633,0x396354,0xd5cbbf,0x8b5239,0x303231,0x293c64,0x261f20);
  const nTone=(x,y,z,ny)=>{
    if(!duck) return paint(0,1,ease(.0,.82,-ny)*.48,1+grain(x,y,z)*.04);
    if(y<.158) return paint(6,5,ease(.026,.116,-y+.14)*.39);
    if(y<.181) return paint(2);
    return paint(3,4,ease(.19,.32,y)*.74,1+grain(x,y,z)*.10);
  };
  A.volume([
    ball(-length*.48,height-depth*.05,0,length*.52,depth*.81,width*.79,-.08),
    ball(-length*.06,height,0,length*.72,depth,width,.05),
    ball(length*.37,height+depth*.16,0,length*.34,depth*.81,width*.83,.45),
    ball(neckProfile[0][0],neckProfile[0][1],0,width*.68,depth*.69,width*.63,.44),
  ],(x,y,z,ny)=>{
    const noise=1+grain(x,y,z)*.058;
    if(!duck) return paint(0,1,ease(.0,.82,-ny)*.42,noise);
    return x>.085?paint(5,6,ease(.07,.224,x),noise):paint(5,7,ease(-.17,-.34,x)*.77,noise);
  },(x,y)=>transition(body,neck,ease(base[1]-.028,base[1]+.066,y)*ease(length*.04,length*.35,x)),{blend:duck?.031:.038,material:"plumage",resolution:49});
  A.tube(neckProfile,nTone,(x,y)=>{
    const a=ease(base[1]-.064,base[1]+.066,y),b=ease(middle[1]-.056,middle[1]+.079,y),c=ease(top[1]-.074,top[1]+.029,y);
    return [[body,1-a],[neck,a*(1-b)],[upper,a*b*(1-c)],[head,a*b*c]];
  },"plumage",{seg:24,sub:7,capK:.65});
  const [hx,hy]=top;
  const H=egret?.049:swan?.074:.060;
  A.volume([ball(hx+.018,hy+.001,0,H*1.20,H*.82,H*.82,-.11),ball(hx+H*.58,hy-H*.16,0,H*.70,H*.66,H*.61,-.25)],
    nTone,head,{blend:.013,material:"plumage",resolution:33});
  const tip=hx+(egret?.221:swan?.174:.143), y0=hy-H*.26;
  const beak=tones(duck?0xc2a245:swan?0xce7640:0x28282b,duck?0x968244:swan?0x352725:0x72675a,0x201e20);
  const bx=hx+H*.99, w=H*(duck?.65:.54);
  A.tube([[bx,y0,0,w,w*.57],[mix(bx,tip,.51),y0-.009,0,w*(egret?.55:.89),w*.36],
    [tip,y0-.025,0,egret?.002:w*.27,egret?.002:w*.21]],(x,y)=>beak(0,1,ease(tip-.028,tip,x)*.52),head,"scale",{seg:16,capK:.44});
  A.tube([[bx,y0-w*.40,0,w*.9,w*.25],[tip-.005,y0-.025-w*.11,0,egret?.003:w*.36,w*.11]],beak(0,1,.28),head,"scale");
  if(swan) A.oval([bx-.007,y0+.012,0],[.042,.025,.039],0x292729,head,"eye");
  for(const s of [-1,1]){
    const z=s*H*.723, ex=hx+H*.50, ey=hy+H*.19, er=H*(egret?.151:.155);
    A.oval([ex,ey,z],[er*1.47,er,er*.55],egret?0xbaa665:0x474136,head,"eye");
    A.oval([ex+.001,ey,z+s*er*.42],[er*.85,er*.79,er*.23],duck?0x6a5234:egret?0xb5903c:0x302a2a,head,"eye");
    A.oval([ex+.002,ey,z+s*er*.58],[er*.48,er*.59,er*.14],0x15151a,head,"eye");
    A.oval([bx+.024,y0+.003,s*w*.75],[w*.15,w*.095,w*.12],0x392e28,head,"eye");
    if(egret) for(let j=0;j<3;j++) A.vane([hx-.021,hy+.024,s*(.005+j*.007)],
      [hx-.091-j*.026,hy-.010-j*.008,s*(.017+j*.010)],.008,.003,0xeae8df,head);
  }
  for(const s of [-1,1]){
    const wing=A.joint(s>0?"Wing_L":"Wing_R",[length*.22,height+depth*.19,s*width*.72],body);
    A.tube([[-length*.72,height+depth*.20,s*width*.51,width*.10,depth*.09],
      [-length*.40,height+depth*.45,s*width*.78,width*.31,depth*.28],
      [.035,height+depth*.52,s*width*.81,width*.40,depth*.44],
      [length*.32,height+depth*.36,s*width*.66,width*.22,depth*.21]],(x,y,z,ny)=>paint(duck?5:0,1,ease(.02,.68,-ny)*.41,1+grain(x,y,z)*.045),
      wing,"plumage",{seg:17,sub:6});
    for(let i=0;i<8;i++){
      const t=i/7;
      const a=[mix(.06,-length*.22,t),height+depth*mix(.94,.19,t),s*width*mix(.95,1.24,t)];
      const b=[-length*mix(.86,.64,t),height+depth*mix(.39,.015,t),s*width*mix(.64,.96,t)];
      A.vane(a,b,width*.24,depth*.13,(x,y,z)=>{
        const stripe=duck&&i>=4&&i<=6;
        if(stripe){
          const v=ease(-length*.71,-length*.33,x);
          return paint(v>.13&&v<.76?8:2,7,v>.89?.57:0,1+grain(x,y,z)*.09);
        }
        return paint(duck?5:0,1,.08+i*.038,1+grain(x,y,z)*.075);
      },wing,"plumage",!duck);
    }
  }
  for(let j=-2;j<=2;j++) A.vane([-length*.51,height+.027,j*width*.16],
    [-length*(egret?1.02:swan?1.20:1.04),height+depth*.10,j*width*.22],width*.48,depth*.07,
    paint(duck?7:0,1,Math.abs(j)*.08),body);

  if(egret) for(const s of [-1,1]){
    const p=[-.062,.63,s*.067],q=[-.131,.321,s*.081],f=[-.064,.029,s*.082];
    const hip=A.joint(s>0?"Leg_L":"Leg_R",p,body);
    A.tube([[...p,.023],[...q,.013],[...f,.011]],(x,y,z)=>beak(0,1,.27+grain(x,y,z)*.15),hip,"scale",{up:[1,0,0],seg:11});
    for(let j=-1;j<=1;j++) A.tube([[...f,.010],[-.012,.017,f[2]+j*.026,.008],[.067,.011,f[2]+j*.059,.003]],0xa9964a,hip,"scale",{seg:7});
    A.tube([[...f,.008],[-.115,.014,f[2]+s*.021,.004]],0xa9964a,hip,"scale",{seg:7});
  }
  if(!egret) for(const s of [-1,1]){
    const z=s*width*.48, leg=A.joint(s>0?"Foot_L":"Foot_R",[.004,-.031,z],body);
    const skin=duck?0xb17644:0x39393b;
    A.tube([[.013,.015,z,.016],[-.033,-.068,z,.014],[-.083,-.079,z,.013]],skin,leg,"scale",{seg:8,up:[1,0,0]});
    A.sheet([[[-.079,-.078,z-.012],[-.080,-.080,z],[-.079,-.078,z+.012]],
      [[-.133,-.081,z-.034],[-.160,-.087,z],[-.133,-.081,z+.034]]],skin,leg,"scale");
  }
  return A.finish(kind);
}

export function createWaterBird(kind) {
  if(!waterfowl.has(kind)) waterfowl.set(kind,waterTemplate(kind));
  const root=waterfowl.get(kind)(), get=name=>root.getObjectByName(name);
  const n=get("Neck"),m=get("UpperNeck"),h=get("Head");
  const wings=["Wing_L","Wing_R"].map(get),feet=["Foot_L","Foot_R"].map(get);
  return {root,pose(t,bob,turn){
    const egret=kind==="egret", dip=egret?Math.pow(Math.max(0,Math.sin(t*.49)),15):0;
    n.rotation.z=Math.sin(t*1.36)*.035-dip*.27+bob*.018;
    m.rotation.z=Math.sin(t*1.36-.41)*.048-dip*.22;
    h.rotation.z=Math.sin(t*1.36-.92)*.033+dip*.19;
    n.rotation.x=Math.sin(t*.91)*.048;
    h.rotation.y=Math.sin(t*.84)*.095+turn*.13;
    for(let i=0;i<2;i++){
      const sign=i===0?1:-1;
      wings[i].rotation.x=sign*(Math.sin(t*.98+i)*.021+dip*.046);
      if(feet[i]) feet[i].rotation.z=Math.sin(t*(kind==="swan"?3.3:5.4)+i*Math.PI)*.48;
    }
  }};
}
