import { ball, buildAnimal, ease, grain, mix, tones } from "./wildlife_mesh.js";

let fishTemplate, fireflyTemplate;
const butterflies = new Map();
function makeFish(){
  const A=buildAnimal(), body=A.joint("Body"), bend=A.joint("Spine",[-.042,0,0],body), tail=A.joint("Tail",[-.155,0,0],bend);
  const paint=tones(0x465b49,0xa6a68d,0xded0b9,0x62534c,0x4b5654,0xb18c74,0xb58880);
  const weights=(x)=>{
    const a=1-ease(-.12,-.010,x), b=1-ease(-.208,-.12,x);
    return [[body,1-a],[bend,a*(1-b)],[tail,a*b]];
  };
  const scales=(x,y,z,ny)=>{
    const u=x*126+y*31, v=y*172+Math.sin(x*52)*.41;
    const pattern=(Math.cos(u+Math.cos(v)*1.6)*.5+.5)*.13;
    const spot=Math.sin(x*108+y*190+z*97)*Math.cos(x*172-y*87+z*128)>.78?.42:0;
    const belly=ease(.22,.93,-ny);
    if(spot&&y>-.01&&x<.103)return paint(0,3,spot,.75);
    const stripe=(1-ease(.005,.024,Math.abs(y+.005)))*ease(.012,.031,Math.abs(z))*.47;
    return ny<-.4?paint(1,2,belly,1-pattern):paint(stripe>.25?6:0,1,ease(.06,.96,-ny),1-pattern+grain(x,y,z)*.07);
  };
  A.volume([ball(-.08,-.002,0,.116,.046,.022,.08),ball(.013,.006,0,.138,.056,.031,-.04),
    ball(.106,.002,0,.066,.037,.026,-.15),ball(-.149,-.003,0,.051,.019,.012,.08),
    ball(.155,-.007,0,.032,.021,.017,-.14)],scales,weights,{blend:.013,material:"scale",resolution:50});
  const fin=(start,end,rays,paintFin,w)=>{
    const rows=[0,.31,.63,1].map(t=>Array.from({length:rays},(_,i)=>{
      const q=i/(rays-1),a=start(q),b=end(q);
      return a.map((v,j)=>mix(v,b[j],t)+(j===2?Math.sin(Math.PI*t)*.005:0));
    }));
    A.sheet(rows,paintFin,w,"scale");
    for(let i=0;i<rays;i++){
      const q=i/(rays-1),a=start(q),b=end(q);
      A.tube([[...a,.00115],[...a.map((v,j)=>mix(v,b[j],.6)),.001],[...b,.00036]],0x766a5c,w,"scale",{seg:5,sub:2,cap:1});
    }
  };
  fin(q=>[-.171,mix(.012,-.013,q),0],q=>[-.223-.046*Math.abs(q-.5)*2,mix(.059,-.049,q),0],9,
    (x,y,z)=>paint(4,5,ease(-.28,-.19,x)*.56,.96+grain(x,y,z)*.13),tail);
  fin(q=>[mix(.053,-.064,q),.041+Math.sin(q*Math.PI)*.010,0],q=>[mix(.025,-.092,q),.055+Math.sin(Math.PI*q)**.72*.064,0],8,
    (x,y)=>paint(4,5,ease(.045,.10,y)*.69),weights);
  for(const s of [-1,1]){
    fin(q=>[mix(.083,.056,q),mix(-.016,-.033,q),s*.025],
      q=>[mix(.051,-.023,q),-.039-Math.sin(Math.PI*q)*.018,s*(.028+.028*Math.sin(Math.PI*q))],5,
      (x,y,z)=>paint(4,5,ease(.020,.054,Math.abs(z))*.72),body);
    A.oval([.125,.015,s*.023],[.010,.009,.004],0xc0ad81,body,"eye",.11);
    A.oval([.129,.015,s*.026],[.0057,.0058,.0019],0x25272a,body,"eye");
    A.tube([[.109,.034,s*.022,.001],[.092,.015,s*.028,.0013],[.100,-.018,s*.026,.0009]],0x5f5048,body,"eye",{seg:5,cap:1});
  }
  A.tube([[.164,-.014,-.015,.0011],[.177,-.015,0,.0014],[.164,-.014,.015,.0011]],0x65504a,body,"eye",{seg:6,cap:1,up:[0,1,0]});
  return A.finish("fish");
}
export function createFish(){
  fishTemplate ||= makeFish();
  const root=fishTemplate(), spine=root.getObjectByName("Spine"),tail=root.getObjectByName("Tail");
  return {root,pose(t){spine.rotation.y=Math.sin(t*19)*.19;tail.rotation.y=Math.sin(t*19-.91)*.43;}};
}

function makeButterfly(color,pattern){
  const A=buildAnimal(), body=A.joint("Body");
  const paint=tones(color,0x222129,0xf5e1bb,0x9e734f);
  A.tube([[-.038,0,0,.0027],[-.017,0,0,.005],[.008,.001,0,.006],[.022,.001,0,.0048]],paint(1),body,"scale");
  for(const s of [-1,1]){
    const wing=A.joint(s>0?"Wing_L":"Wing_R",[.004,0,s*.0038],body);
    const boundary=[[.029,.001,.004],[.044,.002,.032],[.038,.001,.065],[.020,0,.078],
      [-.002,0,.076],[-.018,-.002,.061],[-.020,-.001,.045],[-.036,-.001,.050],[-.050,-.001,.038],
      [-.051,-.001,.023],[-.041,0,.012],[-.021,0,.005]];
    const c=[-.002,.002,s*.004];
    const steps=[.005,.11,.23,.37,.50,.62,.74,.82,.89,.93,.969,1];
    const rows=steps.map(t=>boundary.map(([x,y,z])=>[mix(c[0],x,t),mix(c[1],y,t)+Math.sin(t*Math.PI)*.006,s*mix(.004,z,t)]));
    const gPaint=(x,y,z)=>{
      const span=Math.abs(z), rim=ease(.059,.076,span)+ease(.032,.046,Math.abs(x));
      const dots=span>.046&&Math.sin(x*490+z*220)>.41;
      const spots=(Math.sin(x*280+span*134)*Math.sin(span*250-x*91)>.58);
      const light=1+.24*grain(x,y,z,3.7)+Math.sin(span*122)*.13;
      if(dots&&rim>.63)return paint(2,1,pattern*.14,light);
      if(spots&&pattern>1) return paint(1,3,.22,light);
      return paint(0,1,Math.min(.96,rim*.77+(1-ease(.009,.038,span))*.28),light);
    };
    A.sheet(rows,gPaint,wing,"scale");
    for(const idx of [1,2,3,5,7,8,10]){
      const [x,y,z]=boundary[idx];
      A.tube([[...c,.00047],[x*.53,.007,s*z*.56,.00037],[x*.93,y+.002,s*z*.94,.00020]],
        paint(0,1,.55),wing,"scale",{seg:4,sub:3,cap:1});
    }
    A.tube([[.019,.005,s*.002],[.038,.010,s*.009],[.046,.014,s*.014]].map((p,i)=>[...p,i===2?.0013:.00065]),paint(1),body,"scale",{seg:5,cap:2});
    A.oval([.017,.004,s*.004],[.003,.0024,.0017],0x2c2628,body,"eye");
    for(let j=0;j<3;j++) A.tube([[.011-j*.013,-.003,s*.003,.0007],[.016-j*.012,-.010,s*.013,.00055],
      [.010-j*.014,-.015,s*.019,.00033]],0x4a372d,body,"scale",{seg:4,sub:2,cap:1});
  }
  return A.finish("butterfly");
}
export function createButterfly(color,pattern){
  if(!butterflies.has(color)) butterflies.set(color,makeButterfly(color,pattern));
  const root=butterflies.get(color)(), l=root.getObjectByName("Wing_L"), r=root.getObjectByName("Wing_R");
  return {root,pose(phase){const f=.24+Math.sin(phase)*.98;l.rotation.x=f;r.rotation.x=-f;l.rotation.y=Math.cos(phase)*.12;r.rotation.y=-l.rotation.y;}};
}

function makeFirefly(){
  const A=buildAnimal(),body=A.joint("Body");
  A.oval([-.005,.000,0],[.018,.007,.008],0x504739,body,"coat");
  A.oval([.012,.001,0],[.008,.007,.008],0x4e332d,body,"coat");
  A.oval([.019,.001,0],[.005,.004,.0055],0x272226,body,"eye");
  for(const s of [-1,1]){
    const wing=A.joint(s>0?"Wing_L":"Wing_R",[.006,.003,s*.004],body);
    A.oval([-.005,.004,s*.004],[.017,.0024,.0039],0x312b29,wing,"coat");
    A.vane([.006,.004,s*.006],[-.030,.004,s*.017],.006,.002,0x6f5b45,wing,"scale");
    A.tube([[.020,.004,s*.002,.00068],[.028,.009,s*.007,.00053],[.031,.012,s*.009,.0004]],0x594a3a,body,"coat",{seg:4,cap:1});
    for(let j=0;j<3;j++) A.tube([[.012-j*.007,-.002,s*.004,.0008],[.013-j*.009,-.006,s*.011,.0006],
      [.008-j*.009,-.009,s*.014,.00034]],0x514539,body,"coat",{seg:4,sub:2,cap:1});
  }
  return A.finish("firefly");
}
export function createFirefly(){
  fireflyTemplate ||= makeFirefly();
  const root=fireflyTemplate(),left=root.getObjectByName("Wing_L"),right=root.getObjectByName("Wing_R");
  return {root,pose(t){
    const angle=.43+Math.sin(t*43)*.27;
    left.rotation.x=-angle;right.rotation.x=angle;
    left.rotation.y=.22;right.rotation.y=-.22;
  }};
}
